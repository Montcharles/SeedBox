Target amd64-unicode
SetCompressor /SOLID lzma
SetCompressorDictSize 64

!include "MUI2.nsh"
!include "FileFunc.nsh"

!define APPNAME "SeedBox"
!define APPFULL "SeedBox - Dimensional Morphometry"
!define VERSION "2.01"
!define PUBLISHER "SeedBox"
!define SRC "/home/claude/build/dist/SeedBox"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\SeedBox"

Name "${APPFULL}"
OutFile "/home/claude/build/out/SeedBox_2.01_Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\SeedBox"
InstallDirRegKey HKCU "Software\SeedBox" "InstallDir"
RequestExecutionLevel user
BrandingText "SeedBox ${VERSION}"
VIProductVersion "2.0.1.0"
VIAddVersionKey "ProductName" "${APPNAME}"
VIAddVersionKey "FileDescription" "${APPFULL} Setup"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "ProductVersion" "${VERSION}"
VIAddVersionKey "CompanyName" "${PUBLISHER}"
VIAddVersionKey "LegalCopyright" "(c) 2026 SeedBox"

!define MUI_ICON "/home/claude/build/app/seedbox/assets/seedbox.ico"
!define MUI_UNICON "/home/claude/build/app/seedbox/assets/seedbox.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "/home/claude/build/installer/welcome.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "/home/claude/build/installer/welcome.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_RIGHT
!define MUI_HEADERIMAGE_BITMAP "/home/claude/build/installer/header.bmp"
!define MUI_ABORTWARNING
!define MUI_LANGDLL_ALLLANGUAGES
!define MUI_FINISHPAGE_RUN "$INSTDIR\SeedBox.exe"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "PortugueseBR"
!insertmacro MUI_LANGUAGE "English"


Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
FunctionEnd

Function un.onInit
  !insertmacro MUI_UNGETLANGUAGE
FunctionEnd

Section "SeedBox" SecMain
  SectionIn RO
  SetOutPath "$INSTDIR"
  ; remove files of a previous version
  RMDir /r "$INSTDIR\runtime"
  RMDir /r "$INSTDIR\app"
  File /r "${SRC}/*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\SeedBox"
  CreateShortCut "$SMPROGRAMS\SeedBox\SeedBox.lnk" "$INSTDIR\SeedBox.exe" "" "$INSTDIR\SeedBox.exe" 0
  CreateShortCut "$SMPROGRAMS\SeedBox\Uninstall SeedBox.lnk" "$INSTDIR\Uninstall.exe"
  CreateShortCut "$DESKTOP\SeedBox.lnk" "$INSTDIR\SeedBox.exe" "" "$INSTDIR\SeedBox.exe" 0
  WriteRegStr HKCU "Software\SeedBox" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayName" "${APPFULL}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${UNINSTKEY}" "Publisher" "${PUBLISHER}"
  WriteRegStr HKCU "${UNINSTKEY}" "DisplayIcon" "$INSTDIR\SeedBox.exe"
  WriteRegStr HKCU "${UNINSTKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTKEY}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  IntFmt $0 "0x%08X" $0
  WriteRegDWORD HKCU "${UNINSTKEY}" "EstimatedSize" "$0"
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\SeedBox.lnk"
  RMDir /r "$SMPROGRAMS\SeedBox"
  RMDir /r "$INSTDIR\runtime"
  RMDir /r "$INSTDIR\app"
  Delete "$INSTDIR\SeedBox.exe"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  DeleteRegKey HKCU "${UNINSTKEY}"
  DeleteRegKey HKCU "Software\SeedBox"
SectionEnd
