// SeedBox launcher (C++): boots the embedded runtime and starts the application.
#define WIN32_LEAN_AND_MEAN
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <shellapi.h>
#include <string>
#include <vector>

typedef int(__cdecl* PyMainFn)(int, wchar_t**);

static std::wstring dir_of(const std::wstring& p) {
    const size_t k = p.find_last_of(L"\\/");
    return k == std::wstring::npos ? p : p.substr(0, k);
}

static bool exists(const std::wstring& p) { return GetFileAttributesW(p.c_str()) != INVALID_FILE_ATTRIBUTES; }

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    wchar_t buf[32768];
    GetModuleFileNameW(nullptr, buf, 32768);
    const std::wstring exe(buf);
    const std::wstring root = dir_of(exe);
    const std::wstring rt = root + L"\\runtime";
    const std::wstring dll = rt + L"\\python312.dll";
    const std::wstring app = root + L"\\app\\main.pyc";

    if (!exists(dll) || !exists(app)) {
        MessageBoxW(nullptr, L"Installation files are missing. Please reinstall SeedBox.", L"SeedBox",
                    MB_ICONERROR | MB_OK);
        return 2;
    }
    SetEnvironmentVariableW(L"PYTHONHOME", rt.c_str());
    SetEnvironmentVariableW(L"PYTHONPATH", nullptr);
    SetEnvironmentVariableW(L"PYTHONSTARTUP", nullptr);
    SetEnvironmentVariableW(L"PYTHONNOUSERSITE", L"1");
    SetEnvironmentVariableW(L"PYTHONUTF8", L"1");
    SetEnvironmentVariableW(L"PYTHONDONTWRITEBYTECODE", L"1");
    SetEnvironmentVariableW(L"SEEDBOX_HOME", root.c_str());
    // Detach invalid inherited standard handles (GUI launch contexts).
    const DWORD ids[3] = {STD_INPUT_HANDLE, STD_OUTPUT_HANDLE, STD_ERROR_HANDLE};
    for (DWORD id : ids) {
        HANDLE h = GetStdHandle(id);
        if (h == nullptr || h == INVALID_HANDLE_VALUE) continue;
        SetLastError(NO_ERROR);
        if (GetFileType(h) == FILE_TYPE_UNKNOWN && GetLastError() != NO_ERROR) SetStdHandle(id, nullptr);
    }
    SetDllDirectoryW(rt.c_str());

    HMODULE py = LoadLibraryExW(dll.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
    if (!py) {
        MessageBoxW(nullptr, L"Unable to start the SeedBox engine.", L"SeedBox", MB_ICONERROR | MB_OK);
        return 3;
    }
    auto py_main = reinterpret_cast<PyMainFn>(GetProcAddress(py, "Py_Main"));
    if (!py_main) {
        MessageBoxW(nullptr, L"Unable to start the SeedBox engine.", L"SeedBox", MB_ICONERROR | MB_OK);
        return 4;
    }
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    std::vector<std::wstring> args = {exe, L"-s", L"-B", app};
    for (int i = 1; i < argc; ++i) args.emplace_back(argv[i]);
    std::vector<wchar_t*> ptrs;
    for (auto& a : args) ptrs.push_back(const_cast<wchar_t*>(a.c_str()));
    ptrs.push_back(nullptr);
    const int rc = py_main(static_cast<int>(args.size()), ptrs.data());
    LocalFree(argv);
    return rc;
}
