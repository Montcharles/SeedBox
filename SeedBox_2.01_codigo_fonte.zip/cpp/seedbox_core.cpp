// SeedBox native computation core (C++17)
// Physical properties, hexagonal SOM training, best-matching units and
// chi-square permutation test.

#include <cmath>
#include <cstdint>
#include <vector>
#include <random>
#include <algorithm>
#include <numeric>

#if defined(_WIN32)
#define SB_API extern "C" __declspec(dllexport)
#else
#define SB_API extern "C" __attribute__((visibility("default")))
#endif

static const double SB_PI = 3.14159265358979323846;

SB_API int sb_version() { return 201; }

// ---------------------------------------------------------------------------
// Physical properties of seeds treated as ellipsoids.
SB_API void sb_physical(int n, const double* L, const double* W, const double* T,
                        double* Da, double* Dg, double* R, double* Phi, double* V, double* S) {
    for (int i = 0; i < n; ++i) {
        const double a = L[i], b = W[i], c = T[i];
        Da[i] = (a + b + c) / 3.0;
        Dg[i] = std::cbrt(a * b * c);
        R[i] = b / a * 100.0;
        Phi[i] = Dg[i] / a * 100.0;
        V[i] = SB_PI * a * b * c / 6.0;
        S[i] = SB_PI * Dg[i] * Dg[i];
    }
}

// ---------------------------------------------------------------------------
// Online SOM training. W: m x dim (in/out), D2: m x m squared lattice distances,
// idx: n_iter sample indices.
SB_API void sb_som_train(int n, int dim, const double* X, int m, double* W, const double* D2,
                         int n_iter, double lr0, double sigma0, const int64_t* idx) {
    std::vector<double> h(m);
    for (int t = 0; t < n_iter; ++t) {
        const double frac = 1.0 - static_cast<double>(t) / n_iter;
        const double lr = lr0 * frac;
        double sig = sigma0 * frac;
        if (sig < 0.5) sig = 0.5;
        const double inv = 1.0 / (2.0 * sig * sig);
        const double* x = X + static_cast<size_t>(idx[t]) * dim;
        int best = 0;
        double bd = 1e300;
        for (int j = 0; j < m; ++j) {
            const double* w = W + static_cast<size_t>(j) * dim;
            double d = 0.0;
            for (int k = 0; k < dim; ++k) {
                const double e = w[k] - x[k];
                d += e * e;
            }
            if (d < bd) { bd = d; best = j; }
        }
        const double* drow = D2 + static_cast<size_t>(best) * m;
        for (int j = 0; j < m; ++j) {
            const double g = lr * std::exp(-drow[j] * inv);
            if (g < 1e-12) continue;
            double* w = W + static_cast<size_t>(j) * dim;
            for (int k = 0; k < dim; ++k) w[k] += g * (x[k] - w[k]);
        }
    }
}

// Best and second-best matching units; returns mean quantization error.
SB_API double sb_bmu(int n, int dim, const double* X, int m, const double* W, int64_t* b1, int64_t* b2) {
    double qe = 0.0;
    for (int i = 0; i < n; ++i) {
        const double* x = X + static_cast<size_t>(i) * dim;
        double d1 = 1e300, d2 = 1e300;
        int j1 = 0, j2 = 0;
        for (int j = 0; j < m; ++j) {
            const double* w = W + static_cast<size_t>(j) * dim;
            double d = 0.0;
            for (int k = 0; k < dim; ++k) {
                const double e = w[k] - x[k];
                d += e * e;
            }
            if (d < d1) { d2 = d1; j2 = j1; d1 = d; j1 = j; }
            else if (d < d2) { d2 = d; j2 = j; }
        }
        b1[i] = j1;
        b2[i] = j2;
        qe += std::sqrt(d1);
    }
    return n > 0 ? qe / n : 0.0;
}

// ---------------------------------------------------------------------------
static double chi2_stat(int n, const int64_t* units, const int64_t* labels, int n_units, int n_groups,
                        std::vector<double>& tab) {
    std::fill(tab.begin(), tab.end(), 0.0);
    for (int i = 0; i < n; ++i) tab[static_cast<size_t>(units[i]) * n_groups + labels[i]] += 1.0;
    std::vector<double> rs(n_units, 0.0), cs(n_groups, 0.0);
    double tot = 0.0;
    for (int u = 0; u < n_units; ++u)
        for (int g = 0; g < n_groups; ++g) {
            const double v = tab[static_cast<size_t>(u) * n_groups + g];
            rs[u] += v;
            cs[g] += v;
            tot += v;
        }
    double chi = 0.0;
    for (int u = 0; u < n_units; ++u) {
        if (rs[u] <= 0) continue;
        for (int g = 0; g < n_groups; ++g) {
            const double e = rs[u] * cs[g] / tot;
            if (e <= 0) continue;
            const double d = tab[static_cast<size_t>(u) * n_groups + g] - e;
            chi += d * d / e;
        }
    }
    return chi;
}

// Observed chi-square of the unit x group table and its permutation distribution.
SB_API double sb_chi2_perm(int n, const int64_t* units, const int64_t* labels, int n_units, int n_groups,
                           int n_perm, uint64_t seed, double* perm_out) {
    std::vector<double> tab(static_cast<size_t>(n_units) * n_groups);
    const double obs = chi2_stat(n, units, labels, n_units, n_groups, tab);
    std::vector<int64_t> lab(labels, labels + n);
    std::mt19937_64 rng(seed);
    for (int p = 0; p < n_perm; ++p) {
        for (int i = n - 1; i > 0; --i) {
            std::uniform_int_distribution<int> U(0, i);
            std::swap(lab[i], lab[U(rng)]);
        }
        perm_out[p] = chi2_stat(n, units, lab.data(), n_units, n_groups, tab);
    }
    return obs;
}
