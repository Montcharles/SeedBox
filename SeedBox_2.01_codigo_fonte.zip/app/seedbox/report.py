"""PDF report."""
from __future__ import annotations

import io
import os
import datetime as dt
import numpy as np

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                Image, KeepTogether, PageBreak, CondPageBreak)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

from .core import TRAITS, UNITS
from . import i18n, figures
from .i18n import tr, trait, num, fmt_p
from .paths import asset

NAVY = colors.HexColor("#0F2433")
GREEN = colors.HexColor("#2EA043")
BLUE = colors.HexColor("#1684C4")
INK = colors.HexColor("#1F2A33")
MUTED = colors.HexColor("#6B7A86")
LINE = colors.HexColor("#D9E1E7")
SOFT = colors.HexColor("#F3F6F8")
GREEN_SOFT = colors.HexColor("#E8F5EB")

_fonts_ok = False


def _fonts():
    global _fonts_ok
    if _fonts_ok:
        return
    f = lambda n: asset("fonts", n)
    pdfmetrics.registerFont(TTFont("Poppins", f("Poppins-Regular.ttf")))
    pdfmetrics.registerFont(TTFont("Poppins-Medium", f("Poppins-Medium.ttf")))
    pdfmetrics.registerFont(TTFont("Poppins-Bold", f("Poppins-Bold.ttf")))
    pdfmetrics.registerFont(TTFont("Body", f("Carlito-Regular.ttf")))
    pdfmetrics.registerFont(TTFont("Body-Bold", f("Carlito-Bold.ttf")))
    from reportlab.pdfbase.pdfmetrics import registerFontFamily
    registerFontFamily("Body", normal="Body", bold="Body-Bold", italic="Body", boldItalic="Body-Bold")
    _fonts_ok = True


def _styles():
    return dict(
        h1=ParagraphStyle("h1", fontName="Poppins-Bold", fontSize=17, leading=21, textColor=NAVY, spaceAfter=2),
        h2=ParagraphStyle("h2", fontName="Poppins-Medium", fontSize=11.5, leading=15, textColor=NAVY,
                          spaceBefore=10, spaceAfter=5),
        body=ParagraphStyle("body", fontName="Body", fontSize=9.6, leading=13, textColor=INK, alignment=TA_JUSTIFY),
        small=ParagraphStyle("small", fontName="Body", fontSize=8, leading=10, textColor=MUTED),
        cell=ParagraphStyle("cell", fontName="Body", fontSize=8.2, leading=10, textColor=INK),
        cellb=ParagraphStyle("cellb", fontName="Body-Bold", fontSize=8.2, leading=10, textColor=INK),
        head=ParagraphStyle("head", fontName="Body-Bold", fontSize=8.2, leading=10, textColor=colors.white),
        cap=ParagraphStyle("cap", fontName="Body", fontSize=8.4, leading=11, textColor=MUTED, alignment=TA_LEFT),
        kpiv=ParagraphStyle("kpiv", fontName="Poppins-Bold", fontSize=15, leading=18, textColor=NAVY,
                            alignment=TA_CENTER),
        kpil=ParagraphStyle("kpil", fontName="Body", fontSize=7.8, leading=9.5, textColor=MUTED, alignment=TA_CENTER),
        best=ParagraphStyle("best", fontName="Poppins-Bold", fontSize=13, leading=16, textColor=colors.HexColor("#1B7A33")),
    )


def _table(data, widths, header=True, zebra=True, align_right_from=1):
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
          ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
          ("LINEBELOW", (0, -1), (-1, -1), 0.6, LINE)]
    if header:
        st += [("BACKGROUND", (0, 0), (-1, 0), NAVY)]
    if zebra:
        for r in range(1 if header else 0, len(data)):
            if r % 2 == 0:
                st.append(("BACKGROUND", (0, r), (-1, r), SOFT))
    t.setStyle(TableStyle(st))
    return t


def _fig_image(R, key, width):
    fig = figures.make(R, key)
    png = figures.to_png_bytes(fig, dpi=220)
    ir = ImageReader(io.BytesIO(png))
    w, h = ir.getSize()
    return Image(io.BytesIO(png), width=width, height=width * h / w)


def build(R, path, meta: dict, progress=None):
    _fonts()
    S = _styles()
    G = R.groups
    W, H = A4
    margin = 16 * mm
    content_w = W - 2 * margin
    today = dt.date.today().strftime("%d/%m/%Y" if i18n.LANG == "pt" else "%Y-%m-%d")
    logo = asset("logo_light.png")

    def on_page(c, doc):
        c.saveState()
        c.setFillColor(NAVY)
        c.rect(0, H - 9 * mm, W, 9 * mm, stroke=0, fill=1)
        c.setFillColor(GREEN)
        c.rect(0, H - 9.8 * mm, W * 0.33, 0.8 * mm, stroke=0, fill=1)
        c.setFillColor(BLUE)
        c.rect(W * 0.33, H - 9.8 * mm, W * 0.67, 0.8 * mm, stroke=0, fill=1)
        c.setFillColor(colors.white)
        c.setFont("Poppins-Medium", 8)
        c.drawString(margin, H - 6 * mm, "SeedBox  ·  " + tr("app_sub"))
        c.drawRightString(W - margin, H - 6 * mm, tr("rep_doc_title"))
        c.setStrokeColor(LINE)
        c.setLineWidth(0.5)
        c.line(margin, 12 * mm, W - margin, 12 * mm)
        c.setFillColor(MUTED)
        c.setFont("Body", 7.8)
        c.drawString(margin, 8 * mm, f"{meta.get('project') or tr('rep_doc_title')}  ·  {today}")
        c.drawRightString(W - margin, 8 * mm, f"{tr('rep_page')} {doc.page}")
        c.restoreState()

    doc = BaseDocTemplate(path, pagesize=A4, leftMargin=margin, rightMargin=margin, topMargin=16 * mm,
                          bottomMargin=17 * mm, title=tr("rep_doc_title"), author=meta.get("analyst", ""),
                          subject="SeedBox", creator="SeedBox")
    frame = Frame(margin, 17 * mm, content_w, H - 33 * mm, id="f", leftPadding=0, rightPadding=0,
                  topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id="p", frames=[frame], onPage=on_page)])
    E = []
    step = lambda f: progress and progress(f)

    # ---------------- title block
    ir = ImageReader(logo)
    lw, lh = ir.getSize()
    logo_w = 62 * mm
    head = Table([[Image(logo, width=logo_w, height=logo_w * lh / lw),
                   [Paragraph(tr("rep_doc_title"), S["h1"]),
                    Paragraph(f"{tr('rep_date')}: {today}", S["small"])]]],
                 colWidths=[logo_w + 8 * mm, content_w - logo_w - 8 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    E += [head, Spacer(1, 6 * mm)]

    info = []
    for k, lab in [("project", "rep_project"), ("species", "species"), ("analyst", "rep_analyst"),
                   ("institution", "rep_inst")]:
        if meta.get(k):
            v = meta[k]
            if k == "species":
                v = f"<i>{v}</i>"
            info.append([Paragraph(tr(lab), S["cellb"]), Paragraph(v, S["cell"])])
    if info:
        t = Table(info, colWidths=[45 * mm, content_w - 45 * mm])
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, -1), SOFT), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
                               ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]))
        E += [t, Spacer(1, 5 * mm)]

    # ---------------- KPIs
    sig_n = int((R.comp["p"] < R.settings.alpha).sum()) if R.comp is not None else None
    kp = [(str(len(R.props)), tr("kpi_seeds")), (str(len(G)), tr("kpi_groups")),
          (f"{num(R.pca['cum'][1], 1)}%", tr("kpi_pca"))]
    if sig_n is not None:
        kp.insert(2, (f"{sig_n}/9", tr("kpi_sig")))
    if R.clf:
        kp.append((f"{num(R.clf['table'].iloc[0]['bacc'] * 100, 1)}%", tr("bacc")))
    cells = [[Paragraph(v, S["kpiv"]) for v, _ in kp], [Paragraph(l, S["kpil"]) for _, l in kp]]
    kt = Table(cells, colWidths=[content_w / len(kp)] * len(kp))
    kst = [("BOX", (i, 0), (i, 1), 0.6, LINE) for i in range(len(kp))]
    kst += [("BACKGROUND", (0, 0), (-1, -1), colors.white), ("TOPPADDING", (0, 0), (-1, 0), 7),
            ("BOTTOMPADDING", (0, 1), (-1, 1), 7)]
    kt.setStyle(TableStyle(kst))
    E += [kt, Spacer(1, 4 * mm)]
    step(0.1)

    # ---------------- 1. sample
    E.append(Paragraph(tr("rep_s1"), S["h2"]))
    rows = [[Paragraph(tr("group"), S["head"]), Paragraph("n", S["head"])] +
            [Paragraph(f"{trait(t)} (mm)", S["head"]) for t in ["L", "W", "T"]]]
    for g in G:
        r = [Paragraph(g, S["cellb"]), Paragraph(str(int((R.props.group == g).sum())), S["cell"])]
        for t in ["L", "W", "T"]:
            d = R.desc[(R.desc.group == g) & (R.desc.trait == t)].iloc[0]
            r.append(Paragraph(f"{num(d['min'])} – {num(d['max'])}", S["cell"]))
        rows.append(r)
    E.append(_table(rows, [content_w * 0.34, content_w * 0.09] + [content_w * 0.19] * 3))
    rep = R.clean_report
    if rep.get("missing") or rep.get("nonpositive"):
        E.append(Spacer(1, 2 * mm))
        E.append(Paragraph(f"{tr('incomplete')}: {rep.get('missing', 0) + rep.get('nonpositive', 0)}", S["small"]))

    # ---------------- 2. properties
    E.append(Paragraph(tr("rep_s2"), S["h2"]))
    hdr = [Paragraph(tr("trait"), S["head"])] + [Paragraph(g, S["head"]) for g in G]
    rows = [hdr]
    for t in TRAITS:
        r = [Paragraph(f"{trait(t)} ({UNITS[t]})", S["cellb"])]
        for g in G:
            d = R.desc[(R.desc.group == g) & (R.desc.trait == t)].iloc[0]
            let = ""
            if R.comp is not None:
                let = R.comp[R.comp.trait == t].iloc[0][f"letter_{g}"]
                let = f" <font color='#1684C4'><b>{let}</b></font>"
            r.append(Paragraph(f"{num(d['mean'])} ± {num(d['sd'])}{let}", S["cell"]))
        rows.append(r)
    first = content_w * 0.34
    E.append(_table(rows, [first] + [(content_w - first) / len(G)] * len(G)))
    E.append(Spacer(1, 1.5 * mm))
    note = "Mean ± SD." if i18n.LANG == "en" else "Média ± DP."
    if R.comp is not None:
        note += " " + tr("letters_note", a=num(R.settings.alpha, 2))
    E.append(Paragraph(note, S["small"]))
    step(0.25)

    # ---------------- 3. comparison
    if R.comp is not None:
        E.append(CondPageBreak(60 * mm))
        E.append(Paragraph(tr("rep_s3"), S["h2"]))
        rows = [[Paragraph(x, S["head"]) for x in [tr("trait"), tr("test"), tr("stat"), tr("p"), tr("effect"),
                                                   tr("result")]]]
        eff_names = {"g": "Hedges g", "r_rb": "r (rank-biserial)", "eta2": "η²", "eps2": "ε²"}
        for _, r in R.comp.iterrows():
            sig = r["p"] < R.settings.alpha
            rows.append([Paragraph(trait(r["trait"]), S["cellb"]), Paragraph(tr(r["test"]), S["cell"]),
                         Paragraph(num(r["stat"], 2), S["cell"]),
                         Paragraph(f"<b>{fmt_p(r['p'])}</b>" if sig else fmt_p(r["p"]), S["cell"]),
                         Paragraph(f"{eff_names[r['effect_name']]} = {num(r['effect'], 3)}", S["cell"]),
                         Paragraph(f"<font color='#1B7A33'><b>{tr('sig')}</b></font>" if sig else tr("ns"),
                                   S["cell"])])
        E.append(_table(rows, [content_w * w for w in [0.24, 0.16, 0.11, 0.1, 0.22, 0.17]]))
        E.append(Spacer(1, 3 * mm))
        E.append(KeepTogether([_fig_image(R, "box", content_w),
                               Paragraph(f"<b>{tr('fig_box')}.</b> " + tr("letters_note", a=num(R.settings.alpha, 2)),
                                         S["cap"])]))
    step(0.45)

    # ---------------- 4. multivariate
    E.append(CondPageBreak(90 * mm))
    E.append(Paragraph(tr("rep_s4"), S["h2"]))
    P = R.pca
    load = P["loadings"]
    top1 = load["PC1"].abs().sort_values(ascending=False).index[:3]
    top2 = load["PC2"].abs().sort_values(ascending=False).index[:3]
    pcl = "PC" if i18n.LANG == "en" else "CP"
    if i18n.LANG == "en":
        txt = (f"The first two principal components explained {num(P['cum'][1], 1)}% of the total variance "
               f"({pcl}1 = {num(P['explained'][0], 1)}%; {pcl}2 = {num(P['explained'][1], 1)}%); "
               f"{P['retained']} component(s) had eigenvalue &gt; 1. {pcl}1 was mainly associated with "
               f"{', '.join(trait(t).lower() for t in top1)}, and {pcl}2 with {', '.join(trait(t).lower() for t in top2)}.")
    else:
        txt = (f"Os dois primeiros componentes principais explicaram {num(P['cum'][1], 1)}% da variância total "
               f"({pcl}1 = {num(P['explained'][0], 1)}%; {pcl}2 = {num(P['explained'][1], 1)}%); "
               f"{P['retained']} componente(s) apresentaram autovalor &gt; 1. O {pcl}1 associou-se principalmente a "
               f"{', '.join(trait(t).lower() for t in top1)}, e o {pcl}2 a {', '.join(trait(t).lower() for t in top2)}.")
    E.append(Paragraph(txt, S["body"]))
    E.append(Spacer(1, 3 * mm))
    E.append(KeepTogether([_fig_image(R, "pca", content_w), Paragraph(f"<b>{tr('fig_pca')}.</b>", S["cap"])]))
    step(0.6)

    # ---------------- 5. best model
    if R.clf:
        C = R.clf
        b = C["table"].iloc[0]
        E.append(CondPageBreak(110 * mm))
        E.append(Paragraph(tr("rep_s5"), S["h2"]))
        box = [[Paragraph(f"{tr('best_model')}: {tr(C['best'])}", S["best"])],
               [Paragraph(
                   f"{tr('bacc')}: <b>{num(b['bacc'] * 100, 1)}% ± {num(b['bacc_sd'] * 100, 1)}</b> "
                   f"({tr('ci95')}: {num(b['bacc_lo'] * 100, 1)}–{num(b['bacc_hi'] * 100, 1)}%) · "
                   f"{tr('acc')}: {num(b['acc'] * 100, 1)}% · {tr('f1')}: {num(b['f1'], 3)} · "
                   f"{tr('auc')}: {num(b['auc'], 3)}", S["body"])],
               [Paragraph(
                   f"{tr('chance')}: {num(C['chance'] * 100, 1)}% · {tr('perm_p')}: {fmt_p(C['perm']['p'])} · "
                   f"{tr('validation')}: {tr('cv_desc', f=C['folds'], r=C['repeats'])}", S["small"])]]
        bt = Table(box, colWidths=[content_w])
        bt.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), GREEN_SOFT),
                                ("LINEBEFORE", (0, 0), (0, -1), 3, GREEN),
                                ("LEFTPADDING", (0, 0), (-1, -1), 10), ("TOPPADDING", (0, 0), (-1, 0), 8),
                                ("BOTTOMPADDING", (0, -1), (-1, -1), 8)]))
        E += [bt, Spacer(1, 3 * mm)]
        rows = [[Paragraph(x, S["head"]) for x in [tr("model"), tr("bacc"), tr("acc"), tr("f1"), tr("auc")]]]
        for _, r in C["table"].iterrows():
            st = S["cellb"] if r["model"] == C["best"] else S["cell"]
            rows.append([Paragraph(tr(r["model"]), st),
                         Paragraph(f"{num(r['bacc'] * 100, 1)} ± {num(r['bacc_sd'] * 100, 1)}", st),
                         Paragraph(f"{num(r['acc'] * 100, 1)} ± {num(r['acc_sd'] * 100, 1)}", st),
                         Paragraph(num(r["f1"], 3), st), Paragraph(num(r["auc"], 3), st)])
        E.append(_table(rows, [content_w * w for w in [0.32, 0.19, 0.19, 0.15, 0.15]]))
        ax = C["axes"]
        E.append(Spacer(1, 2 * mm))
        E.append(Paragraph(
            f"{tr('best_model')} — {tr('all_traits')}: {num(ax['full_bacc'] * 100, 1)}% · "
            f"{tr('axes_only')}: {num(ax['axes_bacc'] * 100, 1)}% ({tr('bacc').lower()}).", S["small"]))
        E.append(Spacer(1, 3 * mm))
        E.append(KeepTogether([_fig_image(R, "models", content_w), Paragraph(f"<b>{tr('fig_models')}.</b>", S["cap"])]))
        E.append(Spacer(1, 3 * mm))
        E.append(KeepTogether([_fig_image(R, "cm", content_w), Paragraph(f"<b>{tr('fig_cm')}.</b>", S["cap"])]))
    step(0.78)

    # ---------------- 6. unsupervised
    if R.clus or R.som:
        E.append(CondPageBreak(80 * mm))
        E.append(Paragraph(tr("rep_s6"), S["h2"]))
        if R.clus and R.clus["methods"]:
            rows = [[Paragraph(x, S["head"]) for x in [tr("method"), "k", tr("ari"), tr("silhouette")]]]
            for m, v in R.clus["methods"].items():
                rows.append([Paragraph(tr(m), S["cellb"]), Paragraph(str(R.clus["k_used"]), S["cell"]),
                             Paragraph(num(v["ari"], 3), S["cell"]), Paragraph(num(v["sil"], 3), S["cell"])])
            E.append(_table(rows, [content_w * w for w in [0.4, 0.15, 0.22, 0.23]]))
            E.append(Spacer(1, 3 * mm))
        if R.som:
            so = R.som
            E.append(Paragraph(
                f"{tr('som')}: {tr('som_grid')} {so['side']}×{so['side']} · {tr('qe')} = {num(so['qe'], 3)} · "
                f"{tr('te')} = {num(so['te'], 3)} · χ² = {num(so['chi2'], 1)} · {tr('perm_p')} = {fmt_p(so['p'])} "
                f"({so['nperm']} perm.)", S["body"]))
            E.append(Spacer(1, 3 * mm))
            E.append(KeepTogether([_fig_image(R, "som", content_w), Paragraph(f"<b>{tr('fig_som')}.</b>", S["cap"])]))
    step(0.9)

    # ---------------- 7. summary
    E.append(CondPageBreak(60 * mm))
    E.append(Paragraph(tr("rep_s7"), S["h2"]))
    for line in summary_lines(R):
        E.append(Paragraph("•&nbsp;&nbsp;" + line, S["body"]))
        E.append(Spacer(1, 1.5 * mm))
    if meta.get("notes"):
        E.append(Spacer(1, 3 * mm))
        E.append(Paragraph(f"<b>{tr('rep_notes')}:</b> {meta['notes']}", S["body"]))

    # ---------------- methods
    E.append(Paragraph(tr("rep_s9"), S["h2"]))
    E.append(Paragraph(methods_text(R), S["small"]))
    E.append(Spacer(1, 2 * mm))
    E.append(Paragraph(f"{tr('reference')}: Nobrega, M.A.S. et al. (2026). A simple method for discriminating "
                       f"<i>Schizolobium parahyba</i> (Vell.) Blake (Fabaceae) seeds population by dimensional "
                       f"morphometry and machine learning algorithms. <i>Flora</i>, 153108. "
                       f"https://doi.org/10.1016/j.flora.2026.153108", S["small"]))
    doc.build(E)
    step(1.0)
    return path


def summary_lines(R):
    out = []
    a = R.settings.alpha
    en = i18n.LANG == "en"
    if R.comp is not None:
        sig = [trait(t).lower() for t in R.comp.loc[R.comp.p < a, "trait"]]
        if sig:
            out.append((f"Significant differences between lots were found for {len(sig)} of 9 traits: {', '.join(sig)}."
                        if en else
                        f"Foram encontradas diferenças significativas entre os lotes em {len(sig)} das 9 variáveis: {', '.join(sig)}."))
        else:
            out.append("No trait differed significantly between lots in central tendency." if en else
                       "Nenhuma variável diferiu significativamente entre os lotes quanto à tendência central.")
    # correlation structure contrast
    if len(R.groups) >= 2:
        rs = {g: R.corr[g]["r"].loc["L", "W"] for g in R.groups}
        txt = "; ".join(f"{g}: r = {num(v, 2)}" for g, v in rs.items())
        out.append((f"Length–width correlation by lot — {txt}." if en else
                    f"Correlação comprimento–largura por lote — {txt}."))
    P = R.pca
    out.append((f"PC1 and PC2 jointly explained {num(P['cum'][1], 1)}% of the morphometric variance." if en else
                f"CP1 e CP2 explicaram conjuntamente {num(P['cum'][1], 1)}% da variância morfométrica."))
    if R.clf:
        C = R.clf
        b = C["table"].iloc[0]
        above = C["perm"]["p"] < a if not np.isnan(C["perm"]["p"]) else False
        if en:
            out.append(f"The best classifier was {tr(C['best'])}, with balanced accuracy of {num(b['bacc'] * 100, 1)}% "
                       f"(chance = {num(C['chance'] * 100, 1)}%; permutation p {_pp(C['perm']['p'])}), indicating "
                       f"{'discrimination significantly above chance' if above else 'no discrimination beyond chance'}.")
        else:
            out.append(f"O melhor classificador foi {tr(C['best'])}, com acurácia balanceada de {num(b['bacc'] * 100, 1)}% "
                       f"(acaso = {num(C['chance'] * 100, 1)}%; p de permutação {_pp(C['perm']['p'])}), indicando "
                       f"{'discriminação significativamente superior ao acaso' if above else 'ausência de discriminação além do acaso'}.")
    if R.clus and R.clus["methods"]:
        mx = max(v["ari"] for v in R.clus["methods"].values())
        out.append((f"Unsupervised clustering {'recovered' if mx >= 0.5 else 'did not recover'} the lots as natural groups "
                    f"(maximum ARI = {num(mx, 3)})." if en else
                    f"O agrupamento não supervisionado {'recuperou' if mx >= 0.5 else 'não recuperou'} os lotes como grupos "
                    f"naturais (ARI máximo = {num(mx, 3)})."))
    if R.som and len(R.groups) > 1:
        sp = R.som["p"] < a
        out.append((f"The self-organizing map {'revealed significant' if sp else 'did not reveal'} spatial segregation "
                    f"between lots (permutation p {_pp(R.som['p'])})." if en else
                    f"O mapa auto-organizável {'revelou' if sp else 'não revelou'} segregação espacial "
                    f"{'significativa ' if sp else ''}entre os lotes (p de permutação {_pp(R.som['p'])})."))
    return out


def _pp(p):
    s = fmt_p(p)
    return s if s.startswith("<") else f"= {s}"


def methods_text(R):
    st = R.settings
    if i18n.LANG == "en":
        t = ("Arithmetic and geometric mean diameters, aspect ratio, sphericity index, ellipsoid volume and "
             "surface area were derived from length, width and thickness of each seed. Normality (Shapiro-Wilk) and "
             "homoscedasticity (Levene) guided the choice between parametric (t-test / ANOVA + Tukey HSD) and "
             "non-parametric tests (Mann-Whitney U / Kruskal-Wallis + Holm-adjusted pairwise tests). Pearson "
             "correlations were adjusted by Benjamini-Hochberg FDR. PCA was computed on standardized variables. ")
        if R.clf:
            t += (f"Classifiers were evaluated by stratified {R.clf['folds']}-fold cross-validation repeated "
                  f"{R.clf['repeats']} times with standardization fitted inside each training partition; the best model "
                  f"was selected by balanced accuracy and tested against {R.clf['perm']['n']} label permutations. ")
        if R.som:
            t += (f"A hexagonal self-organizing map ({R.som['side']}×{R.som['side']}) was trained on standardized "
                  f"variables and segregation was assessed by a χ² permutation test ({R.som['nperm']} permutations). ")
        t += f"Significance level α = {st.alpha}."
    else:
        t = ("Os diâmetros médios aritmético e geométrico, a razão de aspecto, o índice de esfericidade, o volume "
             "elipsoidal e a área superficial foram derivados do comprimento, largura e espessura de cada semente. "
             "A normalidade (Shapiro-Wilk) e a homocedasticidade (Levene) orientaram a escolha entre testes "
             "paramétricos (t / ANOVA + Tukey HSD) e não paramétricos (Mann-Whitney U / Kruskal-Wallis + comparações "
             "par a par ajustadas por Holm). As correlações de Pearson foram ajustadas pelo FDR de Benjamini-Hochberg. "
             "A ACP foi realizada sobre variáveis padronizadas. ")
        if R.clf:
            t += (f"Os classificadores foram avaliados por validação cruzada estratificada com {R.clf['folds']} partições "
                  f"repetida {R.clf['repeats']} vezes, com padronização ajustada dentro de cada partição de treino; o "
                  f"melhor modelo foi selecionado pela acurácia balanceada e testado contra {R.clf['perm']['n']} "
                  f"permutações dos rótulos. ")
        if R.som:
            t += (f"Um mapa auto-organizável hexagonal ({R.som['side']}×{R.som['side']}) foi treinado com as variáveis "
                  f"padronizadas e a segregação foi avaliada por teste de permutação do χ² ({R.som['nperm']} permutações). ")
        t += f"Nível de significância α = {num(st.alpha, 2)}."
    return t
