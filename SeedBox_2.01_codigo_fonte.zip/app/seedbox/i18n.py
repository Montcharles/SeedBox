"""Interface strings (English / Português)."""

LANG = "pt"

S = {
    # ---- general / navigation
    "app_sub": ("Dimensional Morphometry", "Morfometria Dimensional"),
    "nav_data": ("Data", "Dados"),
    "nav_overview": ("Overview", "Visão geral"),
    "nav_props": ("Physical properties", "Propriedades físicas"),
    "nav_compare": ("Group comparison", "Comparação de grupos"),
    "nav_multi": ("Multivariate", "Multivariada"),
    "nav_models": ("Classification", "Classificação"),
    "nav_figures": ("Figures", "Figuras"),
    "nav_report": ("Report", "Laudo"),
    "nav_section_input": ("INPUT", "ENTRADA"),
    "nav_section_results": ("RESULTS", "RESULTADOS"),
    "nav_section_output": ("OUTPUT", "SAÍDA"),
    "language": ("Language", "Idioma"),
    "settings": ("Settings", "Configurações"),
    "about": ("About", "Sobre"),
    "run": ("Run analysis", "Executar análise"),
    "running": ("Analysing…", "Analisando…"),
    "ready": ("Ready", "Pronto"),
    "no_results": ("Run the analysis to view results.", "Execute a análise para visualizar os resultados."),
    "no_results_title": ("No results yet", "Ainda não há resultados"),
    "cancel": ("Cancel", "Cancelar"),
    "ok": ("OK", "OK"),
    "close": ("Close", "Fechar"),
    "save": ("Save", "Salvar"),
    "error": ("Error", "Erro"),
    "warning": ("Attention", "Atenção"),
    "done": ("Completed", "Concluído"),
    "seeds": ("seeds", "sementes"),
    "groups": ("groups", "grupos"),
    "group": ("Group", "Grupo"),
    "seed": ("Seed", "Semente"),
    "all": ("All", "Todos"),
    "pooled": ("Pooled", "Conjunto"),

    # ---- data page
    "data_title": ("Seed dataset", "Conjunto de dados"),
    "data_sub": ("Import a spreadsheet or type the measurements of each seed lot.",
                 "Importe uma planilha ou digite as medidas de cada lote de sementes."),
    "import_file": ("Import Excel / CSV", "Importar Excel / CSV"),
    "template": ("Download template", "Baixar modelo"),
    "example": ("Example dataset", "Dados de exemplo"),
    "clear": ("Clear", "Limpar"),
    "manual_title": ("Manual entry", "Digitação manual"),
    "n_groups": ("Treatments / populations", "Tratamentos / populações"),
    "n_seeds": ("Seeds per lot", "Sementes por lote"),
    "create_table": ("Create table", "Criar tabela"),
    "group_names": ("Lot names", "Nomes dos lotes"),
    "add_rows": ("Add rows", "Adicionar linhas"),
    "remove_rows": ("Remove selected", "Remover selecionadas"),
    "paste_hint": ("Tip: values can be pasted directly from Excel (Ctrl+V).",
                   "Dica: os valores podem ser colados diretamente do Excel (Ctrl+V)."),
    "summary": ("Summary", "Resumo"),
    "valid_seeds": ("Valid seeds", "Sementes válidas"),
    "lots": ("Lots", "Lotes"),
    "incomplete": ("Incomplete rows", "Linhas incompletas"),
    "axis_order": ("Axis order warnings", "Avisos de ordem dos eixos"),
    "axis_order_tip": ("Seeds where width > length or thickness > width.",
                       "Sementes com largura > comprimento ou espessura > largura."),
    "species": ("Species", "Espécie"),
    "species_ph": ("e.g. Schizolobium parahyba", "ex.: Schizolobium parahyba"),
    "length": ("Length", "Comprimento"),
    "width": ("Width", "Largura"),
    "thickness": ("Thickness", "Espessura"),
    "map_title": ("Column mapping", "Mapeamento de colunas"),
    "map_sub": ("Indicate which columns contain each variable.",
                "Indique quais colunas contêm cada variável."),
    "map_group_none": ("(single lot)", "(lote único)"),
    "map_sheets": ("Use each sheet as a lot", "Usar cada aba como um lote"),
    "import_ok": ("{n} seeds imported in {g} lot(s).", "{n} sementes importadas em {g} lote(s)."),
    "import_fail": ("The file could not be read.", "Não foi possível ler o arquivo."),
    "not_enough": ("At least 3 complete seeds are required.", "São necessárias pelo menos 3 sementes completas."),
    "confirm_clear": ("Discard the current dataset?", "Descartar o conjunto de dados atual?"),
    "lot": ("Lot", "Lote"),
    "sheet": ("Sheet", "Aba"),
    "invalid_cells": ("Invalid values", "Valores inválidos"),
    "per_lot": ("Seeds per lot", "Sementes por lote"),
    "detailed": ("Detailed statistics", "Estatística detalhada"),
    "select_lot": ("Lot", "Lote"),
    "k_suggest": ("Suggested k (silhouette / BIC)", "k sugerido (silhueta / BIC)"),
    "segregation": ("Segregation between lots", "Segregação entre lotes"),
    "yes_sig": ("Significant", "Significativa"),
    "no_sig": ("Not significant", "Não significativa"),
    "export": ("Export", "Exportar"),
    "exports_title": ("Exports", "Exportações"),
    "exports_sub": ("Report, figure archive and complete spreadsheet of results.",
                    "Laudo, pacote de figuras e planilha completa de resultados."),
    "saved_to": ("Saved to", "Salvo em"),
    "above_chance": ("above chance", "acima do acaso"),
    "folds_lbl": ("folds", "partições"),
    "sw_note": ("Shapiro-Wilk p by lot; Levene p across lots.", "p de Shapiro-Wilk por lote; p de Levene entre lotes."),
    "run_first": ("Enter or import data, then run the analysis.", "Insira ou importe os dados e execute a análise."),
    "analysis_done": ("Analysis completed in {s} s.", "Análise concluída em {s} s."),
    "data_changed": ("Data changed — run the analysis again to update the results.",
                     "Os dados foram alterados — execute a análise novamente para atualizar os resultados."),

    # ---- overview
    "ov_title": ("Overview", "Visão geral"),
    "ov_sub": ("Key indicators of the current analysis.", "Principais indicadores da análise atual."),
    "kpi_seeds": ("Seeds analysed", "Sementes analisadas"),
    "kpi_groups": ("Lots compared", "Lotes comparados"),
    "kpi_sig": ("Traits with differences", "Variáveis com diferença"),
    "kpi_pca": ("Variance PC1 + PC2", "Variância CP1 + CP2"),
    "kpi_best": ("Best classifier", "Melhor classificador"),
    "kpi_som": ("SOM segregation", "Segregação SOM"),
    "highlights": ("Highlights", "Destaques"),
    "group_profile": ("Lot profiles (mean ± SD)", "Perfil dos lotes (média ± DP)"),

    # ---- properties
    "props_title": ("Physical properties", "Propriedades físicas"),
    "props_sub": ("Dimensional and derived properties for every seed and lot.",
                  "Propriedades dimensionais e derivadas por semente e por lote."),
    "tab_summary": ("Summary by lot", "Resumo por lote"),
    "tab_seed": ("Per seed", "Por semente"),
    "tab_assum": ("Assumptions", "Pressupostos"),
    "export_xlsx": ("Export Excel", "Exportar Excel"),
    "stat": ("Statistic", "Estatística"),
    "mean": ("Mean", "Média"), "sd": ("SD", "DP"), "se": ("SE", "EP"), "cv": ("CV (%)", "CV (%)"),
    "min": ("Min", "Mín"), "max": ("Max", "Máx"), "median": ("Median", "Mediana"),
    "ci95": ("95% CI", "IC 95%"), "n": ("n", "n"),
    "trait": ("Trait", "Variável"),
    "unit": ("Unit", "Unidade"),
    "shapiro": ("Shapiro-Wilk p", "Shapiro-Wilk p"),
    "levene": ("Levene p", "Levene p"),

    # ---- comparison
    "cmp_title": ("Group comparison", "Comparação de grupos"),
    "cmp_sub": ("Differences between treatments or populations for each trait.",
                "Diferenças entre tratamentos ou populações para cada variável."),
    "test": ("Test", "Teste"),
    "p": ("p-value", "Valor-p"),
    "effect": ("Effect size", "Tamanho de efeito"),
    "result": ("Result", "Resultado"),
    "sig": ("Significant", "Significativo"),
    "ns": ("Not significant", "Não significativo"),
    "pairwise": ("Pairwise comparisons", "Comparações par a par"),
    "single_group": ("Comparison requires at least two lots.", "A comparação requer pelo menos dois lotes."),
    "letters_note": ("Means followed by the same letter do not differ (α = {a}).",
                     "Médias seguidas pela mesma letra não diferem entre si (α = {a})."),
    "t": ("Student t", "t de Student"), "U": ("Mann-Whitney U", "Mann-Whitney U"),
    "F": ("ANOVA F", "ANOVA F"), "H": ("Kruskal-Wallis H", "Kruskal-Wallis H"),

    # ---- multivariate
    "multi_title": ("Multivariate structure", "Estrutura multivariada"),
    "multi_sub": ("Principal components, correlations and natural grouping.",
                  "Componentes principais, correlações e agrupamento natural."),
    "pca": ("Principal components", "Componentes principais"),
    "eigen": ("Eigenvalue", "Autovalor"),
    "explained": ("Explained (%)", "Explicada (%)"),
    "cumulative": ("Cumulative (%)", "Acumulada (%)"),
    "loadings": ("Loadings", "Cargas"),
    "corr": ("Correlations", "Correlações"),
    "clustering": ("Unsupervised grouping", "Agrupamento não supervisionado"),
    "method": ("Method", "Método"),
    "ari": ("ARI vs lots", "ARI vs lotes"),
    "silhouette": ("Silhouette", "Silhueta"),
    "kmeans": ("k-means", "k-means"),
    "ward": ("Hierarchical (Ward)", "Hierárquico (Ward)"),
    "gmm": ("Gaussian mixture", "Mistura gaussiana"),
    "som": ("Self-organizing map", "Mapa auto-organizável"),
    "som_grid": ("Grid", "Grade"),
    "qe": ("Quantization error", "Erro de quantização"),
    "te": ("Topographic error", "Erro topográfico"),
    "perm_p": ("Permutation p", "p de permutação"),
    "corr_group": ("Lot", "Lote"),

    # ---- models
    "mdl_title": ("Classification models", "Modelos de classificação"),
    "mdl_sub": ("Discrimination of lots from morphometric traits.",
                "Discriminação dos lotes a partir das variáveis morfométricas."),
    "best_model": ("Best model", "Melhor modelo"),
    "model": ("Model", "Modelo"),
    "acc": ("Accuracy", "Acurácia"),
    "bacc": ("Balanced accuracy", "Acurácia balanceada"),
    "f1": ("F1-score", "F1-score"),
    "auc": ("ROC-AUC", "ROC-AUC"),
    "chance": ("Chance level", "Nível do acaso"),
    "axes_only": ("Three axes only", "Somente três eixos"),
    "all_traits": ("All nine traits", "Todas as nove variáveis"),
    "validation": ("Validation", "Validação"),
    "cv_desc": ("{f}-fold × {r} repetitions", "{f} partições × {r} repetições"),
    "no_models": ("Classification requires at least two lots with ≥ 4 seeds each.",
                  "A classificação requer pelo menos dois lotes com ≥ 4 sementes cada."),
    "lr": ("Logistic regression", "Regressão logística"),
    "lda": ("Linear discriminant", "Discriminante linear"),
    "qda": ("Quadratic discriminant", "Discriminante quadrático"),
    "svm_lin": ("SVM (linear)", "SVM (linear)"),
    "svm_rbf": ("SVM (RBF)", "SVM (RBF)"),
    "knn": ("k-NN (k = 5)", "k-NN (k = 5)"),
    "rf": ("Random forest", "Floresta aleatória"),
    "gb": ("Gradient boosting", "Gradient boosting"),

    # ---- figures
    "fig_title": ("Figures", "Figuras"),
    "fig_sub": ("Publication-quality figures, ready to export.",
                "Figuras com qualidade de publicação, prontas para exportar."),
    "save_fig": ("Save figure", "Salvar figura"),
    "export_zip": ("Export all (ZIP)", "Exportar todas (ZIP)"),
    "resolution": ("Resolution", "Resolução"),
    "formats": ("Formats", "Formatos"),
    "zip_ok": ("{n} files exported.", "{n} arquivos exportados."),
    "exporting": ("Exporting figures…", "Exportando figuras…"),
    "fig_hist": ("Frequency distributions", "Distribuições de frequência"),
    "fig_box": ("Trait distributions by lot", "Distribuição das variáveis por lote"),
    "fig_scatter": ("Dimensional relationships", "Relações dimensionais"),
    "fig_shape": ("Shape space", "Espaço de forma"),
    "fig_corr": ("Correlation matrices", "Matrizes de correlação"),
    "fig_pca": ("Principal component analysis", "Análise de componentes principais"),
    "fig_models": ("Classifier performance", "Desempenho dos classificadores"),
    "fig_cm": ("Best model diagnostics", "Diagnóstico do melhor modelo"),
    "fig_clus": ("Cluster validation", "Validação de agrupamentos"),
    "fig_som": ("Self-organizing map", "Mapa auto-organizável"),
    "fig_planes": ("SOM component planes", "Planos de componentes do SOM"),

    # ---- report
    "rep_title": ("Analysis report", "Laudo de análise"),
    "rep_sub": ("Generate a PDF report with the main results and figures.",
                "Gere um laudo em PDF com os principais resultados e figuras."),
    "rep_info": ("Report information", "Informações do laudo"),
    "rep_project": ("Project / experiment", "Projeto / experimento"),
    "rep_analyst": ("Analyst", "Responsável"),
    "rep_inst": ("Institution / laboratory", "Instituição / laboratório"),
    "rep_notes": ("Notes", "Observações"),
    "rep_sections": ("Sections", "Seções"),
    "rep_gen": ("Generate PDF report", "Gerar laudo em PDF"),
    "rep_ok": ("Report saved.", "Laudo salvo."),
    "rep_open": ("Open", "Abrir"),
    "rep_doc_title": ("Seed Morphometry Report", "Laudo de Morfometria de Sementes"),
    "rep_date": ("Date", "Data"),
    "rep_dataset": ("Dataset", "Conjunto de dados"),
    "rep_s1": ("1. Sample description", "1. Descrição da amostra"),
    "rep_s2": ("2. Physical properties", "2. Propriedades físicas"),
    "rep_s3": ("3. Comparison between lots", "3. Comparação entre lotes"),
    "rep_s4": ("4. Multivariate structure", "4. Estrutura multivariada"),
    "rep_s5": ("5. Classification — best model", "5. Classificação — melhor modelo"),
    "rep_s6": ("6. Unsupervised structure", "6. Estrutura não supervisionada"),
    "rep_s7": ("7. Summary", "7. Síntese"),
    "rep_s8": ("Figures", "Figuras"),
    "rep_s9": ("Methods", "Métodos"),
    "rep_page": ("Page", "Página"),
    "rep_conf": ("Confusion matrix", "Matriz de confusão"),

    # ---- settings dialog
    "set_title": ("Analysis settings", "Configurações da análise"),
    "set_alpha": ("Significance level (α)", "Nível de significância (α)"),
    "set_folds": ("Cross-validation folds", "Partições da validação cruzada"),
    "set_reps": ("Cross-validation repetitions", "Repetições da validação cruzada"),
    "set_seed": ("Random seed", "Semente aleatória"),
    "set_perm": ("Permutations", "Permutações"),
    "set_som": ("SOM grid (0 = automatic)", "Grade do SOM (0 = automática)"),
    "set_iter": ("SOM iterations", "Iterações do SOM"),
    "set_ml": ("Classification models", "Modelos de classificação"),
    "set_somrun": ("Self-organizing map", "Mapa auto-organizável"),
    "auto": ("Automatic", "Automática"),

    # ---- progress
    "pg_props": ("Computing physical properties", "Calculando propriedades físicas"),
    "pg_desc": ("Descriptive statistics", "Estatística descritiva"),
    "pg_compare": ("Comparing lots", "Comparando lotes"),
    "pg_corr": ("Correlation structure", "Estrutura de correlação"),
    "pg_pca": ("Principal components", "Componentes principais"),
    "pg_ml": ("Training classifiers", "Treinando classificadores"),
    "pg_clus": ("Unsupervised grouping", "Agrupamento não supervisionado"),
    "pg_som": ("Self-organizing map", "Mapa auto-organizável"),
    "pg_done": ("Finishing", "Finalizando"),

    # ---- about
    "about_text": ("Software for dimensional seed morphometry: physical properties, "
                   "comparison of treatments and populations, multivariate analysis and classification.",
                   "Software de morfometria dimensional de sementes: propriedades físicas, "
                   "comparação de tratamentos e populações, análise multivariada e classificação."),
    "reference": ("Reference", "Referência"),
    "version": ("Version", "Versão"),
}

TRAIT_NAMES = {
    "L": ("Length", "Comprimento"),
    "W": ("Width", "Largura"),
    "T": ("Thickness", "Espessura"),
    "Da": ("Arithmetic mean diameter", "Diâmetro médio aritmético"),
    "Dg": ("Geometric mean diameter", "Diâmetro médio geométrico"),
    "R": ("Aspect ratio", "Razão de aspecto"),
    "Phi": ("Sphericity index", "Índice de esfericidade"),
    "V": ("Volume", "Volume"),
    "S": ("Surface area", "Área superficial"),
}
TRAIT_SYM = {"L": "L", "W": "W", "T": "T", "Da": "Da", "Dg": "Dg", "R": "R", "Phi": "Φ", "V": "V", "S": "S"}
TRAIT_SYM_PT = {"L": "C", "W": "La", "T": "E", "Da": "Da", "Dg": "Dg", "R": "R", "Phi": "Φ", "V": "V", "S": "S"}


def set_lang(code):
    global LANG
    LANG = code


def tr(key, **kw):
    v = S.get(key)
    if v is None:
        return key
    s = v[0] if LANG == "en" else v[1]
    return s.format(**kw) if kw else s


def trait(key, short=False):
    if short:
        return (TRAIT_SYM if LANG == "en" else TRAIT_SYM_PT)[key]
    v = TRAIT_NAMES[key]
    return v[0] if LANG == "en" else v[1]


def trait_label(key):
    from .core import UNITS
    return f"{trait(key)} ({UNITS[key]})"


def fmt_p(p):
    import math
    if p is None or (isinstance(p, float) and math.isnan(p)):
        return "—"
    if p < 0.001:
        return "< 0.001"
    s = f"{p:.3f}"
    return s if LANG == "en" else s.replace(".", ",")


def num(x, d=2):
    import math
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "—"
    s = f"{x:,.{d}f}"
    if LANG == "pt":
        s = s.replace(",", "§").replace(".", ",").replace("§", ".")
    return s
