import os

BASE = os.path.dirname(os.path.abspath(__file__))


def asset(*p):
    return os.path.join(BASE, "assets", *p)


def user_dir():
    root = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(root, "SeedBox")
    os.makedirs(d, exist_ok=True)
    return d
