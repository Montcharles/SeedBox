"""Bindings to the C++ computation core (seedbox_core)."""
import ctypes
import os
import sys
import numpy as np

_lib = None
_P = ctypes.POINTER(ctypes.c_double)
_I = ctypes.POINTER(ctypes.c_int64)


def _load():
    global _lib
    if _lib is not None:
        return _lib or None
    here = os.path.dirname(os.path.abspath(__file__))
    name = "seedbox_core.dll" if sys.platform == "win32" else "libseedbox_core.so"
    path = os.path.join(here, name)
    try:
        lib = ctypes.CDLL(path)
        lib.sb_version.restype = ctypes.c_int
        lib.sb_physical.argtypes = [ctypes.c_int] + [_P] * 9
        lib.sb_som_train.argtypes = [ctypes.c_int, ctypes.c_int, _P, ctypes.c_int, _P, _P, ctypes.c_int,
                                     ctypes.c_double, ctypes.c_double, _I]
        lib.sb_bmu.argtypes = [ctypes.c_int, ctypes.c_int, _P, ctypes.c_int, _P, _I, _I]
        lib.sb_bmu.restype = ctypes.c_double
        lib.sb_chi2_perm.argtypes = [ctypes.c_int, _I, _I, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                     ctypes.c_uint64, _P]
        lib.sb_chi2_perm.restype = ctypes.c_double
        lib.sb_version()
        _lib = lib
    except Exception:
        _lib = False
    return _lib or None


def available():
    return _load() is not None


def _d(a):
    return np.ascontiguousarray(a, dtype=np.float64)


def _ptr(a, t=_P):
    return a.ctypes.data_as(t)


def physical(L, W, T):
    lib = _load()
    L, W, T = _d(L), _d(W), _d(T)
    n = len(L)
    outs = [np.empty(n) for _ in range(6)]
    lib.sb_physical(n, _ptr(L), _ptr(W), _ptr(T), *[_ptr(o) for o in outs])
    return dict(zip(["Da", "Dg", "R", "Phi", "V", "S"], outs))


def som_train(X, W, D2, idx, lr0, sigma0):
    lib = _load()
    X, D2 = _d(X), _d(D2)
    W = _d(W).copy()
    idx = np.ascontiguousarray(idx, dtype=np.int64)
    lib.sb_som_train(X.shape[0], X.shape[1], _ptr(X), W.shape[0], _ptr(W), _ptr(D2), len(idx),
                     float(lr0), float(sigma0), _ptr(idx, _I))
    return W


def bmu(X, W):
    lib = _load()
    X, W = _d(X), _d(W)
    b1 = np.empty(len(X), np.int64)
    b2 = np.empty(len(X), np.int64)
    qe = lib.sb_bmu(X.shape[0], X.shape[1], _ptr(X), W.shape[0], _ptr(W), _ptr(b1, _I), _ptr(b2, _I))
    return b1, b2, qe


def chi2_perm(units, labels, n_units, n_groups, n_perm, seed):
    lib = _load()
    u = np.ascontiguousarray(units, np.int64)
    l = np.ascontiguousarray(labels, np.int64)
    out = np.empty(n_perm)
    obs = lib.sb_chi2_perm(len(u), _ptr(u, _I), _ptr(l, _I), int(n_units), int(n_groups), int(n_perm),
                           int(seed), _ptr(out))
    return obs, out
