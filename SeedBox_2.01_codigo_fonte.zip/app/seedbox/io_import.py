"""Spreadsheet import with automatic column recognition."""
import re
import unicodedata
import pandas as pd

KEYS = {
    "group": ["group", "grupo", "treatment", "tratamento", "trat", "population", "populacao", "pop", "lote", "lot",
              "area", "sample area", "amostra", "origem", "origin", "procedencia", "site", "local", "matriz",
              "especie", "species", "sample", "genotipo", "genotype", "acesso"],
    "seed": ["seed", "semente", "id", "n", "no", "numero", "rep", "repeticao", "replicate", "individuo"],
    "L": ["length", "comprimento", "comp", "c", "l", "a", "major axis", "eixo maior", "len", "compr"],
    "W": ["width", "largura", "larg", "w", "b", "intermediate axis", "eixo intermediario", "lar", "wid"],
    "T": ["thickness", "espessura", "esp", "t", "e", "minor axis", "eixo menor", "thick", "esps", "altura", "height"],
}


def _norm(s):
    s = str(s).strip().lower()
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"\(.*?\)|\[.*?\]", "", s)
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def read_any(path):
    p = path.lower()
    if p.endswith((".xlsx", ".xlsm", ".xls")):
        sheets = pd.read_excel(path, sheet_name=None)
        return {k: v.dropna(how="all").dropna(axis=1, how="all") for k, v in sheets.items() if not v.dropna(how="all").empty}
    # text
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "latin-1"):
        try:
            txt = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    first = txt.splitlines()[0] if txt else ""
    sep = ";" if first.count(";") > first.count(",") else ("\t" if "\t" in first else ",")
    import io
    df = pd.read_csv(io.StringIO(txt), sep=sep, dtype=str)
    return {"data": df.dropna(how="all")}


def _is_numeric(s):
    v = pd.to_numeric(s.astype(str).str.replace(",", ".", regex=False), errors="coerce")
    return v.notna().mean() > 0.8


def auto_map(df):
    cols = list(df.columns)
    normed = {c: _norm(c) for c in cols}
    found = {}
    for key in ["L", "W", "T", "group", "seed"]:
        best = None
        for c in cols:
            if c in found.values():
                continue
            n = normed[c]
            for cand in KEYS[key]:
                if n == cand or n.startswith(cand + " ") or (len(cand) > 3 and cand in n):
                    best = c
                    break
            if best:
                break
        if best is not None:
            found[key] = best
    ok = all(k in found for k in ["L", "W", "T"]) and all(_is_numeric(df[found[k]]) for k in ["L", "W", "T"])
    return found, ok


def to_long(df, mapping, group_name=None):
    out = pd.DataFrame()
    if mapping.get("group") and mapping["group"] in df.columns:
        out["group"] = df[mapping["group"]].astype(str).str.strip()
    else:
        out["group"] = group_name or "1"
    for k in ["L", "W", "T"]:
        out[k] = pd.to_numeric(df[mapping[k]].astype(str).str.replace(",", ".", regex=False).str.strip(),
                               errors="coerce")
    if mapping.get("seed") and mapping["seed"] in df.columns:
        out["seed"] = df[mapping["seed"]].values
    return out.reset_index(drop=True)


def load(path):
    """Return (long_df | None, sheets, mapping_guess). None means manual mapping is needed."""
    sheets = read_any(path)
    names = list(sheets)
    # single table with recognisable columns
    if len(names) == 1:
        df = sheets[names[0]]
        m, ok = auto_map(df)
        return (to_long(df, m, None if m.get("group") else "1") if ok else None), sheets, m
    # several sheets: if every sheet maps and none has a group column -> sheets are lots
    maps = {n: auto_map(sheets[n]) for n in names}
    if all(ok for _, ok in maps.values()):
        has_group = any(m.get("group") for m, _ in maps.values())
        parts = []
        for n in names:
            m, _ = maps[n]
            parts.append(to_long(sheets[n], m, None if has_group and m.get("group") else n))
        return pd.concat(parts, ignore_index=True), sheets, maps[names[0]][0]
    first = names[0]
    return None, sheets, maps[first][0]
