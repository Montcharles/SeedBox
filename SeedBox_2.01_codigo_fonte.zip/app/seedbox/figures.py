"""Publication-quality figures."""
from __future__ import annotations

import io
import numpy as np
import matplotlib
matplotlib.use("Agg")
from matplotlib.figure import Figure
from matplotlib.patches import Ellipse, RegularPolygon
from matplotlib import colors as mcolors
from matplotlib import font_manager as fm
from scipy import stats

from .core import TRAITS, AXES, UNITS
from . import i18n
from .i18n import tr, trait, trait_label

PALETTE = ["#3B75AF", "#D1495B", "#2A9D8F", "#E9A23B", "#7B5EA7", "#5C946E", "#C2185B", "#607D8B",
           "#8D6E63", "#00838F"]
INK = "#1F2A33"
MUTED = "#6B7A86"
GRID = "#E3E8EC"


def setup_style():
    fams = {f.name for f in fm.fontManager.ttflist}
    family = next((f for f in ["Arial", "Liberation Sans", "Helvetica", "DejaVu Sans"] if f in fams), "DejaVu Sans")
    matplotlib.rcParams.update({
        "font.family": "sans-serif", "font.sans-serif": [family, "DejaVu Sans"],
        "font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9, "xtick.labelsize": 8,
        "ytick.labelsize": 8, "legend.fontsize": 8, "axes.edgecolor": INK, "axes.labelcolor": INK,
        "xtick.color": INK, "ytick.color": INK, "axes.linewidth": 0.8, "axes.spines.top": False,
        "axes.spines.right": False, "xtick.major.width": 0.8, "ytick.major.width": 0.8,
        "legend.frameon": False, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
        "mathtext.default": "regular", "axes.titleweight": "bold", "figure.dpi": 100,
        "axes.formatter.use_locale": False, "pdf.fonttype": 42, "svg.fonttype": "none",
    })


setup_style()


def gcolor(i):
    return PALETTE[i % len(PALETTE)]


def _panel(ax, i, x=-0.13, y=1.06):
    ax.text(x, y, f"({chr(65 + i)})", transform=ax.transAxes, fontsize=10, fontweight="bold",
            va="bottom", ha="left", color=INK)


def _dec(fig):
    """Use decimal comma in Portuguese."""
    if i18n.LANG != "pt":
        return
    from matplotlib.ticker import FuncFormatter

    def f(x, pos):
        s = f"{x:g}"
        return s.replace(".", ",")
    for ax in fig.axes:
        if getattr(ax, "_keep_ticks", False):
            continue
        try:
            if ax.xaxis.get_scale() == "linear" and not getattr(ax, "_cat_x", False):
                ax.xaxis.set_major_formatter(FuncFormatter(f))
            if ax.yaxis.get_scale() == "linear" and not getattr(ax, "_cat_y", False):
                ax.yaxis.set_major_formatter(FuncFormatter(f))
        except Exception:
            pass


def _ellipse(ax, x, y, color, n_std=2.4477, **kw):
    if len(x) < 3:
        return
    cov = np.cov(x, y)
    vals, vecs = np.linalg.eigh(cov)
    order = vals.argsort()[::-1]
    vals, vecs = vals[order], vecs[:, order]
    ang = np.degrees(np.arctan2(*vecs[:, 0][::-1]))
    w, h = 2 * n_std * np.sqrt(np.clip(vals, 0, None))
    ax.add_patch(Ellipse((x.mean(), y.mean()), w, h, angle=ang, facecolor=mcolors.to_rgba(color, 0.10),
                         edgecolor=color, lw=1.1, **kw))


# --------------------------------------------------------------------------
def fig_hist(R):
    G = R.groups
    nG = len(G)
    fig = Figure(figsize=(3.0 * min(nG, 4) + 0.6, 2.35 * 3), layout="constrained")
    ncol = min(nG, 4)
    if nG > 4:
        # overlay mode for many groups
        fig = Figure(figsize=(10, 3.2), layout="constrained")
        axs = fig.subplots(1, 3)
        for k, t in enumerate(AXES):
            ax = axs[k]
            lo, hi = R.props[t].min(), R.props[t].max()
            bins = np.linspace(lo, hi, 16)
            for i, g in enumerate(G):
                x = R.props.loc[R.props.group == g, t]
                ax.hist(x, bins=bins, histtype="step", lw=1.4, color=gcolor(i), label=g)
            ax.set_xlabel(trait_label(t))
            ax.set_ylabel(tr_freq())
            _panel(ax, k)
        axs[-1].legend(loc="upper left", bbox_to_anchor=(1, 1))
        _dec(fig)
        return fig
    axs = fig.subplots(3, ncol, squeeze=False)
    k = 0
    for r, t in enumerate(AXES):
        lo, hi = R.props[t].min(), R.props[t].max()
        bins = np.histogram_bin_edges(R.props[t], bins="sturges")
        ymax = 0
        for c, g in enumerate(G):
            ax = axs[r, c]
            x = R.props.loc[R.props.group == g, t].to_numpy()
            nh, _, _ = ax.hist(x, bins=bins, color=gcolor(c), edgecolor="white", lw=0.6, alpha=0.92)
            ymax = max(ymax, nh.max())
            m, s = x.mean(), x.std(ddof=1) if len(x) > 1 else 0
            ax.axvline(m, color=INK, ls="--", lw=1.1)
            ax.axvline(m - s, color=MUTED, ls=":", lw=0.9)
            ax.axvline(m + s, color=MUTED, ls=":", lw=0.9)
            ax.set_xlabel(trait_label(t))
            if c == 0:
                ax.set_ylabel(tr_freq())
            ax.set_title(g, loc="left", fontsize=9)
            _panel(ax, k)
            k += 1
        for c in range(ncol):
            axs[r, c].set_ylim(0, ymax * 1.12)
            axs[r, c].set_xlim(bins[0] - (bins[1] - bins[0]), bins[-1] + (bins[1] - bins[0]))
    _dec(fig)
    return fig


def tr_freq():
    return "Frequency" if i18n.LANG == "en" else "Frequência"


def fig_box(R):
    G = R.groups
    fig = Figure(figsize=(10.5, 8.2), layout="constrained")
    axs = fig.subplots(3, 3).ravel()
    rng = np.random.default_rng(1)
    for k, t in enumerate(TRAITS):
        ax = axs[k]
        data = [R.props.loc[R.props.group == g, t].to_numpy() for g in G]
        pos = np.arange(len(G))
        vp = ax.violinplot(data, positions=pos, widths=0.8, showextrema=False)
        for i, b in enumerate(vp["bodies"]):
            b.set_facecolor(mcolors.to_rgba(gcolor(i), 0.18))
            b.set_edgecolor(mcolors.to_rgba(gcolor(i), 0.5))
            b.set_linewidth(0.6)
        bp = ax.boxplot(data, positions=pos, widths=0.28, patch_artist=True, showfliers=False,
                        medianprops=dict(color=INK, lw=1.2), whiskerprops=dict(color=INK, lw=0.8),
                        capprops=dict(color=INK, lw=0.8), boxprops=dict(lw=0.8, edgecolor=INK))
        for i, b in enumerate(bp["boxes"]):
            b.set_facecolor(mcolors.to_rgba(gcolor(i), 0.75))
        for i, d in enumerate(data):
            ax.scatter(pos[i] + rng.uniform(-0.2, 0.2, len(d)), d, s=5, color=gcolor(i), alpha=0.45, lw=0, zorder=3)
            ax.scatter(pos[i], d.mean(), marker="D", s=16, color="white", edgecolor=INK, lw=0.8, zorder=4)
        ax.set_xticks(pos)
        ax.set_xticklabels(G, rotation=20 if len(G) > 3 else 0, ha="right" if len(G) > 3 else "center")
        ax._cat_x = True
        ax.set_ylabel(f"{trait(t)} ({UNITS[t]})")
        if R.comp is not None:
            row = R.comp[R.comp.trait == t].iloc[0]
            top = max(d.max() for d in data)
            span = top - min(d.min() for d in data)
            for i, g in enumerate(G):
                ax.text(pos[i], top + 0.06 * span, row[f"letter_{g}"], ha="center", va="bottom",
                        fontsize=8.5, fontweight="bold", color=INK)
            ax.set_ylim(top=top + 0.2 * span)
            ax.set_title(f"p {_pfmt(row['p'])}", loc="right", fontsize=8, color=MUTED, fontweight="normal")
        _panel(ax, k, x=-0.2)
    _dec(fig)
    return fig


def _pfmt(p):
    s = i18n.fmt_p(p)
    return s if s.startswith("<") else f"= {s}"


def fig_scatter(R):
    G = R.groups
    pairs = [("L", "W"), ("L", "T"), ("W", "T"), ("L", "Dg")]
    fig = Figure(figsize=(8.4, 7.2), layout="constrained")
    axs = fig.subplots(2, 2).ravel()
    for k, (a, b) in enumerate(pairs):
        ax = axs[k]
        for i, g in enumerate(G):
            sub = R.props[R.props.group == g]
            x, y = sub[a].to_numpy(), sub[b].to_numpy()
            ax.scatter(x, y, s=14, color=gcolor(i), alpha=0.6, lw=0, label=g)
            if len(x) > 2 and np.std(x) > 0:
                lr = stats.linregress(x, y)
                xx = np.linspace(x.min(), x.max(), 50)
                ax.plot(xx, lr.intercept + lr.slope * xx, color=gcolor(i), lw=1.6)
                ax.text(0.02, 0.97 - 0.07 * i, f"{g}: r = {i18n.num(lr.rvalue, 2)}", transform=ax.transAxes,
                        fontsize=7.5, color=gcolor(i), va="top")
        ax.set_xlabel(trait_label(a))
        ax.set_ylabel(trait_label(b))
        _panel(ax, k)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="outside upper center", ncol=min(len(G), 5), markerscale=1.6)
    _dec(fig)
    return fig


def fig_shape(R):
    G = R.groups
    fig = Figure(figsize=(8.6, 3.8), layout="constrained")
    ax1, ax2 = fig.subplots(1, 2)
    for i, g in enumerate(G):
        sub = R.props[R.props.group == g]
        ax1.scatter(sub["R"], sub["Phi"], s=14, color=gcolor(i), alpha=0.6, lw=0, label=g)
        _ellipse(ax1, sub["R"].to_numpy(), sub["Phi"].to_numpy(), gcolor(i))
        ax2.scatter(sub["Dg"], sub["Phi"], s=14, color=gcolor(i), alpha=0.6, lw=0, label=g)
        _ellipse(ax2, sub["Dg"].to_numpy(), sub["Phi"].to_numpy(), gcolor(i))
    ax1.set_xlabel(trait_label("R"))
    ax1.set_ylabel(trait_label("Phi"))
    ax2.set_xlabel(trait_label("Dg"))
    ax2.set_ylabel(trait_label("Phi"))
    _panel(ax1, 0)
    _panel(ax2, 1)
    ax2.legend(loc="upper left")
    _dec(fig)
    return fig


def fig_corr(R):
    keys = R.groups + (["__all__"] if len(R.groups) > 1 else [])
    keys = keys[:6]
    n = len(keys)
    ncol = min(n, 3)
    nrow = int(np.ceil(n / ncol))
    fig = Figure(figsize=(4.1 * ncol + 0.6, 3.9 * nrow), layout="constrained")
    axs = np.atleast_1d(fig.subplots(nrow, ncol)).ravel()
    labels = [trait(t, short=True) for t in TRAITS]
    im = None
    for k, g in enumerate(keys):
        ax = axs[k]
        c = R.corr[g]
        M = c["r"].to_numpy()
        Q = c["q"].to_numpy()
        mask = np.triu(np.ones_like(M, bool), 0)
        Mm = np.ma.array(M, mask=mask)
        im = ax.imshow(Mm, cmap="RdBu_r", vmin=-1, vmax=1)
        for i in range(len(TRAITS)):
            for j in range(i + 1):
                if i == j:
                    continue
                v = M[i, j]
                star = "*" if Q[i, j] < 0.05 else ""
                ax.text(j, i, f"{i18n.num(v, 2)}{star}", ha="center", va="center", fontsize=6.3,
                        color="white" if abs(v) > 0.6 else INK)
        ax.set_xticks(range(len(TRAITS)))
        ax.set_yticks(range(len(TRAITS)))
        ax.set_xticklabels(labels)
        ax.set_yticklabels(labels)
        ax._cat_x = ax._cat_y = True
        for s in ax.spines.values():
            s.set_visible(False)
        ax.tick_params(length=0)
        ax.set_title(tr("pooled") if g == "__all__" else g, loc="left")
        _panel(ax, k, x=-0.1, y=1.02)
    for ax in axs[n:]:
        ax.set_visible(False)
    cb = fig.colorbar(im, ax=list(axs[:n]), shrink=0.7, pad=0.02)
    cb.set_label("Pearson r")
    cb.outline.set_visible(False)
    return fig


def fig_pca(R):
    P = R.pca
    G = R.groups
    fig = Figure(figsize=(10.2, 4.3), layout="constrained")
    gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 1.0, 0.85])
    ax = fig.add_subplot(gs[0])
    sc = P["scores"]
    for i, g in enumerate(G):
        m = P["groups"] == g
        ax.scatter(sc[m, 0], sc[m, 1], s=14, color=gcolor(i), alpha=0.65, lw=0, label=g)
        _ellipse(ax, sc[m, 0], sc[m, 1], gcolor(i))
    ax.axhline(0, color=GRID, lw=0.8, zorder=0)
    ax.axvline(0, color=GRID, lw=0.8, zorder=0)
    pcl = "PC" if i18n.LANG == "en" else "CP"
    ax.set_xlabel(f"{pcl}1 ({i18n.num(P['explained'][0], 1)}%)")
    ax.set_ylabel(f"{pcl}2 ({i18n.num(P['explained'][1], 1)}%)")
    ax.legend(loc="best", markerscale=1.5)
    _panel(ax, 0)
    # loadings circle
    ax2 = fig.add_subplot(gs[1])
    L = P["loadings"].to_numpy()
    th = np.linspace(0, 2 * np.pi, 200)
    ax2.plot(np.cos(th), np.sin(th), color=MUTED, lw=0.8)
    ax2.axhline(0, color=GRID, lw=0.8)
    ax2.axvline(0, color=GRID, lw=0.8)
    clusters = []
    for k, t in enumerate(TRAITS):
        ax2.annotate("", xy=(L[k, 0], L[k, 1]), xytext=(0, 0),
                     arrowprops=dict(arrowstyle="-|>", color="#1684C4" if t in AXES else "#2EA043", lw=1.1))
        for cl in clusters:
            if np.hypot(*(L[cl[0], :2] - L[k, :2])) < 0.12:
                cl.append(k)
                break
        else:
            clusters.append([k])
    for cl in clusters:
        x, y = L[cl, 0].mean(), L[cl, 1].mean()
        r = max(np.hypot(x, y), 1e-6)
        lab = ", ".join(trait(TRAITS[k], short=True) for k in cl)
        ax2.text(x + 0.14 * x / r, y + 0.14 * y / r, lab, ha="left" if x > 0.3 else ("right" if x < -0.3 else "center"),
                 va="center", fontsize=8, color=INK)
    ax2.set_xlim(-1.2, 1.2)
    ax2.set_ylim(-1.2, 1.2)
    ax2.set_aspect("equal")
    ax2.set_xlabel(f"{pcl}1")
    ax2.set_ylabel(f"{pcl}2")
    _panel(ax2, 1, x=-0.18)
    # scree
    ax3 = fig.add_subplot(gs[2])
    k = np.arange(1, len(P["eigen"]) + 1)
    ax3.bar(k, P["explained"], color="#9FC5E0", edgecolor="#1684C4", lw=0.7)
    ax3.plot(k, P["cum"], "-o", color=INK, ms=3.5, lw=1.1)
    ax3.axhline(80, color=MUTED, ls=":", lw=0.8)
    ax3.set_xticks(k)
    ax3._cat_x = True
    ax3.set_xlabel(pcl)
    ax3.set_ylabel(tr("explained"))
    ax3.set_ylim(0, 105)
    _panel(ax3, 2, x=-0.25)
    _dec(fig)
    return fig


def fig_models(R):
    C = R.clf
    T = C["table"].iloc[::-1]
    fig = Figure(figsize=(9.6, 4.0), layout="constrained")
    ax, ax2 = fig.subplots(1, 2, gridspec_kw=dict(width_ratios=[1.25, 1]))
    y = np.arange(len(T))
    cols = ["#2EA043" if m == C["best"] else "#9FB3C2" for m in T["model"]]
    ax.barh(y, T["bacc"] * 100, color=cols, height=0.62)
    ax.errorbar(T["bacc"] * 100, y, xerr=[(T["bacc"] - T["bacc_lo"]) * 100, (T["bacc_hi"] - T["bacc"]) * 100],
                fmt="none", ecolor=INK, lw=0.9, capsize=2.5)
    ax.axvline(C["chance"] * 100, color="#D1495B", ls="--", lw=1)
    ax.text(C["chance"] * 100, len(T) - 0.35, tr("chance"), color="#D1495B", fontsize=7.5, ha="left", va="bottom")
    ax.set_yticks(y)
    ax.set_yticklabels([tr(m) for m in T["model"]])
    ax._cat_y = True
    ax.set_xlabel(f"{tr('bacc')} (%)")
    ax.set_xlim(0, 100)
    for yi, v in zip(y, T["bacc"]):
        ax.text(1.5, yi, f"{i18n.num(v * 100, 1)}", va="center", fontsize=7.5, color="white", fontweight="bold")
    _panel(ax, 0, x=-0.38)
    # distributions of fold scores
    order = list(T["model"])
    data = [C["raw"][m] * 100 for m in order]
    bp = ax2.boxplot(data, vert=False, patch_artist=True, widths=0.55, showfliers=False,
                     medianprops=dict(color=INK), boxprops=dict(lw=0.8))
    for i, b in enumerate(bp["boxes"]):
        b.set_facecolor("#CDEBD3" if order[i] == C["best"] else "#E3EAF0")
    rng = np.random.default_rng(0)
    for i, d in enumerate(data):
        ax2.scatter(d, i + 1 + rng.uniform(-0.15, 0.15, len(d)), s=4, color=MUTED, alpha=0.6, lw=0)
    ax2.set_yticks(np.arange(1, len(order) + 1))
    ax2.set_yticklabels([])
    ax2._cat_y = True
    ax2.axvline(C["chance"] * 100, color="#D1495B", ls="--", lw=1)
    ax2.set_xlabel(f"{tr('bacc')} — {('folds' if i18n.LANG == 'en' else 'partições')} (%)")
    _panel(ax2, 1, x=-0.05)
    _dec(fig)
    return fig


def fig_cm(R):
    C = R.clf
    G = R.groups
    has_roc = bool(C.get("roc"))
    fig = Figure(figsize=(10.4 if has_roc else 7.2, 3.9), layout="constrained")
    n = 3 if has_roc else 2
    axs = fig.subplots(1, n)
    ax = axs[0]
    cm = C["cm"].astype(float)
    cmn = cm / cm.sum(1, keepdims=True)
    ax.imshow(cmn, cmap="Greens", vmin=0, vmax=1)
    for i in range(len(G)):
        for j in range(len(G)):
            ax.text(j, i, f"{int(cm[i, j])}\n{i18n.num(cmn[i, j] * 100, 1)}%", ha="center", va="center",
                    fontsize=7.5, color="white" if cmn[i, j] > 0.6 else INK)
    ax.set_xticks(range(len(G)))
    ax.set_yticks(range(len(G)))
    ax.set_xticklabels(G, rotation=20 if len(G) > 2 else 0)
    ax.set_yticklabels(G)
    ax._cat_x = ax._cat_y = True
    ax.set_xlabel("Predicted" if i18n.LANG == "en" else "Predito")
    ax.set_ylabel("Observed" if i18n.LANG == "en" else "Observado")
    ax.set_title(tr(C["best"]), loc="left")
    for s in ax.spines.values():
        s.set_visible(False)
    _panel(ax, 0, x=-0.3)
    k = 1
    if has_roc:
        ax = axs[1]
        for i, (g, (fpr, tpr, a)) in enumerate(C["roc"].items()):
            ci = G.index(g)
            ax.plot(fpr, tpr, color=gcolor(ci) if len(G) > 2 else "#1684C4", lw=1.6,
                    label=f"{g} (AUC = {i18n.num(a, 3)})" if len(G) > 2 else f"AUC = {i18n.num(a, 3)}")
        ax.plot([0, 1], [0, 1], color=MUTED, ls=":", lw=0.9)
        ax.set_xlabel("1 − " + ("Specificity" if i18n.LANG == "en" else "Especificidade"))
        ax.set_ylabel("Sensitivity" if i18n.LANG == "en" else "Sensibilidade")
        ax.set_aspect("equal")
        ax.legend(loc="lower right")
        _panel(ax, k)
        k += 1
    ax = axs[k]
    pm = C["perm"]
    if len(pm["scores"]):
        ax.hist(pm["scores"] * 100, bins=20, color="#C9D6DF", edgecolor="white")
        ax.axvline(pm["score"] * 100, color="#2EA043", lw=2)
        ax.text(pm["score"] * 100, ax.get_ylim()[1] * 0.95, f"  p {_pfmt(pm['p'])}", color="#2EA043",
                fontsize=8, va="top")
    ax.set_xlabel(f"{tr('bacc')} (%)")
    ax.set_ylabel(tr_freq())
    ax.set_title("Permutation test" if i18n.LANG == "en" else "Teste de permutação", loc="left")
    _panel(ax, k)
    _dec(fig)
    return fig


def fig_clus(R):
    Cl = R.clus
    cv = Cl["curves"]
    fig = Figure(figsize=(10.2, 3.4), layout="constrained")
    axs = fig.subplots(1, 3 if Cl["methods"] else 2)
    axs[0].plot(cv["k"], cv["wss"], "-o", color="#1684C4", ms=4)
    axs[0].set_xlabel("k")
    axs[0].set_ylabel("WSS")
    axs[1].plot(cv["k"], cv["sil"], "-o", color="#2EA043", ms=4, label=tr("silhouette"))
    axs[1].set_xlabel("k")
    axs[1].set_ylabel(tr("silhouette"))
    a2 = axs[1].twinx()
    a2.spines["right"].set_visible(True)
    a2.plot(cv["k"], cv["bic"], "-s", color="#E9A23B", ms=4)
    a2.set_ylabel("BIC", color="#E9A23B")
    a2._keep_ticks = True
    for i, a in enumerate(axs[:2]):
        a.set_xticks(cv["k"])
        a._cat_x = True
        _panel(a, i)
    if Cl["methods"]:
        ax = axs[2]
        ms = list(Cl["methods"].keys())
        v = [Cl["methods"][m]["ari"] for m in ms]
        ax.bar(range(len(ms)), v, color=["#7B5EA7", "#2A9D8F", "#E9A23B"][:len(ms)], width=0.6)
        ax.axhline(0, color=INK, lw=0.8)
        ax.set_xticks(range(len(ms)))
        ax.set_xticklabels([tr(m) for m in ms], rotation=12)
        ax._cat_x = True
        ax.set_ylabel("ARI")
        ax.set_ylim(min(-0.05, min(v) - 0.05), max(1.0, max(v) + 0.05) if max(v) > 0.5 else max(0.3, max(v) + 0.1))
        _panel(ax, 2)
    _dec(fig)
    return fig


def _hexplot(ax, som, values, cmap, vmin=None, vmax=None, edge="white"):
    xy = som.xy
    norm = mcolors.Normalize(vmin=np.nanmin(values) if vmin is None else vmin,
                             vmax=np.nanmax(values) if vmax is None else vmax)
    cm = matplotlib.colormaps[cmap] if isinstance(cmap, str) else cmap
    for (x, y), v in zip(xy, values):
        fc = "#F1F3F5" if np.isnan(v) else cm(norm(v))
        ax.add_patch(RegularPolygon((x, y), numVertices=6, radius=0.5 / np.cos(np.pi / 6) * 0.98,
                                    orientation=0, facecolor=fc, edgecolor=edge, lw=0.5))
    ax.set_xlim(xy[:, 0].min() - 0.7, xy[:, 0].max() + 0.7)
    ax.set_ylim(xy[:, 1].max() + 0.7, xy[:, 1].min() - 0.7)
    ax.set_aspect("equal")
    ax.axis("off")
    return matplotlib.cm.ScalarMappable(norm=norm, cmap=cm)


def fig_som(R):
    S = R.som
    som = S["som"]
    G = R.groups
    nG = len(G)
    ncols = 2 + min(nG, 4)
    fig = Figure(figsize=(2.9 * ncols, 3.4), layout="constrained")
    axs = fig.subplots(1, ncols)
    sm = _hexplot(axs[0], som, S["U"], "Greys")
    cb = fig.colorbar(sm, ax=axs[0], shrink=0.7, pad=0.02)
    cb.outline.set_visible(False)
    axs[0].set_title("(A)  U-matrix", loc="left")
    hits = S["hits"]
    tot = hits.sum(0)
    dom = np.argmax(hits, 0).astype(float)
    ax = axs[1]
    cmap = mcolors.ListedColormap([gcolor(i) for i in range(nG)])
    for (x, y), d, t, col in zip(som.xy, dom, tot, range(len(tot))):
        if t == 0:
            fc = "#F1F3F5"
        else:
            share = hits[int(d), col] / t
            fc = mcolors.to_rgba(gcolor(int(d)), 0.25 + 0.75 * share)
        ax.add_patch(RegularPolygon((x, y), 6, radius=0.5 / np.cos(np.pi / 6) * 0.98, facecolor=fc,
                                    edgecolor="white", lw=0.5))
    ax.set_xlim(som.xy[:, 0].min() - 0.7, som.xy[:, 0].max() + 0.7)
    ax.set_ylim(som.xy[:, 1].max() + 0.7, som.xy[:, 1].min() - 0.7)
    ax.set_aspect("equal")
    ax.axis("off")
    ttl = "Dominance" if i18n.LANG == "en" else "Dominância"
    ax.set_title(f"(B)  {ttl}  (p {_pfmt(S['p'])})", loc="left")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=gcolor(i), label=g) for i, g in enumerate(G)], loc="upper center",
              bbox_to_anchor=(0.5, -0.02), ncol=min(nG, 3), fontsize=7)
    vmax = hits.max()
    for i in range(min(nG, 4)):
        ax = axs[2 + i]
        v = hits[i].astype(float)
        v[v == 0] = np.nan
        cm_ = mcolors.LinearSegmentedColormap.from_list("h", ["#FFFFFF", gcolor(i)])
        sm = _hexplot(ax, som, v, cm_, vmin=0, vmax=vmax)
        for (x, y), h in zip(som.xy, hits[i]):
            if h:
                ax.text(x, y, str(h), ha="center", va="center", fontsize=5.5,
                        color="white" if h > vmax * 0.6 else INK)
        ax.set_title(f"({chr(67 + i)})  {g_trunc(G[i])}", loc="left")
    return fig


def g_trunc(g, n=22):
    return g if len(g) <= n else g[:n - 1] + "…"


def fig_planes(R):
    S = R.som
    som = S["som"]
    fig = Figure(figsize=(9.6, 9.0), layout="constrained")
    axs = fig.subplots(3, 3).ravel()
    for k, t in enumerate(TRAITS):
        sm = _hexplot(axs[k], som, S["planes"][:, k], "viridis")
        cb = fig.colorbar(sm, ax=axs[k], shrink=0.7, pad=0.01)
        cb.outline.set_visible(False)
        cb.ax.tick_params(labelsize=6.5)
        axs[k].set_title(f"({chr(65 + k)})  {trait(t)}", loc="left", fontsize=8.5)
    return fig


# --------------------------------------------------------------------------
REGISTRY = [
    ("hist", "fig_hist", fig_hist, lambda R: True),
    ("box", "fig_box", fig_box, lambda R: True),
    ("scatter", "fig_scatter", fig_scatter, lambda R: True),
    ("shape", "fig_shape", fig_shape, lambda R: True),
    ("corr", "fig_corr", fig_corr, lambda R: R.corr is not None),
    ("pca", "fig_pca", fig_pca, lambda R: R.pca is not None),
    ("models", "fig_models", fig_models, lambda R: R.clf is not None),
    ("cm", "fig_cm", fig_cm, lambda R: R.clf is not None),
    ("clus", "fig_clus", fig_clus, lambda R: R.clus is not None),
    ("som", "fig_som", fig_som, lambda R: R.som is not None),
    ("planes", "fig_planes", fig_planes, lambda R: R.som is not None),
]


def available(R):
    return [(k, t, f) for k, t, f, ok in REGISTRY if ok(R)]


def make(R, key):
    for k, t, f, ok in REGISTRY:
        if k == key:
            return f(R)
    raise KeyError(key)


def save(fig, path, dpi=600):
    kw = {}
    if path.lower().endswith((".tif", ".tiff")):
        kw["pil_kwargs"] = {"compression": "tiff_lzw"}
    fig.savefig(path, dpi=dpi, facecolor="white", **kw)


def to_png_bytes(fig, dpi=150):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, facecolor="white")
    return buf.getvalue()
