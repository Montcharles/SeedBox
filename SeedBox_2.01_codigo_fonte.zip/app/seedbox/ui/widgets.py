"""Reusable widgets."""
from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex, Signal, QSize
from PySide6.QtGui import QColor, QFont, QPixmap, QPainter
from PySide6.QtWidgets import (QFrame, QVBoxLayout, QHBoxLayout, QLabel, QTableView, QHeaderView, QWidget,
                               QGraphicsDropShadowEffect, QSizePolicy, QPushButton, QAbstractItemView, QScrollArea)

from .theme import C, icon


def shadow(w, blur=24, alpha=18, dy=4):
    e = QGraphicsDropShadowEffect(w)
    e.setBlurRadius(blur)
    e.setColor(QColor(16, 36, 52, alpha))
    e.setOffset(0, dy)
    w.setGraphicsEffect(e)


class Card(QFrame):
    def __init__(self, title=None, sub=None, parent=None, margins=(18, 16, 18, 18), spacing=10):
        super().__init__(parent)
        self.setObjectName("Card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(*margins)
        self.lay.setSpacing(spacing)
        self.title = self.sub = None
        if title is not None:
            self.title = QLabel(title)
            self.title.setObjectName("CardTitle")
            self.lay.addWidget(self.title)
        if sub is not None:
            self.sub = QLabel(sub)
            self.sub.setObjectName("CardSub")
            self.sub.setWordWrap(True)
            self.lay.addWidget(self.sub)
        shadow(self)

    def set_title(self, t, s=None):
        if self.title:
            self.title.setText(t)
        if self.sub and s is not None:
            self.sub.setText(s)


class KpiCard(QFrame):
    def __init__(self, color, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 16, 0)
        bar = QFrame()
        bar.setFixedWidth(4)
        bar.setStyleSheet(f"background:{color}; border-top-left-radius:12px; border-bottom-left-radius:12px;")
        lay.addWidget(bar)
        v = QVBoxLayout()
        v.setContentsMargins(14, 14, 0, 14)
        v.setSpacing(2)
        self.value = QLabel("—")
        self.value.setObjectName("KpiValue")
        self.label = QLabel("")
        self.label.setObjectName("KpiLabel")
        self.label.setWordWrap(True)
        self.extra = QLabel("")
        self.extra.setObjectName("Hint")
        v.addWidget(self.value)
        v.addWidget(self.label)
        v.addWidget(self.extra)
        lay.addLayout(v, 1)
        self.setMinimumHeight(104)
        shadow(self)

    def set(self, value, label, extra=""):
        self.value.setText(value)
        self.label.setText(label)
        self.extra.setText(extra)
        self.extra.setVisible(bool(extra))


class FrameModel(QAbstractTableModel):
    """Read-only model from a list of rows."""

    def __init__(self, headers, rows, bold_first=True, highlight_rows=(), align_left_cols=(0,), colors=None):
        super().__init__()
        self.h = headers
        self.rows = rows
        self.bold_first = bold_first
        self.hl = set(highlight_rows)
        self.left = set(align_left_cols)
        self.colors = colors or {}

    def rowCount(self, p=QModelIndex()):
        return len(self.rows)

    def columnCount(self, p=QModelIndex()):
        return len(self.h)

    def data(self, idx, role=Qt.DisplayRole):
        r, c = idx.row(), idx.column()
        if role == Qt.DisplayRole:
            return str(self.rows[r][c])
        if role == Qt.TextAlignmentRole:
            return int((Qt.AlignLeft if c in self.left else Qt.AlignCenter) | Qt.AlignVCenter)
        if role == Qt.FontRole:
            if (c == 0 and self.bold_first) or r in self.hl:
                f = QFont()
                f.setBold(True)
                return f
        if role == Qt.BackgroundRole and r in self.hl:
            return QColor(C["green_soft"])
        if role == Qt.ForegroundRole and (r, c) in self.colors:
            return QColor(self.colors[(r, c)])
        return None

    def headerData(self, s, o, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and o == Qt.Horizontal:
            return self.h[s]
        if role == Qt.DisplayRole and o == Qt.Vertical:
            return str(s + 1)
        return None


def make_table(stretch=True, min_h=None):
    t = QTableView()
    t.setAlternatingRowColors(True)
    t.verticalHeader().setVisible(False)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectRows)
    t.setShowGrid(False)
    t.verticalHeader().setDefaultSectionSize(32)
    t.horizontalHeader().setHighlightSections(False)
    t.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
    t.setWordWrap(False)
    if min_h:
        t.setMinimumHeight(min_h)
    return t


def set_model(table, model, stretch=True, first_w=None):
    table.setModel(model)
    hh = table.horizontalHeader()
    if stretch:
        hh.setSectionResizeMode(QHeaderView.Stretch)
        if first_w:
            hh.setSectionResizeMode(0, QHeaderView.Fixed)
            table.setColumnWidth(0, first_w)
    else:
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
    n = model.rowCount()
    table.setFixedHeight(min(36 + n * 32 + 4, 36 + 18 * 32))


def fit_table(table, max_rows=18):
    n = table.model().rowCount() if table.model() else 0
    table.setFixedHeight(min(36 + n * 32 + 4, 36 + max_rows * 32))


def chip(text, kind="Chip"):
    l = QLabel(text)
    l.setObjectName(kind)
    l.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
    return l


def btn(text, ic=None, kind=None, color=None):
    b = QPushButton(text)
    if kind:
        b.setObjectName(kind)
    if ic:
        col = color or ("#FFFFFF" if kind in ("Primary", "Blue") else C["ink"])
        b.setIcon(icon(ic, col, 16))
        b.setIconSize(QSize(16, 16))
    b.setCursor(Qt.PointingHandCursor)
    return b


class EmptyState(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        v = QVBoxLayout(self)
        v.setAlignment(Qt.AlignCenter)
        from ..paths import asset
        self.img = QLabel()
        pm = QPixmap(asset("emblem.png")).scaled(120, 120, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        op = QPixmap(pm.size())
        op.fill(Qt.transparent)
        p = QPainter(op)
        p.setOpacity(0.35)
        p.drawPixmap(0, 0, pm)
        p.end()
        self.img.setPixmap(op)
        self.img.setAlignment(Qt.AlignCenter)
        self.t = QLabel()
        self.t.setObjectName("CardTitle")
        self.t.setAlignment(Qt.AlignCenter)
        self.s = QLabel()
        self.s.setObjectName("Muted")
        self.s.setAlignment(Qt.AlignCenter)
        v.addWidget(self.img)
        v.addSpacing(10)
        v.addWidget(self.t)
        v.addWidget(self.s)

    def set(self, t, s):
        self.t.setText(t)
        self.s.setText(s)


def scroll_wrap(inner):
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFrameShape(QFrame.NoFrame)
    sa.setWidget(inner)
    inner.setObjectName("Content")
    sa.viewport().setObjectName("Viewport")
    sa.viewport().setStyleSheet(f"QWidget#Viewport{{background:{C['bg']};}}")
    return sa


class AspectImage(QWidget):
    """Pixmap that scales with the available width, keeping aspect ratio."""

    def __init__(self, pixmap, max_w=None, parent=None):
        super().__init__(parent)
        self.pm = pixmap
        self.max_w = max_w or pixmap.width()
        sp = QSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        sp.setHeightForWidth(True)
        self.setSizePolicy(sp)
        self.setMinimumWidth(200)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, w):
        w = min(w, self.max_w)
        return int(w * self.pm.height() / max(1, self.pm.width()))

    def sizeHint(self):
        return QSize(self.max_w, self.heightForWidth(self.max_w))

    def paintEvent(self, e):
        w = min(self.width(), self.max_w)
        h = self.heightForWidth(w)
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.setRenderHint(QPainter.Antialiasing)
        x = (self.width() - w) // 2
        p.drawPixmap(x, 0, w, h, self.pm)
        p.end()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.setMinimumHeight(self.heightForWidth(self.width()))
        self.setMaximumHeight(self.heightForWidth(self.width()))
