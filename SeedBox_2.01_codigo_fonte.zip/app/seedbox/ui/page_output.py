"""Figures and report pages."""
import os
from PySide6.QtCore import Qt, QUrl, QSize
from PySide6.QtGui import QPixmap, QImage, QDesktopServices, QGuiApplication, QCursor
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QComboBox,
                               QCheckBox, QScrollArea, QFileDialog, QLineEdit, QPlainTextEdit, QFormLayout,
                               QFrame, QApplication)

from .. import figures, i18n
from ..i18n import tr
from .widgets import Card, btn, EmptyState, chip
from .page_results import ResultPage
from .theme import C, icon


class FiguresPage(ResultPage):
    title_key, sub_key = "fig_title", "fig_sub"

    def __init__(self, parent=None):
        self.cache = {}
        super().__init__(parent)

    def set_results(self, R):
        self.cache = {}
        super().set_results(R)

    def retranslate(self):
        self.cache = {}
        super().retranslate()

    def build(self, lay):
        R = self.R
        row = QHBoxLayout()
        row.setSpacing(16)
        left = Card(tr("fig_title"), margins=(12, 14, 12, 12))
        self.lst = QListWidget()
        self.items = figures.available(R)
        for i, (k, t, f) in enumerate(self.items):
            it = QListWidgetItem(icon("figures", C["muted"], 16), f"{i + 1:02d}  {tr(t)}")
            it.setData(Qt.UserRole, k)
            self.lst.addItem(it)
        self.lst.setIconSize(QSize(16, 16))
        self.lst.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.lst.setTextElideMode(Qt.ElideRight)
        left.lay.addWidget(self.lst, 1)
        left.setFixedWidth(300)
        row.addWidget(left)

        right = Card(margins=(16, 14, 16, 16))
        tb = QHBoxLayout()
        self.ttl = QLabel()
        self.ttl.setObjectName("CardTitle")
        tb.addWidget(self.ttl)
        tb.addStretch(1)
        self.fmt = QComboBox()
        self.fmt.addItems(["PNG", "TIFF", "PDF", "SVG", "JPG"])
        self.dpi = QComboBox()
        self.dpi.addItems(["300 dpi", "600 dpi", "1200 dpi"])
        self.dpi.setCurrentIndex(1)
        tb.addWidget(QLabel(tr("resolution")))
        tb.addWidget(self.dpi)
        tb.addWidget(self.fmt)
        b1 = btn(tr("save_fig"), "save")
        b1.clicked.connect(self.save_current)
        tb.addWidget(b1)
        right.lay.addLayout(tb)
        exp = QHBoxLayout()
        lab = QLabel(tr("formats") + ":")
        lab.setObjectName("Muted")
        exp.addWidget(lab)
        self.cb = {}
        for f, on in [("png", True), ("tiff", False), ("pdf", False), ("svg", False)]:
            c = QCheckBox(f.upper())
            c.setChecked(on)
            self.cb[f] = c
            exp.addWidget(c)
        exp.addStretch(1)
        bz = btn(tr("export_zip"), "zip", "Primary")
        bz.clicked.connect(lambda: self.window().export_zip(self.zip_formats(), self.zip_dpi()))
        exp.addWidget(bz)
        right.lay.addLayout(exp)
        sep = QFrame()
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"background:{C['border']};")
        right.lay.addWidget(sep)
        self.view = QLabel()
        self.view.setAlignment(Qt.AlignCenter)
        self.view.setObjectName("FigView")
        self.view.setStyleSheet("QLabel#FigView{background:white;}")
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setWidget(self.view)
        sa.setMinimumHeight(560)
        sa.viewport().setObjectName("FigVp")
        sa.viewport().setStyleSheet("QWidget#FigVp{background:white;}")
        right.lay.addWidget(sa, 1)
        row.addWidget(right, 1)
        lay.addLayout(row, 1)
        self.lst.currentRowChanged.connect(self.show_fig)
        self.lst.setCurrentRow(0)

    def zip_formats(self):
        f = [k for k, c in self.cb.items() if c.isChecked()]
        return f or ["png"]

    def zip_dpi(self):
        return int(self.dpi.currentText().split()[0])

    def show_fig(self, i):
        if i < 0:
            return
        k, t, f = self.items[i]
        self.ttl.setText(tr(t))
        if k not in self.cache:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                png = figures.to_png_bytes(f(self.R), dpi=130)
                self.cache[k] = QPixmap.fromImage(QImage.fromData(png))
            finally:
                QApplication.restoreOverrideCursor()
        pm = self.cache[k]
        w = max(600, self.view.width() - 30)
        self.view.setPixmap(pm if pm.width() <= w else pm.scaledToWidth(w, Qt.SmoothTransformation))

    def save_current(self):
        from .main_window import last_dir, remember_dir
        i = self.lst.currentRow()
        if i < 0:
            return
        k, t, f = self.items[i]
        ext = self.fmt.currentText().lower()
        ext = "tif" if ext == "tiff" else ext
        p, _ = QFileDialog.getSaveFileName(self, tr("save_fig"), f"{last_dir()}/{i + 1:02d}_{k}.{ext}",
                                           f"{ext.upper()} (*.{ext})")
        if not p:
            return
        remember_dir(p)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            fig = f(self.R)
            kw = {}
            if ext == "jpg":
                kw = {}
            figures.save(fig, p, dpi=self.zip_dpi())
        finally:
            QApplication.restoreOverrideCursor()
        self.window().flash(f"{tr('saved_to')}: {p}")


class ReportPage(ResultPage):
    title_key, sub_key = "rep_title", "rep_sub"

    def __init__(self, parent=None):
        self.meta = {"project": "", "species": "", "analyst": "", "institution": "", "notes": ""}
        super().__init__(parent)

    def collect(self):
        if hasattr(self, "f_project"):
            try:
                self.meta = {"project": self.f_project.text().strip(), "species": self.f_species.text().strip(),
                             "analyst": self.f_analyst.text().strip(), "institution": self.f_inst.text().strip(),
                             "notes": self.f_notes.toPlainText().strip()}
            except RuntimeError:
                pass
        return self.meta

    def rebuild(self):
        self.collect()
        super().rebuild()

    def build(self, lay):
        row = QHBoxLayout()
        row.setSpacing(16)
        form_card = Card(tr("rep_info"))
        f = QFormLayout()
        f.setVerticalSpacing(10)
        f.setHorizontalSpacing(16)
        self.f_project = QLineEdit(self.meta["project"])
        self.f_species = QLineEdit(self.meta["species"])
        self.f_species.setPlaceholderText(tr("species_ph"))
        self.f_analyst = QLineEdit(self.meta["analyst"])
        self.f_inst = QLineEdit(self.meta["institution"])
        self.f_notes = QPlainTextEdit(self.meta["notes"])
        self.f_notes.setFixedHeight(110)
        for k, w in [("rep_project", self.f_project), ("species", self.f_species), ("rep_analyst", self.f_analyst),
                     ("rep_inst", self.f_inst), ("rep_notes", self.f_notes)]:
            f.addRow(QLabel(tr(k)), w)
        form_card.lay.addLayout(f)
        form_card.lay.addStretch(1)
        row.addWidget(form_card, 3)

        ex = Card(tr("exports_title"), tr("exports_sub"))
        b1 = btn(tr("rep_gen"), "pdf", "Primary")
        b1.setMinimumHeight(44)
        b1.clicked.connect(lambda: self.window().make_report(self.collect()))
        b2 = btn(tr("export_zip"), "zip", "Blue")
        b2.setMinimumHeight(40)
        b2.clicked.connect(lambda: self.window().export_zip(["png"], 600))
        b3 = btn(tr("export_xlsx"), "sheet")
        b3.setMinimumHeight(40)
        b3.clicked.connect(self.window().export_excel)
        ex.lay.addSpacing(6)
        ex.lay.addWidget(b1)
        ex.lay.addWidget(b2)
        ex.lay.addWidget(b3)
        h = QLabel("ZIP: PNG · 600 dpi")
        h.setObjectName("Hint")
        ex.lay.addWidget(h)
        ex.lay.addStretch(1)
        self.last = QLabel("")
        self.last.setObjectName("Hint")
        self.last.setWordWrap(True)
        ex.lay.addWidget(self.last)
        self.b_open = btn(tr("rep_open"), "open")
        self.b_open.setVisible(False)
        ex.lay.addWidget(self.b_open)
        row.addWidget(ex, 2)
        lay.addLayout(row)

        prev = Card(tr("rep_s8"))
        secs = ["rep_s1", "rep_s2", "rep_s3", "rep_s4", "rep_s5", "rep_s6", "rep_s7"]
        for s in secs:
            if s == "rep_s3" and self.R.comp is None:
                continue
            if s == "rep_s5" and not self.R.clf:
                continue
            l = QLabel("✓  " + tr(s))
            l.setStyleSheet(f"color:{C['ink']};padding:2px 0;")
            prev.lay.addWidget(l)
        prev.set_title(tr("rep_sections"))
        lay.addWidget(prev)

    def show_saved(self, path):
        self.last.setText(f"{tr('saved_to')}:\n{path}")
        self.b_open.setVisible(True)
        try:
            self.b_open.clicked.disconnect()
        except Exception:
            pass
        self.b_open.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(path)))
