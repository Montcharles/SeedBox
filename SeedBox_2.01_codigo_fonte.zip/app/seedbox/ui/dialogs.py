"""Dialogs."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QFormLayout, QDialogButtonBox,
                               QSpinBox, QDoubleSpinBox, QCheckBox, QProgressBar, QFrame, QTableWidget,
                               QTableWidgetItem, QHeaderView, QPushButton)

from ..i18n import tr
from ..paths import asset
from .. import __version__
from .widgets import btn
from .theme import C


def _buttons(dlg, ok=True):
    bb = QDialogButtonBox()
    b_ok = btn(tr("ok"), kind="Primary")
    b_c = btn(tr("cancel"))
    bb.addButton(b_c, QDialogButtonBox.RejectRole)
    if ok:
        bb.addButton(b_ok, QDialogButtonBox.AcceptRole)
    bb.accepted.connect(dlg.accept)
    bb.rejected.connect(dlg.reject)
    return bb


class MappingDialog(QDialog):
    def __init__(self, sheets, guess, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("map_title"))
        self.sheets = sheets
        self.setMinimumWidth(640)
        v = QVBoxLayout(self)
        v.setContentsMargins(22, 20, 22, 18)
        t = QLabel(tr("map_title"))
        t.setObjectName("CardTitle")
        s = QLabel(tr("map_sub"))
        s.setObjectName("Muted")
        v.addWidget(t)
        v.addWidget(s)
        form = QFormLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(10)
        self.sheet = QComboBox()
        self.sheet.addItems(list(sheets))
        if len(sheets) > 1:
            form.addRow(QLabel(tr("sheet")), self.sheet)
        self.combos = {}
        for key, lab in [("group", tr("group")), ("L", tr("length")), ("W", tr("width")), ("T", tr("thickness"))]:
            cb = QComboBox()
            self.combos[key] = cb
            form.addRow(QLabel(lab), cb)
        v.addLayout(form)
        self.sheets_as_lots = QCheckBox(tr("map_sheets"))
        self.sheets_as_lots.setVisible(len(sheets) > 1)
        v.addWidget(self.sheets_as_lots)
        self.preview = QTableWidget()
        self.preview.setMaximumHeight(170)
        self.preview.verticalHeader().setVisible(False)
        v.addWidget(self.preview)
        v.addWidget(_buttons(self))
        self.sheet.currentTextChanged.connect(lambda _: self._fill(guess))
        self._fill(guess)

    def _fill(self, guess):
        df = self.sheets[self.sheet.currentText()]
        cols = [str(c) for c in df.columns]
        for key, cb in self.combos.items():
            cb.clear()
            if key == "group":
                cb.addItem(tr("map_group_none"), None)
            for c in df.columns:
                cb.addItem(str(c), c)
            g = guess.get(key)
            if g is not None and g in list(df.columns):
                cb.setCurrentIndex(list(df.columns).index(g) + (1 if key == "group" else 0))
        self.preview.setColumnCount(len(cols))
        self.preview.setHorizontalHeaderLabels(cols)
        n = min(6, len(df))
        self.preview.setRowCount(n)
        for i in range(n):
            for j in range(len(cols)):
                self.preview.setItem(i, j, QTableWidgetItem(str(df.iat[i, j])))
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

    def result_frame(self):
        from ..io_import import to_long
        import pandas as pd
        m = {k: cb.currentData() for k, cb in self.combos.items()}
        if self.sheets_as_lots.isChecked():
            parts = []
            for n, df in self.sheets.items():
                try:
                    parts.append(to_long(df, m, n))
                except Exception:
                    continue
            return pd.concat(parts, ignore_index=True)
        df = self.sheets[self.sheet.currentText()]
        return to_long(df, m, None if m.get("group") is not None else "1")


class SettingsDialog(QDialog):
    def __init__(self, st, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("set_title"))
        self.setMinimumWidth(420)
        v = QVBoxLayout(self)
        v.setContentsMargins(22, 20, 22, 18)
        t = QLabel(tr("set_title"))
        t.setObjectName("CardTitle")
        v.addWidget(t)
        v.addSpacing(6)
        f = QFormLayout()
        f.setVerticalSpacing(10)
        f.setHorizontalSpacing(18)
        self.alpha = QDoubleSpinBox()
        self.alpha.setRange(0.001, 0.2)
        self.alpha.setDecimals(3)
        self.alpha.setSingleStep(0.01)
        self.alpha.setValue(st.alpha)
        self.folds = QSpinBox()
        self.folds.setRange(3, 20)
        self.folds.setValue(st.cv_folds)
        self.reps = QSpinBox()
        self.reps.setRange(1, 20)
        self.reps.setValue(st.cv_repeats)
        self.seed = QSpinBox()
        self.seed.setRange(0, 99999)
        self.seed.setValue(st.seed)
        self.perm = QSpinBox()
        self.perm.setRange(199, 9999)
        self.perm.setSingleStep(100)
        self.perm.setValue(st.n_perm)
        self.grid = QSpinBox()
        self.grid.setRange(0, 15)
        self.grid.setSpecialValueText(tr("auto"))
        self.grid.setValue(st.som_grid)
        self.iters = QSpinBox()
        self.iters.setRange(1000, 30000)
        self.iters.setSingleStep(1000)
        self.iters.setValue(st.som_iter)
        self.ml = QCheckBox()
        self.ml.setChecked(st.run_ml)
        self.somr = QCheckBox()
        self.somr.setChecked(st.run_som)
        for lab, w in [("set_alpha", self.alpha), ("set_ml", self.ml), ("set_folds", self.folds),
                       ("set_reps", self.reps), ("set_seed", self.seed), ("set_somrun", self.somr),
                       ("set_som", self.grid), ("set_iter", self.iters), ("set_perm", self.perm)]:
            f.addRow(QLabel(tr(lab)), w)
        v.addLayout(f)
        v.addSpacing(8)
        v.addWidget(_buttons(self))

    def apply(self, st):
        st.alpha = self.alpha.value()
        st.cv_folds = self.folds.value()
        st.cv_repeats = self.reps.value()
        st.seed = self.seed.value()
        st.n_perm = self.perm.value()
        st.som_grid = self.grid.value()
        st.som_iter = self.iters.value()
        st.run_ml = self.ml.isChecked()
        st.run_som = self.somr.isChecked()
        return st


class AboutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("about"))
        self.setFixedWidth(520)
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 26, 28, 20)
        logo = QLabel()
        logo.setPixmap(QPixmap(asset("logo_light.png")).scaledToWidth(300, Qt.SmoothTransformation))
        v.addWidget(logo)
        v.addSpacing(10)
        ver = QLabel(f"{tr('version')} {__version__}")
        ver.setObjectName("Chip")
        v.addWidget(ver, 0, Qt.AlignLeft)
        v.addSpacing(6)
        txt = QLabel(tr("about_text"))
        txt.setWordWrap(True)
        v.addWidget(txt)
        v.addSpacing(6)
        ref = QLabel(f"<b>{tr('reference')}</b><br>Nobrega, M.A.S.; Nabuco, M.L.H.P.; Araújo, D.; Fernandes, S.Y.; "
                     f"Miguel, E.C.; Arruda, G.J.; Santiago, E.F.; Santos, J.S.; Pontes, M.S. (2026). "
                     f"<i>Flora</i>, 153108. doi:10.1016/j.flora.2026.153108")
        ref.setWordWrap(True)
        ref.setObjectName("Hint")
        ref.setTextInteractionFlags(Qt.TextSelectableByMouse)
        v.addWidget(ref)
        v.addSpacing(8)
        c = QLabel("© 2026 SeedBox")
        c.setObjectName("Hint")
        v.addWidget(c)
        b = btn(tr("close"), kind="Primary")
        b.clicked.connect(self.accept)
        v.addWidget(b, 0, Qt.AlignRight)


class ProgressDialog(QDialog):
    def __init__(self, title, parent=None):
        super().__init__(parent, Qt.Dialog | Qt.FramelessWindowHint)
        self.setModal(True)
        self.setFixedWidth(440)
        self.setAttribute(Qt.WA_TranslucentBackground)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        fr = QFrame()
        fr.setStyleSheet(f"QFrame#pd{{background:white;border:1px solid {C['border']};border-radius:14px;}}")
        fr.setObjectName("pd")
        outer.addWidget(fr)
        v = QVBoxLayout(fr)
        v.setContentsMargins(26, 24, 26, 24)
        h = QHBoxLayout()
        em = QLabel()
        em.setPixmap(QPixmap(asset("emblem.png")).scaled(44, 44, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        h.addWidget(em)
        tv = QVBoxLayout()
        self.t = QLabel(title)
        self.t.setObjectName("CardTitle")
        self.s = QLabel("")
        self.s.setObjectName("Muted")
        tv.addWidget(self.t)
        tv.addWidget(self.s)
        h.addLayout(tv, 1)
        v.addLayout(h)
        v.addSpacing(12)
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setFixedHeight(8)
        v.addWidget(self.bar)

    def update_progress(self, frac, msg=""):
        self.bar.setValue(int(frac * 1000))
        if msg:
            self.s.setText(msg)
