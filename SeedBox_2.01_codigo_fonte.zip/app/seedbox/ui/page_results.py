"""Result pages."""
import numpy as np
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QImage, QColor
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QTabWidget, QComboBox,
                               QStackedLayout, QFrame, QSizePolicy, QFileDialog)

from .. import i18n, figures, report
from ..i18n import tr, trait, num, fmt_p
from ..core import TRAITS, UNITS
from .widgets import (Card, KpiCard, FrameModel, make_table, set_model, chip, btn, EmptyState, scroll_wrap,
                      shadow, AspectImage)
from .theme import C


def fig_widget(R, key, max_w, dpi=150):
    fig = figures.make(R, key)
    png = figures.to_png_bytes(fig, dpi=dpi)
    pm = QPixmap.fromImage(QImage.fromData(png))
    return AspectImage(pm, max_w)


class ResultPage(QWidget):
    """Base: empty state until results exist, then a scrollable rebuilt body."""
    title_key = sub_key = ""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.R = None
        self.stack = QStackedLayout(self)
        self.empty = EmptyState()
        self.empty.setObjectName("Content")
        self.stack.addWidget(self.empty)
        self.holder = QWidget()
        self.stack.addWidget(self.holder)
        self.hl = QVBoxLayout(self.holder)
        self.hl.setContentsMargins(0, 0, 0, 0)
        self.body = None
        self.retranslate()

    def set_results(self, R):
        self.R = R
        self.rebuild()

    def retranslate(self):
        self.empty.set(tr("no_results_title"), tr("no_results"))
        if self.R is not None:
            self.rebuild()

    def rebuild(self):
        if self.R is None:
            self.stack.setCurrentIndex(0)
            return
        if self.body is not None:
            self.hl.removeWidget(self.body)
            self.body.deleteLater()
        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(24, 20, 24, 24)
        lay.setSpacing(16)
        ok = self.build(lay)
        if ok is False:
            self.stack.setCurrentIndex(0)
            return
        lay.addStretch(1)
        self.body = scroll_wrap(inner)
        self.hl.addWidget(self.body)
        self.stack.setCurrentIndex(1)

    def build(self, lay):
        raise NotImplementedError


def _ms(R, g, t, d=2):
    r = R.desc[(R.desc.group == g) & (R.desc.trait == t)].iloc[0]
    return f"{num(r['mean'], d)} ± {num(r['sd'], d)}"


# =========================================================================
class OverviewPage(ResultPage):
    title_key, sub_key = "ov_title", "ov_sub"

    def build(self, lay):
        R = self.R
        grid = QGridLayout()
        grid.setSpacing(14)
        k = [KpiCard(C["blue"]), KpiCard(C["green"]), KpiCard(C["amber"]), KpiCard("#7B5EA7")]
        k[0].set(str(len(R.props)), tr("kpi_seeds"), " · ".join(f"{g}: {int((R.props.group == g).sum())}"
                                                                for g in R.groups[:4]))
        k[1].set(str(len(R.groups)), tr("kpi_groups"))
        if R.comp is not None:
            ns = int((R.comp.p < R.settings.alpha).sum())
            k[2].set(f"{ns}/9", tr("kpi_sig"), f"α = {num(R.settings.alpha, 2)}")
        else:
            k[2].set("—", tr("kpi_sig"))
        k[3].set(f"{num(R.pca['cum'][1], 1)}%", tr("kpi_pca"))
        for i, w in enumerate(k):
            grid.addWidget(w, 0, i)
        lay.addLayout(grid)

        row = QHBoxLayout()
        row.setSpacing(16)
        if R.clf:
            b = R.clf["table"].iloc[0]
            best = QFrame()
            best.setObjectName("BestCard")
            shadow(best)
            bl = QVBoxLayout(best)
            bl.setContentsMargins(20, 16, 20, 16)
            t = QLabel(tr("best_model").upper())
            t.setStyleSheet("color:#1B7A33;font-size:8pt;font-weight:700;letter-spacing:1px;")
            bl.addWidget(t)
            n = QLabel(tr(R.clf["best"]))
            n.setObjectName("BestTitle")
            bl.addWidget(n)
            v = QLabel(f"{num(b['bacc'] * 100, 1)}%")
            v.setStyleSheet("font-family:Poppins;font-size:26pt;font-weight:600;color:#1B2730;")
            bl.addWidget(v)
            bl.addWidget(QLabel(tr("bacc")))
            h = QHBoxLayout()
            p_ok = R.clf["perm"]["p"] < R.settings.alpha
            h.addWidget(chip(f"p {('= ' + fmt_p(R.clf['perm']['p'])) if not fmt_p(R.clf['perm']['p']).startswith('<') else fmt_p(R.clf['perm']['p'])}",
                             "ChipGreen" if p_ok else "ChipRed"))
            h.addWidget(chip(f"{tr('chance')}: {num(R.clf['chance'] * 100, 0)}%"))
            h.addStretch(1)
            bl.addLayout(h)
            bl.addStretch(1)
            best.setFixedWidth(330)
            row.addWidget(best)
        hi = Card(tr("highlights"))
        for line in report.summary_lines(R):
            l = QLabel("•  " + line.replace("&gt;", ">"))
            l.setWordWrap(True)
            l.setObjectName("Bullet")
            hi.lay.addWidget(l)
        hi.lay.addStretch(1)
        row.addWidget(hi, 1)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        row2.setSpacing(16)
        prof = Card(tr("group_profile"))
        keys = ["L", "W", "T", "Dg", "Phi", "V"]
        hdr = [tr("group")] + [f"{trait(t)} ({UNITS[t]})" if t in ("L", "W", "T", "V") else
                               f"{trait(t, short=True)} ({UNITS[t]})" for t in keys]
        rows = [[g] + [_ms(R, g, t) for t in keys] for g in R.groups]
        tb = make_table()
        set_model(tb, FrameModel(hdr, rows))
        prof.lay.addWidget(tb)
        row2.addWidget(prof)
        lay.addLayout(row2)
        pc = Card(tr("fig_pca"))
        pc.lay.addWidget(fig_widget(R, "pca", 1100))
        lay.addWidget(pc)


# =========================================================================
class PropsPage(ResultPage):
    title_key, sub_key = "props_title", "props_sub"

    def build(self, lay):
        R = self.R
        card = Card()
        head = QHBoxLayout()
        t = QLabel(tr("props_title"))
        t.setObjectName("CardTitle")
        head.addWidget(t)
        head.addStretch(1)
        b = btn(tr("export_xlsx"), "sheet")
        b.clicked.connect(self.window().export_excel)
        head.addWidget(b)
        card.lay.addLayout(head)
        tabs = QTabWidget()
        # summary
        hdr = [tr("trait")] + list(R.groups) + ([tr("pooled")] if len(R.groups) > 1 else [])
        rows = []
        for tt in TRAITS:
            r = [f"{trait(tt)} ({UNITS[tt]})"] + [_ms(R, g, tt) for g in R.groups]
            if len(R.groups) > 1:
                r.append(_ms(R, "__all__", tt))
            rows.append(r)
        t1 = make_table()
        set_model(t1, FrameModel(hdr, rows), first_w=260)
        w1 = QWidget()
        v1 = QVBoxLayout(w1)
        v1.setContentsMargins(0, 10, 0, 0)
        v1.addWidget(t1)
        note = QLabel(("Mean ± SD" if i18n.LANG == "en" else "Média ± DP"))
        note.setObjectName("Hint")
        v1.addWidget(note)
        v1.addStretch(1)
        tabs.addTab(w1, tr("tab_summary"))
        # detailed
        w2 = QWidget()
        v2 = QVBoxLayout(w2)
        v2.setContentsMargins(0, 10, 0, 0)
        sel = QComboBox()
        sel.addItems(R.groups + ([tr("pooled")] if len(R.groups) > 1 else []))
        sel.setFixedWidth(260)
        v2.addWidget(sel)
        t2 = make_table()
        v2.addWidget(t2)
        v2.addStretch(1)

        def fill(i):
            g = (R.groups + ["__all__"])[i]
            d = R.desc[R.desc.group == g]
            hdr2 = [tr("trait"), tr("n"), tr("mean"), tr("sd"), tr("se"), tr("cv"), tr("min"), tr("median"),
                    tr("max"), tr("ci95")]
            rr = [[f"{trait(x.trait)} ({UNITS[x.trait]})", int(x.n), num(x.mean), num(x.sd), num(x.se), num(x.cv, 1),
                   num(x.min), num(x.median), num(x.max), f"{num(x.ci_low)} – {num(x.ci_high)}"] for x in d.itertuples()]
            set_model(t2, FrameModel(hdr2, rr), first_w=250)
        sel.currentIndexChanged.connect(fill)
        fill(0)
        tabs.addTab(w2, tr("detailed"))
        # per seed
        w3 = QWidget()
        v3 = QVBoxLayout(w3)
        v3.setContentsMargins(0, 10, 0, 0)
        t3 = make_table()
        hdr3 = [tr("group"), tr("seed")] + [f"{trait(x, short=True)} ({UNITS[x]})" for x in TRAITS]
        rr3 = [[r.group, r.seed] + [num(getattr(r, x)) for x in TRAITS] for r in R.props.itertuples()]
        set_model(t3, FrameModel(hdr3, rr3, bold_first=False))
        t3.setFixedHeight(520)
        v3.addWidget(t3)
        tabs.addTab(w3, tr("tab_seed"))
        # assumptions
        w4 = QWidget()
        v4 = QVBoxLayout(w4)
        v4.setContentsMargins(0, 10, 0, 0)
        hdr4 = [tr("trait")] + [f"SW p · {g}" for g in R.groups] + ([tr("levene")] if len(R.groups) > 1 else [])
        rr4, cols = [], {}
        for i, x in enumerate(R.assum.itertuples()):
            row = [trait(x.trait)]
            for j, g in enumerate(R.groups):
                p = R.assum.iloc[i][f"sw_{g}"]
                row.append(fmt_p(p))
                if p < R.settings.alpha:
                    cols[(i, j + 1)] = C["red"]
            if len(R.groups) > 1:
                row.append(fmt_p(x.levene))
                if x.levene < R.settings.alpha:
                    cols[(i, len(row) - 1)] = C["red"]
            rr4.append(row)
        t4 = make_table()
        set_model(t4, FrameModel(hdr4, rr4, colors=cols), first_w=250)
        v4.addWidget(t4)
        n4 = QLabel(tr("sw_note"))
        n4.setObjectName("Hint")
        v4.addWidget(n4)
        v4.addStretch(1)
        tabs.addTab(w4, tr("tab_assum"))
        card.lay.addWidget(tabs)
        lay.addWidget(card)


# =========================================================================
class ComparePage(ResultPage):
    title_key, sub_key = "cmp_title", "cmp_sub"

    def build(self, lay):
        R = self.R
        if R.comp is None:
            self.empty.set(tr("cmp_title"), tr("single_group"))
            return False
        card = Card(tr("cmp_title"))
        hdr = [tr("trait")] + list(R.groups) + [tr("test"), tr("stat"), tr("p"), tr("effect"), tr("result")]
        eff = {"g": "g", "r_rb": "r", "eta2": "η²", "eps2": "ε²"}
        rows, cols, hl = [], {}, []
        for i, x in enumerate(R.comp.itertuples()):
            sig = x.p < R.settings.alpha
            r = [f"{trait(x.trait)} ({UNITS[x.trait]})"]
            for g in R.groups:
                r.append(f"{_ms(R, g, x.trait)}  {R.comp.iloc[i]['letter_' + g]}")
            r += [tr(x.test), num(x.stat, 2), fmt_p(x.p), f"{eff[x.effect_name]} = {num(x.effect, 3)}",
                  tr("sig") if sig else tr("ns")]
            rows.append(r)
            cols[(i, len(r) - 1)] = "#1B7A33" if sig else C["muted"]
            if sig:
                cols[(i, len(r) - 3)] = "#1B7A33"
        tb = make_table()
        set_model(tb, FrameModel(hdr, rows, colors=cols), first_w=250)
        card.lay.addWidget(tb)
        n = QLabel(tr("letters_note", a=num(R.settings.alpha, 2)))
        n.setObjectName("Hint")
        card.lay.addWidget(n)
        lay.addWidget(card)
        if R.pairs is not None and len(R.pairs):
            pc = Card(tr("pairwise"))
            hdr = [tr("trait"), tr("group") + " 1", tr("group") + " 2", "p (adj.)", tr("method")]
            rows, cols = [], {}
            for i, x in enumerate(R.pairs.itertuples()):
                rows.append([trait(x.trait), x.g1, x.g2, fmt_p(x.p_adj), x.method])
                if x.p_adj < R.settings.alpha:
                    cols[(i, 3)] = "#1B7A33"
            tb2 = make_table()
            set_model(tb2, FrameModel(hdr, rows, colors=cols), first_w=250)
            tb2.setFixedHeight(min(36 + len(rows) * 32 + 4, 420))
            pc.lay.addWidget(tb2)
            lay.addWidget(pc)
        fc = Card(tr("fig_box"))
        lbl = fig_widget(self.R, "box", 1000)
        fc.lay.addWidget(lbl)
        lay.addWidget(fc)


# =========================================================================
class MultiPage(ResultPage):
    title_key, sub_key = "multi_title", "multi_sub"

    def build(self, lay):
        R = self.R
        P = R.pca
        pcl = "PC" if i18n.LANG == "en" else "CP"
        row = QHBoxLayout()
        row.setSpacing(16)
        c1 = Card(tr("pca"))
        hdr = ["", tr("eigen"), tr("explained"), tr("cumulative")]
        n = min(5, len(P["eigen"]))
        rows = [[f"{pcl}{i + 1}", num(P["eigen"][i], 3), num(P["explained"][i], 1), num(P["cum"][i], 1)] for i in range(n)]
        t = make_table()
        set_model(t, FrameModel(hdr, rows, highlight_rows=range(P["retained"])))
        c1.lay.addWidget(t)
        c1.lay.addStretch(1)
        row.addWidget(c1, 2)
        c3 = Card(tr("loadings"))
        hdr = [tr("trait"), f"{pcl}1", f"{pcl}2", f"{pcl}3"]
        L = P["loadings"]
        rows, cols = [], {}
        for i, tt in enumerate(TRAITS):
            rows.append([trait(tt)] + [num(L.loc[tt, f"PC{k}"], 3) for k in (1, 2, 3)])
            for k in (1, 2, 3):
                if abs(L.loc[tt, f"PC{k}"]) >= 0.7:
                    cols[(i, k)] = C["blue"]
        t2 = make_table()
        set_model(t2, FrameModel(hdr, rows, colors=cols), first_w=230)
        c3.lay.addWidget(t2)
        row.addWidget(c3, 3)
        lay.addLayout(row)
        c2 = Card(tr("fig_pca"))
        c2.lay.addWidget(fig_widget(R, "pca", 1150))
        lay.addWidget(c2)

        # correlations
        cc = Card(tr("corr"))
        sel = QComboBox()
        keys = R.groups + (["__all__"] if len(R.groups) > 1 else [])
        sel.addItems([tr("pooled") if k == "__all__" else k for k in keys])
        sel.setFixedWidth(260)
        cc.lay.addWidget(sel)
        tc = make_table()
        cc.lay.addWidget(tc)
        hint = QLabel("* q < 0.05 (Benjamini-Hochberg)")
        hint.setObjectName("Hint")
        cc.lay.addWidget(hint)

        def fill(i):
            cr = R.corr[keys[i]]
            M, Q = cr["r"].to_numpy(), cr["q"].to_numpy()
            hdr = [""] + [trait(x, short=True) for x in TRAITS]
            rows, cols = [], {}
            for a, ta in enumerate(TRAITS):
                r = [trait(ta)]
                for b in range(len(TRAITS)):
                    if b > a:
                        r.append("")
                    elif a == b:
                        r.append("1")
                    else:
                        r.append(f"{num(M[a, b], 2)}{'*' if Q[a, b] < 0.05 else ''}")
                        if Q[a, b] < 0.05:
                            cols[(a, b + 1)] = "#B23446" if M[a, b] > 0 else C["blue"]
                rows.append(r)
            set_model(tc, FrameModel(hdr, rows, colors=cols), first_w=230)
        sel.currentIndexChanged.connect(fill)
        fill(0)
        lay.addWidget(cc)

        # clustering + SOM
        row3 = QHBoxLayout()
        row3.setSpacing(16)
        if R.clus:
            ck = Card(tr("clustering"))
            if R.clus["methods"]:
                hdr = [tr("method"), "k", tr("ari"), tr("silhouette")]
                rows = [[tr(m), R.clus["k_used"], num(v["ari"], 3), num(v["sil"], 3)] for m, v in R.clus["methods"].items()]
                t = make_table()
                set_model(t, FrameModel(hdr, rows))
                ck.lay.addWidget(t)
            s = QLabel(f"{tr('k_suggest')}: {R.clus['k_sil']} / {R.clus['k_bic']}")
            s.setObjectName("Muted")
            ck.lay.addWidget(s)
            ck.lay.addStretch(1)
            row3.addWidget(ck, 1)
        if R.som:
            S = R.som
            sc = Card(tr("som"))
            g = QGridLayout()
            g.setVerticalSpacing(8)
            items = [(tr("som_grid"), f"{S['side']} × {S['side']}"), (tr("qe"), num(S["qe"], 3)),
                     (tr("te"), num(S["te"], 3)), ("χ²", num(S["chi2"], 1)),
                     (tr("perm_p"), f"{fmt_p(S['p'])}  ({S['nperm']})")]
            for i, (a, b) in enumerate(items):
                la = QLabel(a)
                la.setObjectName("Muted")
                lb = QLabel(b)
                lb.setStyleSheet("font-weight:600;")
                lb.setAlignment(Qt.AlignRight)
                g.addWidget(la, i, 0)
                g.addWidget(lb, i, 1)
            sc.lay.addLayout(g)
            if len(R.groups) > 1:
                sig = S["p"] < R.settings.alpha
                sc.lay.addWidget(chip(f"{tr('segregation')}: {tr('yes_sig') if sig else tr('no_sig')}",
                                      "ChipGreen" if sig else "ChipRed"))
            sc.lay.addStretch(1)
            row3.addWidget(sc, 1)
        lay.addLayout(row3)
        if R.som:
            fc = Card(tr("fig_som"))
            lbl = fig_widget(R, "som", 1000)
            fc.lay.addWidget(lbl)
            lay.addWidget(fc)


# =========================================================================
class ModelsPage(ResultPage):
    title_key, sub_key = "mdl_title", "mdl_sub"

    def build(self, lay):
        R = self.R
        if not R.clf:
            self.empty.set(tr("mdl_title"), tr("no_models"))
            return False
        Cl = R.clf
        b = Cl["table"].iloc[0]
        top = QHBoxLayout()
        top.setSpacing(16)
        best = QFrame()
        best.setObjectName("BestCard")
        shadow(best)
        bl = QVBoxLayout(best)
        bl.setContentsMargins(22, 18, 22, 18)
        cap = QLabel(tr("best_model").upper())
        cap.setStyleSheet("color:#1B7A33;font-size:8pt;font-weight:700;letter-spacing:1px;")
        bl.addWidget(cap)
        nm = QLabel(tr(Cl["best"]))
        nm.setObjectName("BestTitle")
        bl.addWidget(nm)
        h = QHBoxLayout()
        h.setSpacing(28)
        for val, lab in [(f"{num(b['bacc'] * 100, 1)}%", tr("bacc")), (f"{num(b['acc'] * 100, 1)}%", tr("acc")),
                         (num(b["f1"], 3), tr("f1")), (num(b["auc"], 3), tr("auc"))]:
            v = QVBoxLayout()
            a = QLabel(val)
            a.setStyleSheet("font-family:Poppins;font-size:19pt;font-weight:600;color:#1B2730;")
            l = QLabel(lab)
            l.setObjectName("Muted")
            v.addWidget(a)
            v.addWidget(l)
            h.addLayout(v)
        h.addStretch(1)
        bl.addLayout(h)
        ch = QHBoxLayout()
        p_ok = Cl["perm"]["p"] < R.settings.alpha
        pp = fmt_p(Cl["perm"]["p"])
        ch.addWidget(chip(f"{tr('perm_p')} {pp if pp.startswith('<') else '= ' + pp}", "ChipGreen" if p_ok else "ChipRed"))
        ch.addWidget(chip(f"{tr('ci95')}: {num(b['bacc_lo'] * 100, 1)}–{num(b['bacc_hi'] * 100, 1)}%"))
        ch.addWidget(chip(f"{tr('validation')}: {tr('cv_desc', f=Cl['folds'], r=Cl['repeats'])}"))
        ch.addStretch(1)
        bl.addLayout(ch)
        top.addWidget(best, 3)
        ax = Cl["axes"]
        k1 = KpiCard(C["blue"])
        k1.set(f"{num(ax['full_bacc'] * 100, 1)}%", tr("all_traits"), tr("bacc"))
        k2 = KpiCard(C["amber"])
        k2.set(f"{num(ax['axes_bacc'] * 100, 1)}%", tr("axes_only"), tr("bacc"))
        kv = QVBoxLayout()
        kv.setSpacing(14)
        kv.addWidget(k1)
        kv.addWidget(k2)
        top.addLayout(kv, 1)
        lay.addLayout(top)

        card = Card(tr("mdl_title"))
        hdr = [tr("model"), f"{tr('bacc')} (%)", f"{tr('acc')} (%)", tr("f1"), tr("auc"), tr("ci95")]
        rows = []
        for x in Cl["table"].itertuples():
            rows.append([tr(x.model), f"{num(x.bacc * 100, 1)} ± {num(x.bacc_sd * 100, 1)}",
                         f"{num(x.acc * 100, 1)} ± {num(x.acc_sd * 100, 1)}", num(x.f1, 3), num(x.auc, 3),
                         f"{num(x.bacc_lo * 100, 1)} – {num(x.bacc_hi * 100, 1)}"])
        t = make_table()
        set_model(t, FrameModel(hdr, rows, highlight_rows=[0]), first_w=240)
        card.lay.addWidget(t)
        lay.addWidget(card)
        for key in ("models", "cm"):
            fc = Card(tr("fig_" + key))
            fc.lay.addWidget(fig_widget(R, key, 1100))
            lay.addWidget(fc)
