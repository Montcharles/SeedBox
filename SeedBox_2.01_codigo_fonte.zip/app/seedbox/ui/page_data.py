"""Data input page."""
import pandas as pd
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QKeySequence, QColor, QGuiApplication
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QLabel, QSpinBox, QTableWidget, QTableWidgetItem,
                               QHeaderView, QListWidget, QListWidgetItem, QGridLayout, QFileDialog, QMessageBox,
                               QAbstractItemView, QSizePolicy, QFrame)

from ..i18n import tr
from .. import core, io_import, export
from .widgets import Card, btn, chip
from .dialogs import MappingDialog
from .theme import C

COLS = ["group", "seed", "L", "W", "T"]


class SeedTable(QTableWidget):
    pasted = Signal()

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Paste):
            self.paste()
            return
        if e.matches(QKeySequence.Copy):
            self.copy()
            return
        if e.key() in (Qt.Key_Delete, Qt.Key_Backspace) and len(self.selectedIndexes()) > 1:
            self.blockSignals(True)
            for ix in self.selectedIndexes():
                it = self.item(ix.row(), ix.column())
                if it:
                    it.setText("")
            self.blockSignals(False)
            self.pasted.emit()
            return
        super().keyPressEvent(e)

    def copy(self):
        idx = sorted(self.selectedIndexes(), key=lambda i: (i.row(), i.column()))
        if not idx:
            return
        rows = {}
        for i in idx:
            it = self.item(i.row(), i.column())
            rows.setdefault(i.row(), []).append(it.text() if it else "")
        QGuiApplication.clipboard().setText("\n".join("\t".join(v) for v in rows.values()))

    def paste(self):
        txt = QGuiApplication.clipboard().text()
        if not txt:
            return
        lines = [l for l in txt.replace("\r", "").split("\n") if l.strip() != ""]
        r0 = max(self.currentRow(), 0)
        c0 = max(self.currentColumn(), 0)
        need = r0 + len(lines)
        self.blockSignals(True)
        if need > self.rowCount():
            self.setRowCount(need)
        for i, line in enumerate(lines):
            for j, val in enumerate(line.split("\t")):
                c = c0 + j
                if c >= self.columnCount():
                    break
                self.setItem(r0 + i, c, QTableWidgetItem(val.strip()))
        self.blockSignals(False)
        self.pasted.emit()


class DataPage(QWidget):
    changed = Signal()
    run_requested = Signal()
    title_key, sub_key = "data_title", "data_sub"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Content")
        root = QHBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(18)

        # ---------- left column
        left = QVBoxLayout()
        left.setSpacing(14)
        self.card_imp = Card(tr("import_file"))
        self.b_import = btn(tr("import_file"), "upload", "Blue")
        self.b_template = btn(tr("template"), "download")
        self.b_example = btn(tr("example"), "spark")
        self.card_imp.lay.addWidget(self.b_import)
        self.card_imp.lay.addWidget(self.b_template)
        self.card_imp.lay.addWidget(self.b_example)
        left.addWidget(self.card_imp)

        self.card_man = Card(tr("manual_title"))
        g = QGridLayout()
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(8)
        self.l_ng = QLabel(tr("n_groups"))
        self.l_ns = QLabel(tr("n_seeds"))
        self.sp_g = QSpinBox()
        self.sp_g.setRange(1, 30)
        self.sp_g.setValue(2)
        self.sp_s = QSpinBox()
        self.sp_s.setRange(3, 5000)
        self.sp_s.setValue(100)
        self.sp_g.setFixedWidth(96)
        self.sp_s.setFixedWidth(96)
        g.addWidget(self.l_ng, 0, 0)
        g.addWidget(self.sp_g, 0, 1)
        g.addWidget(self.l_ns, 1, 0)
        g.addWidget(self.sp_s, 1, 1)
        self.card_man.lay.addLayout(g)
        self.b_create = btn(tr("create_table"), "table")
        self.card_man.lay.addWidget(self.b_create)
        left.addWidget(self.card_man)

        self.card_lots = Card(tr("group_names"))
        self.lots = QListWidget()
        self.lots.setFixedHeight(96)
        self.lots.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed |
                                  QAbstractItemView.SelectedClicked)
        self.card_lots.lay.addWidget(self.lots)
        left.addWidget(self.card_lots)

        self.card_sum = Card(tr("summary"))
        self.sum_grid = QGridLayout()
        self.sum_grid.setVerticalSpacing(4)
        self.s_lab = {}
        self.s_val = {}
        for i, k in enumerate(["valid_seeds", "lots", "incomplete", "axis_order"]):
            a = QLabel(tr(k))
            a.setObjectName("Muted")
            b = QLabel("0")
            b.setStyleSheet("font-weight:600;")
            b.setAlignment(Qt.AlignRight)
            a.setMinimumHeight(20)
            b.setMinimumHeight(20)
            self.sum_grid.addWidget(a, i, 0)
            self.sum_grid.addWidget(b, i, 1)
            self.s_lab[k], self.s_val[k] = a, b
        self.s_lab["axis_order"].setToolTip(tr("axis_order_tip"))
        self.card_sum.lay.addLayout(self.sum_grid)
        self.b_run = btn(tr("run"), "play", "Primary")
        self.b_run.setMinimumHeight(40)
        self.card_sum.lay.addSpacing(4)
        self.card_sum.lay.addWidget(self.b_run)
        left.addWidget(self.card_sum)
        left.addStretch(1)

        lw = QWidget()
        lw.setObjectName("LeftCol")
        lw.setStyleSheet(f"QWidget#LeftCol{{background:{C['bg']};}}")
        left.setContentsMargins(0, 0, 10, 0)
        lw.setLayout(left)
        from PySide6.QtWidgets import QScrollArea
        ls = QScrollArea()
        ls.setWidgetResizable(True)
        ls.setFrameShape(QFrame.NoFrame)
        ls.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        ls.setWidget(lw)
        ls.viewport().setObjectName("LeftVp")
        ls.viewport().setStyleSheet(f"QWidget#LeftVp{{background:{C['bg']};}}")
        ls.setFixedWidth(356)
        root.addWidget(ls)

        # ---------- table
        self.card_tab = Card(tr("data_title"), tr("paste_hint"))
        tb = QHBoxLayout()
        self.b_add = btn(tr("add_rows"), "plus")
        self.b_del = btn(tr("remove_rows"), "trash")
        self.b_clear = btn(tr("clear"), kind="Ghost")
        tb.addWidget(self.b_add)
        tb.addWidget(self.b_del)
        tb.addStretch(1)
        tb.addWidget(self.b_clear)
        self.card_tab.lay.addLayout(tb)
        self.table = SeedTable(0, 5)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setDefaultSectionSize(28)
        self.table.verticalHeader().setStyleSheet(f"QHeaderView::section{{color:{C['muted']};font-weight:400;}}")
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.card_tab.lay.addWidget(self.table, 1)
        root.addWidget(self.card_tab, 1)

        # ---------- signals
        self.b_import.clicked.connect(self.import_file)
        self.b_template.clicked.connect(self.save_template)
        self.b_example.clicked.connect(self.load_example)
        self.b_create.clicked.connect(self.create_table)
        self.b_add.clicked.connect(self.add_rows)
        self.b_del.clicked.connect(self.remove_rows)
        self.b_clear.clicked.connect(self.clear)
        self.b_run.clicked.connect(self.run_requested)
        self.table.itemChanged.connect(self._on_edit)
        self.table.pasted.connect(self._on_edit)
        self.lots.itemChanged.connect(self._rename_lot)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self._refresh_summary)
        self.retranslate()
        self.create_table()

    # ------------------------------------------------------------------
    def retranslate(self):
        self.card_imp.set_title(tr("import_file"))
        self.b_import.setText(tr("import_file"))
        self.b_template.setText(tr("template"))
        self.b_example.setText(tr("example"))
        self.card_man.set_title(tr("manual_title"))
        self.l_ng.setText(tr("n_groups"))
        self.l_ns.setText(tr("n_seeds"))
        self.b_create.setText(tr("create_table"))
        self.card_lots.set_title(tr("group_names"))
        self.card_sum.set_title(tr("summary"))
        for k, l in self.s_lab.items():
            l.setText(tr(k))
        self.s_lab["axis_order"].setToolTip(tr("axis_order_tip"))
        self.b_run.setText(tr("run"))
        self.card_tab.set_title(tr("data_title"), tr("paste_hint"))
        self.b_add.setText(tr("add_rows"))
        self.b_del.setText(tr("remove_rows"))
        self.b_clear.setText(tr("clear"))
        self.table.setHorizontalHeaderLabels([tr("group"), tr("seed"), f"{tr('length')} (mm)",
                                              f"{tr('width')} (mm)", f"{tr('thickness')} (mm)"])

    # ------------------------------------------------------------------
    def set_frame(self, df):
        self.table.blockSignals(True)
        self.table.setRowCount(len(df))
        for i, row in enumerate(df.itertuples(index=False)):
            d = row._asdict()
            vals = [d.get("group", ""), d.get("seed", i + 1), d.get("L", ""), d.get("W", ""), d.get("T", "")]
            for j, v in enumerate(vals):
                if v is None or (isinstance(v, float) and pd.isna(v)):
                    v = ""
                elif j >= 2 and isinstance(v, float):
                    v = f"{v:g}"
                elif j == 1 and isinstance(v, float) and v.is_integer():
                    v = str(int(v))
                it = QTableWidgetItem(str(v))
                if j >= 1:
                    it.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, j, it)
        self.table.blockSignals(False)
        self._on_edit()

    def get_frame(self):
        rows = []
        for i in range(self.table.rowCount()):
            vals = []
            for j in range(5):
                it = self.table.item(i, j)
                vals.append(it.text().strip() if it else "")
            if not any(vals[2:]):
                continue
            rows.append(vals)
        df = pd.DataFrame(rows, columns=COLS)
        df["seed"] = pd.to_numeric(df["seed"], errors="coerce")
        df["seed"] = df["seed"].fillna(pd.Series(range(1, len(df) + 1))).astype(int)
        return df

    def has_data(self):
        f = self.get_frame()
        return len(f) > 0

    # ------------------------------------------------------------------
    def create_table(self):
        if self.has_data() and QMessageBox.question(self, tr("warning"), tr("confirm_clear")) != QMessageBox.Yes:
            return
        ng, ns = self.sp_g.value(), self.sp_s.value()
        rows = [(f"{tr('lot')} {g + 1}", s + 1, None, None, None) for g in range(ng) for s in range(ns)]
        self.set_frame(pd.DataFrame(rows, columns=COLS))

    def add_rows(self):
        n = self.table.rowCount()
        last_group = ""
        if n:
            it = self.table.item(n - 1, 0)
            last_group = it.text() if it else ""
        self.table.blockSignals(True)
        self.table.setRowCount(n + 10)
        for i in range(n, n + 10):
            self.table.setItem(i, 0, QTableWidgetItem(last_group))
            it = QTableWidgetItem(str(i + 1))
            it.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 1, it)
        self.table.blockSignals(False)
        self.table.scrollToBottom()
        self._on_edit()

    def remove_rows(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        self.table.blockSignals(True)
        for r in rows:
            self.table.removeRow(r)
        self.table.blockSignals(False)
        self._on_edit()

    def clear(self):
        if self.has_data() and QMessageBox.question(self, tr("warning"), tr("confirm_clear")) != QMessageBox.Yes:
            return
        self.table.setRowCount(0)
        self._on_edit()

    def load_example(self):
        if self.has_data() and QMessageBox.question(self, tr("warning"), tr("confirm_clear")) != QMessageBox.Yes:
            return
        self.set_frame(core.example_dataset())

    def save_template(self):
        from .main_window import last_dir, remember_dir
        from .. import i18n
        name = "SeedBox_template.xlsx" if i18n.LANG == "en" else "SeedBox_modelo.xlsx"
        p, _ = QFileDialog.getSaveFileName(self, tr("template"), f"{last_dir()}/{name}", "Excel (*.xlsx)")
        if not p:
            return
        remember_dir(p)
        export.template(p, self.sp_g.value(), self.sp_s.value())

    def import_file(self):
        from .main_window import last_dir, remember_dir
        p, _ = QFileDialog.getOpenFileName(self, tr("import_file"), last_dir(),
                                           "Excel / CSV (*.xlsx *.xlsm *.xls *.csv *.txt)")
        if not p:
            return
        remember_dir(p)
        try:
            df, sheets, guess = io_import.load(p)
        except Exception as e:
            QMessageBox.critical(self, tr("error"), f"{tr('import_fail')}\n\n{e}")
            return
        if df is None:
            dlg = MappingDialog(sheets, guess, self)
            if dlg.exec() != MappingDialog.Accepted:
                return
            try:
                df = dlg.result_frame()
            except Exception as e:
                QMessageBox.critical(self, tr("error"), f"{tr('import_fail')}\n\n{e}")
                return
        if "seed" not in df.columns:
            df["seed"] = df.groupby("group", sort=False).cumcount() + 1
        self.set_frame(df[COLS])
        n = df[["L", "W", "T"]].notna().all(axis=1).sum()
        self.window().flash(tr("import_ok", n=int(n), g=df["group"].nunique()))

    # ------------------------------------------------------------------
    def _on_edit(self, *a):
        self._timer.start()
        self.changed.emit()

    def _refresh_summary(self):
        df = self.get_frame()
        bad_brush = QColor("#FDECEE")
        self.table.blockSignals(True)
        nbad = 0
        for i in range(self.table.rowCount()):
            for j in (2, 3, 4):
                it = self.table.item(i, j)
                if not it or not it.text().strip():
                    if it:
                        it.setBackground(QColor(0, 0, 0, 0))
                    continue
                try:
                    ok = float(it.text().replace(",", ".")) > 0
                except ValueError:
                    ok = False
                it.setBackground(QColor(0, 0, 0, 0) if ok else bad_brush)
                nbad += (not ok)
        self.table.blockSignals(False)
        if len(df):
            clean, rep = core.clean_input(df)
            nvalid, nlots, inc, order = rep["valid"], clean["group"].nunique(), rep["missing"] + rep["nonpositive"], rep["order"]
        else:
            nvalid = nlots = inc = order = 0
        self.s_val["valid_seeds"].setText(str(nvalid))
        self.s_val["lots"].setText(str(nlots))
        self.s_val["incomplete"].setText(str(inc))
        self.s_val["incomplete"].setStyleSheet(f"font-weight:600;color:{C['red'] if inc else C['ink']};")
        self.s_val["axis_order"].setText(str(order))
        self.s_val["axis_order"].setStyleSheet(f"font-weight:600;color:{C['amber'] if order else C['ink']};")
        self.b_run.setEnabled(nvalid >= 3)
        # lots list
        groups = []
        for i in range(self.table.rowCount()):
            it = self.table.item(i, 0)
            t = it.text().strip() if it else ""
            if t and t not in groups:
                groups.append(t)
        self.lots.blockSignals(True)
        self.lots.clear()
        counts = df["group"].value_counts() if len(df) else {}
        for gname in groups:
            it = QListWidgetItem(gname)
            it.setData(Qt.UserRole, gname)
            it.setFlags(it.flags() | Qt.ItemIsEditable)
            n = int(counts.get(gname, 0)) if len(df) else 0
            it.setToolTip(f"{n} {tr('seeds')}")
            self.lots.addItem(it)
        self.lots.blockSignals(False)

    def _rename_lot(self, item):
        old = item.data(Qt.UserRole)
        new = item.text().strip()
        if not new or new == old:
            return
        self.table.blockSignals(True)
        for i in range(self.table.rowCount()):
            it = self.table.item(i, 0)
            if it and it.text().strip() == old:
                it.setText(new)
        self.table.blockSignals(False)
        item.setData(Qt.UserRole, new)
        self._on_edit()
