"""Visual theme: palette, stylesheet and icons."""
from PySide6.QtCore import Qt, QByteArray, QRectF
from PySide6.QtGui import QIcon, QPixmap, QPainter, QFontDatabase, QFont
from PySide6.QtSvg import QSvgRenderer

from ..paths import asset

C = dict(
    side="#0D1B26", side2="#0A151E", side_text="#A9BBC8", side_muted="#5D7384", side_hover="#14283A",
    bg="#F3F6F8", card="#FFFFFF", border="#E1E7EC", ink="#1B2730", muted="#6B7B88",
    green="#2EA043", green_d="#238636", green_soft="#E8F5EB", blue="#1684C4", blue_soft="#E6F2FA",
    red="#D1495B", amber="#E9A23B", head="#F6F8FA", sel="#DCEEFB",
)

HEAD_FONT = "Poppins"


def load_fonts():
    for f in ["Poppins-Regular.ttf", "Poppins-Medium.ttf", "Poppins-Bold.ttf", "Poppins-Light.ttf"]:
        QFontDatabase.addApplicationFont(asset("fonts", f))


def ui_font():
    fams = set(QFontDatabase.families())
    for f in ["Segoe UI Variable Text", "Segoe UI", "Inter", "Noto Sans", "DejaVu Sans"]:
        if f in fams:
            return f
    return QFont().defaultFamily()


def stylesheet():
    f = ui_font()
    return f"""
* {{ font-family: "{f}"; font-size: 10pt; color: {C['ink']}; }}
QMainWindow, #Content {{ background: {C['bg']}; }}
QToolTip {{ background: {C['ink']}; color: white; border: none; padding: 6px 8px; border-radius: 4px; }}

/* ---------- sidebar */
#Sidebar {{ background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {C['side']}, stop:1 {C['side2']}); }}
#Sidebar QLabel {{ color: {C['side_text']}; }}
#Brand {{ font-family: "{HEAD_FONT}"; font-size: 17pt; font-weight: 700; color: white; }}
#BrandSub {{ font-family: "{HEAD_FONT}"; font-size: 7pt; letter-spacing: 0.8px; color: {C['side_muted']}; }}
#NavSection {{ font-size: 7.5pt; font-weight: 600; letter-spacing: 1.2px; color: {C['side_muted']}; padding: 14px 0 4px 22px; }}
#NavButton {{ text-align: left; padding: 9px 14px 9px 19px; border: none; border-left: 3px solid transparent;
             color: {C['side_text']}; background: transparent; font-size: 10pt; }}
#NavButton:hover {{ background: {C['side_hover']}; color: white; }}
#NavButton:checked {{ background: rgba(46,160,67,0.16); border-left: 3px solid {C['green']}; color: white; font-weight: 600; }}
#NavButton:disabled {{ color: #3E5262; }}
#SideFooter {{ color: {C['side_muted']}; font-size: 8pt; }}
#SideLink {{ color: {C['side_text']}; background: transparent; border: none; text-align: left; padding: 6px 22px; font-size: 9pt; }}
#SideLink:hover {{ color: white; }}

/* ---------- top bar */
#TopBar {{ background: white; border-bottom: 1px solid {C['border']}; }}
#PageTitle {{ font-family: "{HEAD_FONT}"; font-size: 15pt; font-weight: 600; color: {C['ink']}; }}
#PageSub {{ color: {C['muted']}; font-size: 9.5pt; }}
#LangBox {{ background: {C['bg']}; border: 1px solid {C['border']}; border-radius: 8px; }}
#LangBtn {{ border: none; padding: 5px 11px; border-radius: 6px; background: transparent; color: {C['muted']};
            font-weight: 600; font-size: 9pt; }}
#LangBtn:checked {{ background: white; color: {C['ink']}; border: 1px solid {C['border']}; }}

/* ---------- cards */
#Card {{ background: {C['card']}; border: 1px solid {C['border']}; border-radius: 12px; }}
#CardTitle {{ font-family: "{HEAD_FONT}"; font-size: 11pt; font-weight: 600; color: {C['ink']}; }}
#CardSub {{ color: {C['muted']}; font-size: 9pt; }}
#KpiValue {{ font-family: "{HEAD_FONT}"; font-size: 21pt; font-weight: 600; color: {C['ink']}; }}
#KpiLabel {{ color: {C['muted']}; font-size: 8.8pt; }}
#KpiAccent {{ border-radius: 2px; }}
#Muted {{ color: {C['muted']}; }}
#Hint {{ color: {C['muted']}; font-size: 8.8pt; }}
#BestCard {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #EAF6ED, stop:1 #F4FAF6);
             border: 1px solid #CBE8D2; border-left: 4px solid {C['green']}; border-radius: 12px; }}
#BestTitle {{ font-family: "{HEAD_FONT}"; font-size: 16pt; font-weight: 600; color: #1B6E30; }}
#Chip {{ background: {C['blue_soft']}; color: {C['blue']}; border-radius: 10px; padding: 3px 10px; font-size: 8.8pt; font-weight: 600; }}
#ChipGreen {{ background: {C['green_soft']}; color: #1B7A33; border-radius: 10px; padding: 3px 10px; font-size: 8.8pt; font-weight: 600; }}
#ChipRed {{ background: #FBEAEC; color: #B23446; border-radius: 10px; padding: 3px 10px; font-size: 8.8pt; font-weight: 600; }}
#Bullet {{ font-size: 10pt; color: {C['ink']}; }}

/* ---------- buttons */
QPushButton {{ background: white; border: 1px solid {C['border']}; border-radius: 8px; padding: 7px 14px; font-weight: 500; }}
QPushButton:hover {{ border-color: #B9C6D0; background: #FAFBFC; }}
QPushButton:pressed {{ background: {C['bg']}; }}
QPushButton:disabled {{ color: #A8B4BD; background: #F7F9FA; }}
QPushButton#Primary {{ background: {C['green']}; color: white; border: 1px solid {C['green_d']}; font-weight: 600; padding: 8px 18px; }}
QPushButton#Primary:hover {{ background: {C['green_d']}; }}
QPushButton#Primary:disabled {{ background: #9DD3A9; border-color: #9DD3A9; color: white; }}
QPushButton#Blue {{ background: {C['blue']}; color: white; border: 1px solid #0F6EA6; font-weight: 600; }}
QPushButton#Blue:hover {{ background: #0F6EA6; }}
QPushButton#Ghost {{ background: transparent; border: none; color: {C['muted']}; padding: 6px 8px; }}
QPushButton#Ghost:hover {{ color: {C['ink']}; background: {C['bg']}; }}

/* ---------- inputs */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit, QTextEdit {{
    background: white; border: 1px solid {C['border']}; border-radius: 7px; padding: 6px 8px; selection-background-color: {C['sel']}; selection-color: {C['ink']}; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus {{ border: 1px solid {C['blue']}; }}
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{ width: 18px; border: none; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ border: 1px solid {C['border']}; selection-background-color: {C['sel']}; selection-color: {C['ink']}; outline: 0; padding: 4px; }}
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid #B9C6D0; background: white; }}
QCheckBox::indicator:checked {{ background: {C['green']}; border-color: {C['green_d']}; image: url(CHECK_ICON); }}

/* ---------- tables */
QTableView, QTableWidget {{ background: white; border: 1px solid {C['border']}; border-radius: 10px; gridline-color: #EEF2F5;
    selection-background-color: {C['sel']}; selection-color: {C['ink']}; alternate-background-color: #FAFBFC; }}
QHeaderView::section {{ background: {C['head']}; color: #3D4D59; font-weight: 600; font-size: 9pt; padding: 7px 8px;
    border: none; border-bottom: 1px solid {C['border']}; border-right: 1px solid #EEF2F5; }}
QTableCornerButton::section {{ background: {C['head']}; border: none; }}

QListWidget {{ background: white; border: 1px solid {C['border']}; border-radius: 10px; padding: 6px; outline: 0; }}
QListWidget::item {{ padding: 8px 10px; border-radius: 7px; margin: 1px 0; }}
QListWidget::item:hover {{ background: {C['bg']}; }}
QListWidget::item:selected {{ background: {C['blue_soft']}; color: {C['ink']}; font-weight: 600; }}

QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: transparent; color: {C['muted']}; padding: 8px 16px; border: none; border-bottom: 2px solid transparent; font-weight: 600; }}
QTabBar::tab:selected {{ color: {C['ink']}; border-bottom: 2px solid {C['green']}; }}
QTabBar::tab:hover {{ color: {C['ink']}; }}

QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #C9D3DA; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #AAB8C2; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: #C9D3DA; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

QProgressBar {{ background: #E8EDF1; border: none; border-radius: 4px; height: 8px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ border-radius: 4px; background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {C['green']}, stop:1 {C['blue']}); }}

QDialog {{ background: white; }}
QMessageBox {{ background: white; }}
QMenu {{ background: white; border: 1px solid {C['border']}; padding: 4px; }}
QMenu::item {{ padding: 6px 18px; border-radius: 5px; }}
QMenu::item:selected {{ background: {C['bg']}; }}
#StatusBar {{ background: white; border-top: 1px solid {C['border']}; }}
#StatusText {{ color: {C['muted']}; font-size: 8.8pt; }}
"""


# ---------------------------------------------------------------- icons
_P = {
    "data": '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
    "overview": '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
    "props": '<path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z"/><path d="m14.5 12.5 2-2"/><path d="m11.5 9.5 2-2"/><path d="m8.5 6.5 2-2"/><path d="m17.5 15.5 2-2"/>',
    "compare": '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
    "multi": '<path d="M3 3v18h18"/><circle cx="9" cy="14" r="1.6"/><circle cx="13" cy="9" r="1.6"/><circle cx="17.5" cy="12.5" r="1.6"/><circle cx="18" cy="6" r="1.6"/>',
    "models": '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2"/>',
    "figures": '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
    "report": '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8M16 13H8M16 17H8"/>',
    "settings": '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    "play": '<polygon points="7 4 20 12 7 20 7 4"/>',
    "upload": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    "download": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    "plus": '<path d="M5 12h14M12 5v14"/>',
    "trash": '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    "info": '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    "spark": '<path d="M12 3l1.9 5.8L20 10l-6.1 1.2L12 17l-1.9-5.8L4 10l6.1-1.2z"/>',
    "zip": '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>',
    "check": '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
    "save": '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>',
    "sheet": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/>',
    "table": '<path d="M12 3v18"/><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18M3 15h18"/>',
    "tick": '<polyline points="20 6 9 17 4 12"/>',
    "pdf": '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M9 15h6M9 18h4"/>',
    "open": '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
}


def icon(name, color="#1B2730", size=20, stroke=2.0):
    body = _P[name]
    fill = color if name == "play" else "none"
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="{fill}" '
           f'stroke="{color}" stroke-width="{stroke}" stroke-linecap="round" stroke-linejoin="round">{body}</svg>')
    r = QSvgRenderer(QByteArray(svg.encode()))
    pm = QPixmap(size * 2, size * 2)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    r.render(p, QRectF(0, 0, size * 2, size * 2))
    p.end()
    pm.setDevicePixelRatio(2.0)
    return QIcon(pm)


def nav_icon(name):
    ic = QIcon()
    for mode, col in [(QIcon.Normal, C["side_text"]), (QIcon.Active, "#FFFFFF"), (QIcon.Selected, "#FFFFFF"),
                      (QIcon.Disabled, "#3E5262")]:
        for state in (QIcon.Off,):
            ic.addPixmap(icon(name, col, 18).pixmap(36, 36), mode, state)
    ic.addPixmap(icon(name, "#FFFFFF", 18).pixmap(36, 36), QIcon.Normal, QIcon.On)
    return ic


def check_icon_path():
    import os, tempfile
    from ..paths import user_dir
    p = os.path.join(user_dir(), "check.svg")
    if not os.path.exists(p):
        with open(p, "w") as f:
            f.write('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" '
                    'stroke="white" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">'
                    '<polyline points="20 6 9 17 4 12"/></svg>')
    return p.replace("\\", "/")
