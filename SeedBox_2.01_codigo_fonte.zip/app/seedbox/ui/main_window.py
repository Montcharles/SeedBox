"""Main window."""
import os
import time
import traceback

from PySide6.QtCore import Qt, QThread, Signal, QObject, QSettings, QTimer, QSize, QUrl
from PySide6.QtGui import QPixmap, QIcon, QDesktopServices
from PySide6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QStackedWidget,
                               QButtonGroup, QFrame, QFileDialog, QMessageBox, QSizePolicy, QApplication)

from .. import core, i18n, report, export, __version__
from ..i18n import tr
from ..paths import asset
from .theme import C, nav_icon, icon
from .widgets import btn
from .dialogs import SettingsDialog, AboutDialog, ProgressDialog
from .page_data import DataPage
from .page_results import OverviewPage, PropsPage, ComparePage, MultiPage, ModelsPage
from .page_output import FiguresPage, ReportPage

_settings = None
_translator = None


def apply_qt_translator(lang):
    """Standard dialog buttons in the selected language."""
    global _translator
    from PySide6.QtCore import QTranslator, QLibraryInfo
    app = QApplication.instance()
    if _translator is not None:
        app.removeTranslator(_translator)
        _translator = None
    if lang == "pt":
        t = QTranslator()
        if t.load("qtbase_pt_BR", QLibraryInfo.path(QLibraryInfo.TranslationsPath)):
            app.installTranslator(t)
            _translator = t


def settings():
    global _settings
    if _settings is None:
        _settings = QSettings("SeedBox", "SeedBox")
    return _settings


def last_dir():
    d = settings().value("last_dir", "")
    return d if d and os.path.isdir(d) else os.path.expanduser("~")


def remember_dir(path):
    settings().setValue("last_dir", os.path.dirname(path))


class Worker(QThread):
    progress = Signal(float, str)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, *a, **kw):
        super().__init__()
        self.fn, self.a, self.kw = fn, a, kw

    def run(self):
        try:
            res = self.fn(*self.a, progress=lambda f, m="": self.progress.emit(float(f), m), **self.kw)
            self.done.emit(res)
        except Exception as e:
            self.failed.emit(f"{e}\n\n{traceback.format_exc()}")


NAV = [
    ("nav_section_input", None),
    ("nav_data", "data"),
    ("nav_section_results", None),
    ("nav_overview", "overview"),
    ("nav_props", "props"),
    ("nav_compare", "compare"),
    ("nav_multi", "multi"),
    ("nav_models", "models"),
    ("nav_section_output", None),
    ("nav_figures", "figures"),
    ("nav_report", "report"),
]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SeedBox — Dimensional Morphometry")
        self.setWindowIcon(QIcon(asset("emblem.png")))
        self.resize(1440, 900)
        self.setMinimumSize(1180, 720)
        self.R = None
        self.dirty = False
        apply_qt_translator(i18n.LANG)
        self.st = core.Settings()
        self._load_settings()

        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.setCentralWidget(central)

        # ---------------- sidebar
        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(248)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(0, 18, 0, 14)
        sv.setSpacing(0)
        brand = QHBoxLayout()
        brand.setContentsMargins(18, 0, 14, 8)
        em = QLabel()
        em.setPixmap(QPixmap(asset("emblem.png")).scaled(46, 46, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        brand.addWidget(em)
        bt = QVBoxLayout()
        bt.setSpacing(0)
        name = QLabel('<span style="color:#3FB950">Seed</span><span style="color:#2A9BE0">Box</span>')
        name.setObjectName("Brand")
        self.brand_sub = QLabel(tr("app_sub").upper())
        self.brand_sub.setObjectName("BrandSub")
        bt.addWidget(name)
        bt.addWidget(self.brand_sub)
        brand.addLayout(bt, 1)
        sv.addLayout(brand)
        sv.addSpacing(6)
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_btns = {}
        self.nav_secs = {}
        self.stack = QStackedWidget()
        self.pages = {
            "data": DataPage(), "overview": OverviewPage(), "props": PropsPage(), "compare": ComparePage(),
            "multi": MultiPage(), "models": ModelsPage(), "figures": FiguresPage(), "report": ReportPage(),
        }
        for k, p in self.pages.items():
            self.stack.addWidget(p)
        for key, ic in NAV:
            if ic is None:
                l = QLabel(tr(key))
                l.setObjectName("NavSection")
                self.nav_secs[key] = l
                sv.addWidget(l)
                continue
            b = QPushButton(tr(key))
            b.setObjectName("NavButton")
            b.setCheckable(True)
            b.setIcon(nav_icon(ic))
            b.setIconSize(QSize(18, 18))
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=ic: self.go(k))
            self.nav_group.addButton(b)
            self.nav_btns[ic] = (b, key)
            sv.addWidget(b)
        sv.addStretch(1)
        self.b_settings = QPushButton(tr("settings"))
        self.b_settings.setObjectName("SideLink")
        self.b_settings.setIcon(icon("settings", C["side_text"], 16))
        self.b_settings.setCursor(Qt.PointingHandCursor)
        self.b_settings.clicked.connect(self.open_settings)
        self.b_about = QPushButton(tr("about"))
        self.b_about.setObjectName("SideLink")
        self.b_about.setIcon(icon("info", C["side_text"], 16))
        self.b_about.setCursor(Qt.PointingHandCursor)
        self.b_about.clicked.connect(lambda: AboutDialog(self).exec())
        sv.addWidget(self.b_settings)
        sv.addWidget(self.b_about)
        ver = QLabel(f"v{__version__}")
        ver.setObjectName("SideFooter")
        ver.setContentsMargins(22, 8, 0, 0)
        sv.addWidget(ver)
        root.addWidget(side)

        # ---------------- main column
        main = QVBoxLayout()
        main.setContentsMargins(0, 0, 0, 0)
        main.setSpacing(0)
        top = QFrame()
        top.setObjectName("TopBar")
        top.setFixedHeight(72)
        th = QHBoxLayout(top)
        th.setContentsMargins(26, 10, 22, 10)
        tv = QVBoxLayout()
        tv.setSpacing(0)
        self.p_title = QLabel()
        self.p_title.setObjectName("PageTitle")
        self.p_sub = QLabel()
        self.p_sub.setObjectName("PageSub")
        tv.addWidget(self.p_title)
        tv.addWidget(self.p_sub)
        th.addLayout(tv, 1)
        lang = QFrame()
        lang.setObjectName("LangBox")
        lh = QHBoxLayout(lang)
        lh.setContentsMargins(3, 3, 3, 3)
        lh.setSpacing(2)
        self.lang_btns = {}
        lg = QButtonGroup(self)
        for code, lab in [("pt", "PT"), ("en", "EN")]:
            b = QPushButton(lab)
            b.setObjectName("LangBtn")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=code: self.set_lang(c))
            lg.addButton(b)
            lh.addWidget(b)
            self.lang_btns[code] = b
        self.lang_btns[i18n.LANG].setChecked(True)
        th.addWidget(lang)
        th.addSpacing(10)
        self.b_run = btn(tr("run"), "play", "Primary")
        self.b_run.setMinimumHeight(38)
        self.b_run.clicked.connect(self.run_analysis)
        th.addWidget(self.b_run)
        main.addWidget(top)
        self.banner = QLabel()
        self.banner.setVisible(False)
        self.banner.setStyleSheet(f"background:#FFF6E5;color:#8A5A00;padding:8px 26px;border-bottom:1px solid #F3E1B9;")
        main.addWidget(self.banner)
        main.addWidget(self.stack, 1)
        sb = QFrame()
        sb.setObjectName("StatusBar")
        sb.setFixedHeight(30)
        sh = QHBoxLayout(sb)
        sh.setContentsMargins(26, 0, 22, 0)
        self.status = QLabel(tr("ready"))
        self.status.setObjectName("StatusText")
        self.status_r = QLabel("")
        self.status_r.setObjectName("StatusText")
        sh.addWidget(self.status, 1)
        sh.addWidget(self.status_r)
        main.addWidget(sb)
        mw = QWidget()
        mw.setLayout(main)
        root.addWidget(mw, 1)

        dp = self.pages["data"]
        dp.run_requested.connect(self.run_analysis)
        dp.changed.connect(self._data_changed)
        self._flash_timer = QTimer(self)
        self._flash_timer.setSingleShot(True)
        self._flash_timer.timeout.connect(lambda: self.status.setText(tr("ready")))
        self.go("data")
        self._update_nav()

    # ------------------------------------------------------------------
    def _load_settings(self):
        s = settings()
        for k in ["alpha", "cv_folds", "cv_repeats", "seed", "n_perm", "som_grid", "som_iter"]:
            v = s.value(f"st/{k}")
            if v is not None:
                try:
                    setattr(self.st, k, type(getattr(self.st, k))(v))
                except Exception:
                    pass
        for k in ["run_ml", "run_som"]:
            v = s.value(f"st/{k}")
            if v is not None:
                setattr(self.st, k, str(v).lower() in ("true", "1"))

    def _save_settings(self):
        s = settings()
        for k, v in self.st.__dict__.items():
            s.setValue(f"st/{k}", v)

    def go(self, key):
        self.stack.setCurrentWidget(self.pages[key])
        b, _ = self.nav_btns[key]
        b.setChecked(True)
        p = self.pages[key]
        self.p_title.setText(tr(p.title_key))
        self.p_sub.setText(tr(p.sub_key))

    def _update_nav(self):
        has = self.R is not None
        for k, (b, key) in self.nav_btns.items():
            if k != "data":
                b.setEnabled(has)

    def flash(self, msg, ms=6000):
        self.status.setText(msg)
        self._flash_timer.start(ms)

    def _data_changed(self):
        if self.R is not None and not self.dirty:
            self.dirty = True
            self.banner.setText(tr("data_changed"))
            self.banner.setVisible(True)

    # ------------------------------------------------------------------
    def set_lang(self, code):
        if code == i18n.LANG:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            i18n.set_lang(code)
            apply_qt_translator(code)
            settings().setValue("lang", code)
            self.brand_sub.setText(tr("app_sub").upper())
            for k, (b, key) in self.nav_btns.items():
                b.setText(tr(key))
            for key, l in self.nav_secs.items():
                l.setText(tr(key))
            self.b_settings.setText(tr("settings"))
            self.b_about.setText(tr("about"))
            self.b_run.setText(tr("run"))
            self.status.setText(tr("ready"))
            if self.banner.isVisible():
                self.banner.setText(tr("data_changed"))
            for p in self.pages.values():
                p.retranslate()
            if self.R is not None:
                self.status_r.setText(f"{len(self.R.props)} {tr('seeds')} · {len(self.R.groups)} {tr('groups')}")
            cur = [k for k, p in self.pages.items() if p is self.stack.currentWidget()][0]
            self.go(cur)
        finally:
            QApplication.restoreOverrideCursor()

    def open_settings(self):
        d = SettingsDialog(self.st, self)
        if d.exec():
            d.apply(self.st)
            self._save_settings()

    # ------------------------------------------------------------------
    def run_analysis(self):
        df = self.pages["data"].get_frame()
        clean, rep = core.clean_input(df) if len(df) else (df, {"valid": 0})
        if rep["valid"] < 3:
            QMessageBox.warning(self, tr("warning"), tr("not_enough"))
            return
        labels = {k: tr("pg_" + k) for k in ["props", "desc", "compare", "corr", "pca", "ml", "clus", "som", "done"]}
        dlg = ProgressDialog(tr("running"), self)
        self._t0 = time.time()
        w = Worker(core.run_all, df, self.st)
        w.progress.connect(lambda f, m: dlg.update_progress(f, labels.get(m, "")))
        w.done.connect(lambda R: self._analysis_done(R, dlg))
        w.failed.connect(lambda e: self._failed(e, dlg))
        self._worker = w
        self.b_run.setEnabled(False)
        w.start()
        dlg.exec()

    def _analysis_done(self, R, dlg):
        dlg.update_progress(1.0, tr("pg_done"))
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.R = R
            self.dirty = False
            self.banner.setVisible(False)
            for k, p in self.pages.items():
                if k != "data":
                    p.set_results(R)
            self._update_nav()
            self.go("overview")
        finally:
            QApplication.restoreOverrideCursor()
            dlg.accept()
            self.b_run.setEnabled(True)
        dt = time.time() - self._t0
        self.flash(tr("analysis_done", s=i18n.num(dt, 1)))
        self.status_r.setText(f"{len(R.props)} {tr('seeds')} · {len(R.groups)} {tr('groups')}")

    def _failed(self, err, dlg):
        dlg.reject()
        self.b_run.setEnabled(True)
        msg = err.split("\n\n")[0]
        if msg == "not_enough":
            msg = tr("not_enough")
        box = QMessageBox(QMessageBox.Critical, tr("error"), msg, parent=self)
        box.setDetailedText(err)
        box.exec()

    # ------------------------------------------------------------------
    def _run_job(self, title, fn, on_done, *a, **kw):
        dlg = ProgressDialog(title, self)
        w = Worker(fn, *a, **kw)
        w.progress.connect(lambda f, m: dlg.update_progress(f, m))
        w.done.connect(lambda r: (dlg.accept(), on_done(r)))
        w.failed.connect(lambda e: self._failed(e, dlg))
        self._job = w
        w.start()
        dlg.exec()

    def make_report(self, meta):
        if self.R is None:
            return
        name = ("SeedBox_report" if i18n.LANG == "en" else "SeedBox_laudo") + ".pdf"
        p, _ = QFileDialog.getSaveFileName(self, tr("rep_gen"), f"{last_dir()}/{name}", "PDF (*.pdf)")
        if not p:
            return
        remember_dir(p)

        def job(progress=None):
            return report.build(self.R, p, meta, progress=lambda f: progress(f, ""))

        def done(path):
            self.pages["report"].show_saved(path)
            self.flash(f"{tr('rep_ok')} {path}")
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        self._run_job(tr("rep_gen"), job, done)

    def export_zip(self, fmts, dpi):
        if self.R is None:
            return
        name = ("SeedBox_figures" if i18n.LANG == "en" else "SeedBox_figuras") + ".zip"
        p, _ = QFileDialog.getSaveFileName(self, tr("export_zip"), f"{last_dir()}/{name}", "ZIP (*.zip)")
        if not p:
            return
        remember_dir(p)

        def job(progress=None):
            return export.figures_zip(self.R, p, dpi=dpi, fmts=tuple(fmts), progress=lambda f: progress(f, ""))

        def done(n):
            self.flash(tr("zip_ok", n=n) + f"  {p}")
            QMessageBox.information(self, tr("done"), f"{tr('zip_ok', n=n)}\n\n{p}")
        self._run_job(tr("exporting"), job, done)

    def export_excel(self):
        if self.R is None:
            return
        name = ("SeedBox_results" if i18n.LANG == "en" else "SeedBox_resultados") + ".xlsx"
        p, _ = QFileDialog.getSaveFileName(self, tr("export_xlsx"), f"{last_dir()}/{name}", "Excel (*.xlsx)")
        if not p:
            return
        remember_dir(p)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            export.results_workbook(self.R, p)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, tr("error"), str(e))
            return
        QApplication.restoreOverrideCursor()
        self.flash(f"{tr('saved_to')}: {p}")
