"""File exports: Excel workbook, template and figure archive."""
import os
import io
import zipfile
import tempfile
import pandas as pd

from .core import TRAITS, UNITS
from . import figures, i18n
from .i18n import tr, trait


def _trait_cols():
    return {t: f"{trait(t)} ({UNITS[t]})" for t in TRAITS}


def results_workbook(R, path):
    tc = _trait_cols()
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        per = R.props[["group", "seed"] + TRAITS].rename(columns={"group": tr("group"), "seed": tr("seed"), **tc})
        per.to_excel(xw, sheet_name=tr("tab_seed")[:31], index=False)
        d = R.desc.copy()
        d["group"] = d["group"].replace("__all__", tr("pooled"))
        d["trait"] = d["trait"].map(lambda t: tc[t])
        d.rename(columns={"group": tr("group"), "trait": tr("trait")}).to_excel(
            xw, sheet_name=tr("tab_summary")[:31], index=False)
        a = R.assum.copy()
        a["trait"] = a["trait"].map(lambda t: tc[t])
        a.to_excel(xw, sheet_name=tr("tab_assum")[:31], index=False)
        if R.comp is not None:
            c = R.comp.copy()
            c["trait"] = c["trait"].map(lambda t: tc[t])
            c.to_excel(xw, sheet_name=tr("nav_compare")[:31], index=False)
            if R.pairs is not None and len(R.pairs):
                R.pairs.to_excel(xw, sheet_name=tr("pairwise")[:31], index=False)
        for g, cr in R.corr.items():
            name = (tr("pooled") if g == "__all__" else g)
            cr["r"].to_excel(xw, sheet_name=f"r {name}"[:31])
            cr["q"].to_excel(xw, sheet_name=f"q {name}"[:31])
        P = R.pca
        pd.DataFrame({tr("eigen"): P["eigen"], tr("explained"): P["explained"], tr("cumulative"): P["cum"]},
                     index=P["loadings"].columns).to_excel(xw, sheet_name="PCA")
        P["loadings"].to_excel(xw, sheet_name=tr("loadings")[:31])
        if R.clf:
            t = R.clf["table"].copy()
            t["model"] = t["model"].map(tr)
            t.to_excel(xw, sheet_name=tr("nav_models")[:31], index=False)
        if R.clus and R.clus["methods"]:
            pd.DataFrame({tr(m): {"ARI": v["ari"], tr("silhouette"): v["sil"]} for m, v in R.clus["methods"].items()}
                         ).T.to_excel(xw, sheet_name=tr("clustering")[:31])
    return path


def template(path, n_groups=2, n_seeds=10):
    rows = []
    for g in range(n_groups):
        for s in range(n_seeds):
            rows.append({tr("group"): f"{tr('lot')} {g + 1}", tr("seed"): s + 1,
                         f"{tr('length')} (mm)": None, f"{tr('width')} (mm)": None,
                         f"{tr('thickness')} (mm)": None})
    pd.DataFrame(rows).to_excel(path, index=False)
    return path


def figures_zip(R, path, dpi=600, fmts=("png",), progress=None):
    items = figures.available(R)
    total = len(items) * len(fmts)
    k = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z, tempfile.TemporaryDirectory() as tmp:
        for i, (key, title, fn) in enumerate(items):
            fig = fn(R)
            base = f"{i + 1:02d}_{key}"
            for f in fmts:
                fp = os.path.join(tmp, f"{base}.{f}")
                figures.save(fig, fp, dpi=dpi)
                z.write(fp, f"{base}.{f}")
                k += 1
                if progress:
                    progress(k / total)
    return k
