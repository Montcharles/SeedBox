__version__ = "2.01"
APP_NAME = "SeedBox"
