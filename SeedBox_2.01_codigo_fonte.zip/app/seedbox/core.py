"""SeedBox analysis engine."""
from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")

AXES = ["L", "W", "T"]
DERIVED = ["Da", "Dg", "R", "Phi", "V", "S"]
TRAITS = AXES + DERIVED
UNITS = {"L": "mm", "W": "mm", "T": "mm", "Da": "mm", "Dg": "mm",
         "R": "%", "Phi": "%", "V": "mm³", "S": "mm²"}


@dataclass
class Settings:
    alpha: float = 0.05
    cv_folds: int = 10
    cv_repeats: int = 5
    seed: int = 42
    n_perm: int = 999
    som_grid: int = 0          # 0 = automatic
    som_iter: int = 7000
    run_ml: bool = True
    run_som: bool = True


# --------------------------------------------------------------------------
# Physical properties
# --------------------------------------------------------------------------
def physical_properties(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    from . import native
    if native.available():
        res = native.physical(out["L"].to_numpy(float), out["W"].to_numpy(float), out["T"].to_numpy(float))
        for k, v in res.items():
            out[k] = v
        return out
    a, b, c = out["L"].astype(float), out["W"].astype(float), out["T"].astype(float)
    out["Da"] = (a + b + c) / 3.0
    out["Dg"] = np.cbrt(a * b * c)
    out["R"] = b / a * 100.0
    out["Phi"] = out["Dg"] / a * 100.0
    out["V"] = math.pi * a * b * c / 6.0
    out["S"] = math.pi * out["Dg"] ** 2
    return out


def clean_input(df: pd.DataFrame):
    """Return (clean_df, report dict)."""
    d = df.copy()
    rep = {"input": len(d)}
    for c in AXES:
        d[c] = pd.to_numeric(d[c].astype(str).str.replace(",", ".", regex=False).str.strip(),
                             errors="coerce")
    d["group"] = d["group"].astype(str).str.strip()
    d.loc[d["group"].isin(["", "nan", "None"]), "group"] = np.nan
    missing = d[AXES].isna().any(axis=1) | d["group"].isna()
    rep["missing"] = int(missing.sum())
    d = d[~missing]
    nonpos = (d[AXES] <= 0).any(axis=1)
    rep["nonpositive"] = int(nonpos.sum())
    d = d[~nonpos].copy()
    rep["order"] = int(((d["W"] > d["L"]) | (d["T"] > d["W"])).sum())
    if "seed" not in d.columns:
        d["seed"] = d.groupby("group", sort=False).cumcount() + 1
    d = d.reset_index(drop=True)
    rep["valid"] = len(d)
    return d, rep


# --------------------------------------------------------------------------
# Descriptive statistics and assumptions
# --------------------------------------------------------------------------
def descriptives(props: pd.DataFrame, groups: list[str]) -> pd.DataFrame:
    rows = []
    for g in groups + ["__all__"]:
        sub = props if g == "__all__" else props[props["group"] == g]
        for t in TRAITS:
            x = sub[t].to_numpy(float)
            n = len(x)
            m = x.mean()
            sd = x.std(ddof=1) if n > 1 else np.nan
            se = sd / np.sqrt(n) if n > 1 else np.nan
            tcrit = stats.t.ppf(0.975, n - 1) if n > 1 else np.nan
            rows.append(dict(group=g, trait=t, n=n, mean=m, sd=sd, se=se,
                             cv=sd / m * 100 if m else np.nan,
                             min=x.min(), q1=np.percentile(x, 25), median=np.median(x),
                             q3=np.percentile(x, 75), max=x.max(),
                             ci_low=m - tcrit * se, ci_high=m + tcrit * se,
                             skew=stats.skew(x, bias=False) if n > 2 else np.nan,
                             kurt=stats.kurtosis(x, bias=False) if n > 3 else np.nan))
    return pd.DataFrame(rows)


def assumptions(props, groups):
    rows = []
    for t in TRAITS:
        r = {"trait": t}
        samples = []
        for g in groups:
            x = props.loc[props["group"] == g, t].to_numpy(float)
            samples.append(x)
            r[f"sw_{g}"] = stats.shapiro(x).pvalue if 3 <= len(x) <= 5000 else np.nan
        r["levene"] = stats.levene(*samples, center="median").pvalue if len(groups) > 1 else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# Group comparison
# --------------------------------------------------------------------------
def _cld(groups_sorted, sig):
    """Compact letter display (insert-and-absorb)."""
    letters = [set(groups_sorted)]
    for i, gi in enumerate(groups_sorted):
        for gj in groups_sorted[i + 1:]:
            if not sig.get((gi, gj), sig.get((gj, gi), False)):
                continue
            new = []
            for L in letters:
                if gi in L and gj in L:
                    new.append(L - {gi})
                    new.append(L - {gj})
                else:
                    new.append(L)
            # absorb
            new = [s for s in new if s]
            uniq = []
            for s in new:
                if not any(s < o for o in new) and s not in uniq:
                    uniq.append(s)
            letters = uniq
    # order letters by first group appearance
    letters.sort(key=lambda s: min(groups_sorted.index(g) for g in s))
    out = {g: "" for g in groups_sorted}
    for k, s in enumerate(letters):
        for g in s:
            out[g] += "abcdefghijklmnopqrstuvwxyz"[k % 26]
    return out


def compare_groups(props, groups, assum, alpha=0.05):
    rows, pair_rows = [], []
    k = len(groups)
    for t in TRAITS:
        samples = [props.loc[props["group"] == g, t].to_numpy(float) for g in groups]
        a_row = assum[assum["trait"] == t].iloc[0]
        normal = all((a_row.get(f"sw_{g}", 1) or 1) >= alpha for g in groups)
        homo = (a_row["levene"] if not np.isnan(a_row["levene"]) else 1) >= alpha
        param = normal and homo
        r = {"trait": t, "parametric": param}
        sig = {}
        if k == 2:
            x, y = samples
            if param:
                res = stats.ttest_ind(x, y, equal_var=True)
                r.update(test="t", stat=res.statistic, p=res.pvalue)
                sp = np.sqrt(((len(x) - 1) * x.var(ddof=1) + (len(y) - 1) * y.var(ddof=1)) / (len(x) + len(y) - 2))
                d = (x.mean() - y.mean()) / sp if sp > 0 else 0.0
                J = 1 - 3 / (4 * (len(x) + len(y)) - 9)
                r.update(effect=d * J, effect_name="g")
            else:
                res = stats.mannwhitneyu(x, y, alternative="two-sided")
                r.update(test="U", stat=res.statistic, p=res.pvalue)
                r.update(effect=1 - 2 * res.statistic / (len(x) * len(y)), effect_name="r_rb")
                r["effect"] = -r["effect"]  # positive when group 1 > group 2
            sig[(groups[0], groups[1])] = r["p"] < alpha
        else:
            N = sum(len(s) for s in samples)
            if param:
                res = stats.f_oneway(*samples)
                r.update(test="F", stat=res.statistic, p=res.pvalue)
                grand = np.concatenate(samples).mean()
                ssb = sum(len(s) * (s.mean() - grand) ** 2 for s in samples)
                sst = ((np.concatenate(samples) - grand) ** 2).sum()
                r.update(effect=ssb / sst if sst > 0 else 0, effect_name="eta2")
                tk = stats.tukey_hsd(*samples)
                for i in range(k):
                    for j in range(i + 1, k):
                        p = tk.pvalue[i, j]
                        sig[(groups[i], groups[j])] = p < alpha
                        pair_rows.append(dict(trait=t, g1=groups[i], g2=groups[j], p_adj=p, method="Tukey HSD"))
            else:
                res = stats.kruskal(*samples)
                r.update(test="H", stat=res.statistic, p=res.pvalue)
                r.update(effect=(res.statistic - k + 1) / (N - k), effect_name="eps2")
                ps, prs = [], []
                for i in range(k):
                    for j in range(i + 1, k):
                        ps.append(stats.mannwhitneyu(samples[i], samples[j]).pvalue)
                        prs.append((groups[i], groups[j]))
                padj = _holm(np.array(ps))
                for (gi, gj), p in zip(prs, padj):
                    sig[(gi, gj)] = p < alpha
                    pair_rows.append(dict(trait=t, g1=gi, g2=gj, p_adj=p, method="Mann-Whitney (Holm)"))
        means = {g: s.mean() for g, s in zip(groups, samples)}
        order = sorted(groups, key=lambda g: -means[g])
        letters = _cld(order, sig) if r["p"] < alpha or k == 2 else {g: "a" for g in groups}
        if r["p"] >= alpha:
            letters = {g: "a" for g in groups}
        for g in groups:
            r[f"letter_{g}"] = letters[g]
        rows.append(r)
    return pd.DataFrame(rows), pd.DataFrame(pair_rows)


def _holm(p):
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    run = 0
    for rank, i in enumerate(order):
        run = max(run, min(1.0, (m - rank) * p[i]))
        adj[i] = run
    return adj


def _bh(p):
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)
    ranked = p[order] * m / (np.arange(m) + 1)
    q = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(m)
    out[order] = np.minimum(q, 1)
    return out


# --------------------------------------------------------------------------
# Correlations
# --------------------------------------------------------------------------
def correlations(props, groups):
    res = {}
    for g in groups + ["__all__"]:
        sub = props if g == "__all__" else props[props["group"] == g]
        X = sub[TRAITS].to_numpy(float)
        n = len(TRAITS)
        R = np.eye(n)
        P = np.zeros((n, n))
        idx = []
        for i in range(n):
            for j in range(i + 1, n):
                if np.std(X[:, i]) == 0 or np.std(X[:, j]) == 0 or len(X) < 3:
                    r, p = np.nan, np.nan
                else:
                    r, p = stats.pearsonr(X[:, i], X[:, j])
                R[i, j] = R[j, i] = r
                P[i, j] = P[j, i] = p
                idx.append((i, j))
        pv = np.array([P[i, j] for i, j in idx])
        Q = np.zeros((n, n))
        ok = ~np.isnan(pv)
        qv = np.full(len(pv), np.nan)
        if ok.any():
            qv[ok] = _bh(pv[ok])
        for (i, j), q in zip(idx, qv):
            Q[i, j] = Q[j, i] = q
        res[g] = dict(r=pd.DataFrame(R, TRAITS, TRAITS), p=pd.DataFrame(P, TRAITS, TRAITS),
                      q=pd.DataFrame(Q, TRAITS, TRAITS), n=len(sub))
    return res


# --------------------------------------------------------------------------
# PCA
# --------------------------------------------------------------------------
def pca(props):
    X = props[TRAITS].to_numpy(float)
    mu, sd = X.mean(0), X.std(0, ddof=1)
    sd[sd == 0] = 1
    Z = (X - mu) / sd
    C = np.corrcoef(Z, rowvar=False)
    C = np.nan_to_num(C)
    ev, vec = np.linalg.eigh(C)
    order = np.argsort(ev)[::-1]
    ev, vec = ev[order], vec[:, order]
    ev = np.clip(ev, 0, None)
    # sign convention: largest |loading| positive
    for k in range(vec.shape[1]):
        if vec[np.argmax(np.abs(vec[:, k])), k] < 0:
            vec[:, k] *= -1
    scores = Z @ vec
    explained = ev / ev.sum() * 100
    loadings = vec * np.sqrt(ev)
    retained = int(max(1, (ev > 1).sum()))
    return dict(eigen=ev, explained=explained, cum=np.cumsum(explained),
                vectors=pd.DataFrame(vec, TRAITS, [f"PC{i+1}" for i in range(len(ev))]),
                loadings=pd.DataFrame(loadings, TRAITS, [f"PC{i+1}" for i in range(len(ev))]),
                scores=scores, retained=retained, groups=props["group"].to_numpy())


# --------------------------------------------------------------------------
# Supervised classification
# --------------------------------------------------------------------------
MODEL_KEYS = ["lr", "lda", "qda", "svm_lin", "svm_rbf", "knn", "rf", "gb"]


def _make_model(key, seed):
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
    from sklearn.svm import SVC
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    m = {
        "lr": LogisticRegression(max_iter=5000),
        "lda": LinearDiscriminantAnalysis(),
        "qda": QuadraticDiscriminantAnalysis(reg_param=0.01),
        "svm_lin": SVC(kernel="linear", probability=True, random_state=seed),
        "svm_rbf": SVC(kernel="rbf", probability=True, random_state=seed),
        "knn": KNeighborsClassifier(n_neighbors=5),
        "rf": RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=-1),
        "gb": GradientBoostingClassifier(random_state=seed),
    }[key]
    return make_pipeline(StandardScaler(), m)


def classification(props, groups, st: Settings, progress=None):
    from sklearn.model_selection import (RepeatedStratifiedKFold, StratifiedKFold,
                                         cross_validate, cross_val_predict, permutation_test_score)
    from sklearn.metrics import confusion_matrix, roc_curve, auc
    y_raw = props["group"].to_numpy()
    y = np.array([groups.index(v) for v in y_raw])
    counts = np.bincount(y)
    min_n = counts.min()
    if len(groups) < 2 or min_n < 4:
        return None
    folds = int(min(st.cv_folds, min_n))
    binary = len(groups) == 2
    scoring = {"acc": "accuracy", "bacc": "balanced_accuracy", "f1": "f1_macro",
               "auc": "roc_auc" if binary else "roc_auc_ovr"}
    cv = RepeatedStratifiedKFold(n_splits=folds, n_repeats=st.cv_repeats, random_state=st.seed)
    X_full = props[TRAITS].to_numpy(float)
    X_axes = props[AXES].to_numpy(float)
    rows, raw = [], {}
    keys = [k for k in MODEL_KEYS if not (k == "knn" and min_n * (folds - 1) / folds < 5)]
    total = len(keys) + 3
    for i, key in enumerate(keys):
        if progress:
            progress(i / total, key)
        mdl = _make_model(key, st.seed)
        try:
            res = cross_validate(mdl, X_full, y, cv=cv, scoring=scoring, error_score=np.nan)
        except Exception:
            continue
        row = {"model": key}
        for s in scoring:
            v = res[f"test_{s}"]
            v = v[~np.isnan(v)]
            row[s] = v.mean() if len(v) else np.nan
            row[f"{s}_sd"] = v.std(ddof=1) if len(v) > 1 else np.nan
            if s == "bacc" or s == "acc":
                row[f"{s}_lo"], row[f"{s}_hi"] = (np.percentile(v, 2.5), np.percentile(v, 97.5)) if len(v) else (np.nan, np.nan)
        raw[key] = res["test_bacc"]
        rows.append(row)
    table = pd.DataFrame(rows)
    if table.empty:
        return None
    table = table.sort_values(["bacc", "acc"], ascending=False).reset_index(drop=True)
    best = table.iloc[0]["model"]
    linear = table[table["model"].isin(["lr", "lda", "svm_lin"])]
    # axes-only comparison for best model
    if progress:
        progress((len(keys)) / total, "axes")
    res_ax = cross_validate(_make_model(best, st.seed), X_axes, y, cv=cv,
                            scoring={"bacc": "balanced_accuracy", "acc": "accuracy"})
    axes_cmp = dict(full_bacc=table.iloc[0]["bacc"], full_acc=table.iloc[0]["acc"],
                    axes_bacc=res_ax["test_bacc"].mean(), axes_bacc_sd=res_ax["test_bacc"].std(ddof=1),
                    axes_acc=res_ax["test_acc"].mean())
    # confusion matrix + ROC (pooled out-of-fold predictions, one repetition)
    if progress:
        progress((len(keys) + 1) / total, "cm")
    skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=st.seed)
    y_pred = cross_val_predict(_make_model(best, st.seed), X_full, y, cv=skf)
    cm = confusion_matrix(y, y_pred, labels=list(range(len(groups))))
    roc = None
    try:
        proba = cross_val_predict(_make_model(best, st.seed), X_full, y, cv=skf, method="predict_proba")
        roc = {}
        for ci in range(len(groups)):
            if binary and ci == 0:
                continue
            fpr, tpr, _ = roc_curve((y == ci).astype(int), proba[:, ci])
            roc[groups[ci]] = (fpr, tpr, auc(fpr, tpr))
    except Exception:
        pass
    # permutation test (best model)
    if progress:
        progress((len(keys) + 2) / total, "perm")
    n_perm = 99 if best in ("rf", "gb") else 199
    perm_model = _make_model(best, st.seed)
    if best == "rf":
        perm_model.set_params(randomforestclassifier__n_estimators=100)
    try:
        score, perm_scores, pval = permutation_test_score(
            perm_model, X_full, y, cv=StratifiedKFold(min(folds, 5), shuffle=True, random_state=st.seed),
            n_permutations=n_perm, scoring="balanced_accuracy", random_state=st.seed)
    except Exception:
        score, perm_scores, pval = np.nan, np.array([]), np.nan
    chance = 1.0 / len(groups)
    return dict(table=table, best=best, raw=raw, axes=axes_cmp, cm=cm, roc=roc,
                perm=dict(score=score, scores=perm_scores, p=pval, n=n_perm),
                folds=folds, repeats=st.cv_repeats, chance=chance,
                linear_range=(linear["acc"].min(), linear["acc"].max()) if len(linear) else (np.nan, np.nan))


# --------------------------------------------------------------------------
# Unsupervised clustering
# --------------------------------------------------------------------------
def clustering(props, groups, seed=42):
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans, AgglomerativeClustering
    from sklearn.mixture import GaussianMixture
    from sklearn.metrics import adjusted_rand_score, silhouette_score
    X = StandardScaler().fit_transform(props[TRAITS].to_numpy(float))
    y = props["group"].to_numpy()
    n = len(X)
    kmax = int(min(8, n - 1))
    ks = list(range(2, kmax + 1))
    curves = {"k": ks, "wss": [], "sil": [], "bic": []}
    for k in ks:
        km = KMeans(k, n_init=10, random_state=seed).fit(X)
        curves["wss"].append(km.inertia_)
        curves["sil"].append(silhouette_score(X, km.labels_))
        gm = GaussianMixture(k, covariance_type="full", random_state=seed, reg_covar=1e-4).fit(X)
        curves["bic"].append(gm.bic(X))
    k_sil = ks[int(np.argmax(curves["sil"]))]
    k_bic = ks[int(np.argmin(curves["bic"]))]
    kg = max(2, len(groups))
    methods = {}
    if kg < n:
        labs = {
            "kmeans": KMeans(kg, n_init=10, random_state=seed).fit_predict(X),
            "ward": AgglomerativeClustering(kg, linkage="ward").fit_predict(X),
            "gmm": GaussianMixture(kg, random_state=seed, reg_covar=1e-4).fit(X).predict(X),
        }
        for m, lab in labs.items():
            methods[m] = dict(ari=adjusted_rand_score(y, lab) if len(groups) > 1 else np.nan,
                              sil=silhouette_score(X, lab) if len(set(lab)) > 1 else np.nan,
                              labels=lab)
    return dict(curves=curves, k_sil=k_sil, k_bic=k_bic, k_used=kg, methods=methods)


# --------------------------------------------------------------------------
# Self-organizing map (hexagonal lattice)
# --------------------------------------------------------------------------
class HexSOM:
    def __init__(self, rows, cols, dim, seed=42):
        self.rows, self.cols = rows, cols
        rng = np.random.default_rng(seed)
        self.rng = rng
        self.W = rng.normal(0, 0.5, (rows * cols, dim))
        r, c = np.divmod(np.arange(rows * cols), cols)
        self.xy = np.c_[c + 0.5 * (r % 2), r * np.sqrt(3) / 2]
        self.D2 = ((self.xy[:, None, :] - self.xy[None, :, :]) ** 2).sum(-1)

    def train(self, X, n_iter=7000, lr0=0.5, sigma0=None):
        sigma0 = sigma0 or max(self.rows, self.cols) / 2.0
        # PCA-based initialization for reproducibility
        Xc = X - X.mean(0)
        u, s, vt = np.linalg.svd(Xc, full_matrices=False)
        pc = vt[:2] * (s[:2, None] / np.sqrt(len(X)))
        gx = (self.xy[:, 0] - self.xy[:, 0].mean()) / (self.xy[:, 0].std() + 1e-9)
        gy = (self.xy[:, 1] - self.xy[:, 1].mean()) / (self.xy[:, 1].std() + 1e-9)
        self.W = X.mean(0) + np.outer(gx, pc[0]) + np.outer(gy, pc[1] if len(pc) > 1 else pc[0])
        idx = self.rng.integers(0, len(X), n_iter)
        from . import native
        if native.available():
            self.W = native.som_train(X, self.W, self.D2, idx, lr0, sigma0)
            return self
        for t in range(n_iter):
            frac = 1 - t / n_iter
            lr = lr0 * frac
            sig = max(sigma0 * frac, 0.5)
            x = X[idx[t]]
            b = np.argmin(((self.W - x) ** 2).sum(1))
            h = np.exp(-self.D2[b] / (2 * sig * sig))
            self.W += lr * h[:, None] * (x - self.W)
        return self

    def bmu(self, X, k=1):
        from . import native
        if k == 1 and native.available():
            return native.bmu(X, self.W)[0]
        d = ((X[:, None, :] - self.W[None, :, :]) ** 2).sum(-1)
        if k == 1:
            return np.argmin(d, 1)
        return np.argsort(d, 1)[:, :k]

    def qe(self, X):
        from . import native
        if native.available():
            return float(native.bmu(X, self.W)[2])
        d = np.sqrt(((X[:, None, :] - self.W[None, :, :]) ** 2).sum(-1))
        return d.min(1).mean()

    def te(self, X):
        from . import native
        if native.available():
            b1, b2_, _ = native.bmu(X, self.W)
            return float((self.D2[b1, b2_] > 1.01).mean())
        b2 = self.bmu(X, 2)
        dd = self.D2[b2[:, 0], b2[:, 1]]
        return float((dd > 1.01).mean())

    def umatrix(self):
        U = np.zeros(len(self.W))
        for i in range(len(self.W)):
            nb = np.where((self.D2[i] > 0) & (self.D2[i] < 1.01))[0]
            U[i] = np.mean(np.linalg.norm(self.W[nb] - self.W[i], axis=1)) if len(nb) else 0
        return U


def _chi2_stat(units, labels, n_units, n_groups):
    tab = np.zeros((n_units, n_groups))
    np.add.at(tab, (units, labels), 1)
    tab = tab[tab.sum(1) > 0]
    exp = tab.sum(1, keepdims=True) * tab.sum(0, keepdims=True) / tab.sum()
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.nansum((tab - exp) ** 2 / exp)


def som_analysis(props, groups, st: Settings, progress=None):
    X = props[TRAITS].to_numpy(float)
    X = (X - X.mean(0)) / np.where(X.std(0, ddof=1) == 0, 1, X.std(0, ddof=1))
    n = len(X)
    y = np.array([groups.index(v) for v in props["group"]])
    if st.som_grid and st.som_grid >= 3:
        side = st.som_grid
        sens = []
    else:
        cands = [s for s in range(4, 13) if s * s <= max(16, 2 * n)]
        if not cands:
            cands = [4]
        sens = []
        for s in cands:
            m = HexSOM(s, s, X.shape[1], st.seed).train(X, n_iter=min(st.som_iter, 3000))
            sens.append((s, m.qe(X), m.te(X)))
            if progress:
                progress(0.3 * len(sens) / len(cands), "som")
        best_qe = min(q for _, q, _ in sens)
        side = next(s for s, q, _ in sens if q <= best_qe * 1.10)
    som = HexSOM(side, side, X.shape[1], st.seed).train(X, n_iter=st.som_iter)
    units = som.bmu(X)
    nu = side * side
    hits = np.zeros((len(groups), nu), int)
    for g in range(len(groups)):
        np.add.at(hits[g], units[y == g], 1)
    nperm = max(199, st.n_perm)
    from . import native
    if native.available():
        obs, perm = native.chi2_perm(units, y, nu, len(groups), nperm, st.seed)
    else:
        obs = _chi2_stat(units, y, nu, len(groups))
        rng = np.random.default_rng(st.seed)
        perm = np.array([_chi2_stat(units, rng.permutation(y), nu, len(groups)) for _ in range(nperm)])
    p = (1 + (perm >= obs).sum()) / (nperm + 1)
    if progress:
        progress(1.0, "som")
    return dict(side=side, som=som, units=units, hits=hits, U=som.umatrix(), planes=som.W,
                qe=som.qe(X), te=som.te(X), chi2=obs, p=p, perm=perm, nperm=nperm, sens=sens)


# --------------------------------------------------------------------------
# Orchestrator
# --------------------------------------------------------------------------
@dataclass
class Results:
    data: pd.DataFrame
    props: pd.DataFrame
    groups: list
    settings: Settings
    clean_report: dict
    desc: pd.DataFrame = None
    assum: pd.DataFrame = None
    comp: pd.DataFrame = None
    pairs: pd.DataFrame = None
    corr: dict = None
    pca: dict = None
    clf: dict = None
    clus: dict = None
    som: dict = None
    extra: dict = field(default_factory=dict)


def run_all(raw: pd.DataFrame, st: Settings, progress=None) -> Results:
    def p(frac, msg):
        if progress:
            progress(frac, msg)
    data, rep = clean_input(raw)
    if len(data) < 3:
        raise ValueError("not_enough")
    groups = list(dict.fromkeys(data["group"].tolist()))
    p(0.02, "props")
    props = physical_properties(data)
    R = Results(data=data, props=props, groups=groups, settings=st, clean_report=rep)
    p(0.06, "desc")
    R.desc = descriptives(props, groups)
    R.assum = assumptions(props, groups)
    if len(groups) > 1:
        p(0.10, "compare")
        R.comp, R.pairs = compare_groups(props, groups, R.assum, st.alpha)
    p(0.14, "corr")
    R.corr = correlations(props, groups)
    p(0.18, "pca")
    R.pca = pca(props)
    if len(groups) > 1 and st.run_ml:
        R.clf = classification(props, groups, st,
                               progress=lambda f, m: p(0.20 + 0.55 * f, "ml"))
    p(0.76, "clus")
    if len(props) >= 6:
        R.clus = clustering(props, groups, st.seed)
    if st.run_som and len(props) >= 10:
        R.som = som_analysis(props, groups, st, progress=lambda f, m: p(0.80 + 0.18 * f, "som"))
    p(1.0, "done")
    return R


def example_dataset(seed=7):
    """Two contrasting populations, n = 100 each."""
    rng = np.random.default_rng(seed)
    rows = []
    # population A: weak coupling between axes
    L = rng.normal(12.9, 1.8, 100)
    W = 6.8 + rng.normal(0, 0.55, 100) - 0.05 * (L - 12.9)
    T = 4.77 + rng.normal(0, 0.55, 100) - 0.03 * (L - 12.9)
    for i in range(100):
        rows.append(("Cerrado", i + 1, L[i], W[i], T[i]))
    # population B: integrated (positively correlated) axes
    z = rng.normal(0, 1, (100, 3))
    C = np.array([[1, 0.68, 0.45], [0.68, 1, 0.49], [0.45, 0.49, 1]])
    Lc = np.linalg.cholesky(C)
    zz = z @ Lc.T
    L2 = 12.96 + 2.2 * zz[:, 0]
    W2 = 6.92 + 0.97 * zz[:, 1]
    T2 = 4.70 + 0.78 * zz[:, 2]
    for i in range(100):
        rows.append(("Atlantic Forest", i + 1, L2[i], W2[i], T2[i]))
    df = pd.DataFrame(rows, columns=["group", "seed", "L", "W", "T"])
    df[AXES] = df[AXES].clip(lower=2.0).round(2)
    return df
