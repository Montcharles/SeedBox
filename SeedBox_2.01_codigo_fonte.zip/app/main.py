import os
import sys


def _prepare_streams():
    if sys.stdout is None or sys.stderr is None:
        try:
            from seedbox.paths import user_dir
            f = open(os.path.join(user_dir(), "seedbox.log"), "a", encoding="utf-8", buffering=1)
        except Exception:
            f = open(os.devnull, "w")
        sys.stdout = sys.stdout or f
        sys.stderr = sys.stderr or f


def _install_excepthook():
    import traceback

    def hook(et, ev, tb):
        txt = "".join(traceback.format_exception(et, ev, tb))
        try:
            sys.stderr.write(txt)
        except Exception:
            pass
        try:
            from PySide6.QtWidgets import QApplication, QMessageBox
            if QApplication.instance():
                box = QMessageBox(QMessageBox.Warning, "SeedBox", str(ev) or et.__name__)
                box.setDetailedText(txt)
                box.exec()
        except Exception:
            pass
    sys.excepthook = hook


def main():
    _prepare_streams()
    _install_excepthook()
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("SeedBox.DimensionalMorphometry.1")
        except Exception:
            pass
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    from PySide6.QtCore import Qt, QSettings
    from PySide6.QtGui import QIcon, QPixmap, QPainter, QColor, QFont, QLinearGradient
    from PySide6.QtWidgets import QApplication, QSplashScreen
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setApplicationName("SeedBox")
    app.setOrganizationName("SeedBox")
    from seedbox.paths import asset
    app.setWindowIcon(QIcon(asset("emblem.png")))
    from seedbox.ui import theme
    theme.load_fonts()

    # splash
    W, H = 640, 340
    pm = QPixmap(W, H)
    pm.fill(QColor("#0D1B26"))
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    g = QLinearGradient(0, 0, W, H)
    g.setColorAt(0, QColor("#0F2433"))
    g.setColorAt(1, QColor("#081118"))
    p.fillRect(0, 0, W, H, g)
    logo = QPixmap(asset("logo_dark.png")).scaledToWidth(470, Qt.SmoothTransformation)
    p.drawPixmap((W - logo.width()) // 2, (H - logo.height()) // 2 - 16, logo)
    p.fillRect(0, H - 4, int(W * 0.33), 4, QColor("#2EA043"))
    p.fillRect(int(W * 0.33), H - 4, W, 4, QColor("#1684C4"))
    p.setPen(QColor("#6F8798"))
    f = QFont(theme.ui_font(), 9)
    p.setFont(f)
    from seedbox import __version__
    p.drawText(0, H - 36, W, 20, Qt.AlignCenter, f"v{__version__}")
    p.end()
    splash = QSplashScreen(pm)
    splash.show()
    app.processEvents()

    from seedbox import i18n
    lang = QSettings("SeedBox", "SeedBox").value("lang", "pt")
    i18n.set_lang(lang if lang in ("pt", "en") else "pt")
    qss = theme.stylesheet().replace("CHECK_ICON", theme.check_icon_path())
    app.setStyle("Fusion")
    app.setStyleSheet(qss)
    from seedbox.ui.main_window import MainWindow
    # warm-up heavy imports while splash is visible
    import seedbox.core, seedbox.figures, seedbox.report  # noqa
    w = MainWindow()
    w.showMaximized() if "--windowed" not in sys.argv else w.show()
    splash.finish(w)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
