import sys, os, pickle
sys.path.insert(0, sys.argv[1])
os.environ["QT_QPA_PLATFORM"] = "offscreen"
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
app = QApplication(sys.argv)
from seedbox.ui import theme
from seedbox import i18n, core
theme.load_fonts()
lang = sys.argv[3] if len(sys.argv) > 3 else "pt"
i18n.set_lang(lang)
app.setStyle("Fusion")
app.setStyleSheet(theme.stylesheet().replace("CHECK_ICON", theme.check_icon_path()))
from seedbox.ui.main_window import MainWindow
w = MainWindow()
w.resize(1500, 940)
w.show()
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
app.processEvents()
w.grab().save(f"{out}/00_empty.png")
w.pages["data"].set_frame(core.example_dataset())
app.processEvents()
QTimer.singleShot(0, lambda: None)
w.pages["data"]._refresh_summary()
app.processEvents()
w.grab().save(f"{out}/01_data.png")
R = pickle.load(open("/tmp/R.pkl", "rb"))
class D:
    def update_progress(self,*a): pass
    def accept(self): pass
import time; w._t0 = time.time()
w._analysis_done(R, D())
for k in ["overview", "props", "compare", "multi", "models", "figures", "report"]:
    w.go(k)
    app.processEvents()
    w.grab().save(f"{out}/{k}.png")
print("ok")
