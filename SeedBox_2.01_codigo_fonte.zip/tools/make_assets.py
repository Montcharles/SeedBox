"""Build logo / icon assets from the supplied artwork."""
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import sys, os

A = sys.argv[1]  # assets dir
src = Image.open(os.path.join(A, "logo_source.png")).convert("RGB")
W, H = src.size
SS = 4
# hexagon (outer dark border) in source coords
hexv = [(365, 212), (132, 328), (132, 628), (365, 748), (598, 628), (598, 328)]


def hex_mask(expand=0):
    m = Image.new("L", (W * SS, H * SS), 0)
    cx = sum(p[0] for p in hexv) / 6
    cy = sum(p[1] for p in hexv) / 6
    pts = []
    for x, y in hexv:
        dx, dy = x - cx, y - cy
        d = (dx * dx + dy * dy) ** 0.5
        pts.append(((x + dx / d * expand) * SS, (y + dy / d * expand) * SS))
    ImageDraw.Draw(m).polygon(pts, fill=255)
    return m.resize((W, H), Image.LANCZOS)


arr = np.asarray(src).astype(np.float32)
hm = np.asarray(hex_mask(4)).astype(np.float32) / 255.0

# ---- emblem with glow (transparent) -------------------------------------
lum = arr.max(axis=2)
glow = np.clip((lum - 6) / 110.0, 0, 1) ** 1.2
alpha = np.maximum(hm, glow)
rgb = np.where(alpha[..., None] > 0.02, np.clip(arr / np.maximum(alpha[..., None], 1e-3), 0, 255), 0)
rgb = arr * hm[..., None] + rgb * (1 - hm[..., None])
rgba = np.dstack([rgb, alpha * 255]).astype(np.uint8)
em = Image.fromarray(rgba, "RGBA").crop((70, 150, 660, 810))
em.save(os.path.join(A, "emblem_glow.png"))

# ---- clean emblem (hexagon only) ----------------------------------------
rgba2 = np.dstack([arr, hm * 255]).astype(np.uint8)
clean = Image.fromarray(rgba2, "RGBA").crop((126, 206, 604, 754))
cw, ch = clean.size
side = max(cw, ch)
sq = Image.new("RGBA", (side, side), (0, 0, 0, 0))
sq.paste(clean, ((side - cw) // 2, (side - ch) // 2), clean)
sq = sq.resize((1024, 1024), Image.LANCZOS)
sq.save(os.path.join(A, "emblem.png"))
sq.save(os.path.join(A, "seedbox.ico"),
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])

# ---- wordmark logos ------------------------------------------------------
F = os.path.join(A, "fonts")
GREEN = (46, 160, 67)
BLUE = (22, 132, 196)


def wordmark(dark_bg: bool, path: str):
    h = 600
    canvas = Image.new("RGBA", (2400, h), (0, 0, 0, 0))
    e = sq.resize((520, 520), Image.LANCZOS)
    canvas.paste(e, (20, 40), e)
    d = ImageDraw.Draw(canvas)
    f1 = ImageFont.truetype(os.path.join(F, "Poppins-Bold.ttf"), 250)
    f2 = ImageFont.truetype(os.path.join(F, "Poppins-Medium.ttf"), 78)
    x0 = 600
    d.text((x0, 95), "Seed", font=f1, fill=GREEN + (255,))
    wseed = d.textlength("Seed", font=f1)
    d.text((x0 + wseed, 95), "Box", font=f1, fill=BLUE + (255,))
    sub = (200, 215, 225, 255) if dark_bg else (70, 84, 96, 255)
    d.text((x0 + 8, 400), "DIMENSIONAL MORPHOMETRY", font=f2, fill=sub)
    bbox = canvas.getbbox()
    canvas.crop(bbox).save(path)


wordmark(True, os.path.join(A, "logo_dark.png"))
wordmark(False, os.path.join(A, "logo_light.png"))
print("assets ok")
