#!/bin/bash
# Assemble the Windows distribution of SeedBox.
set -e
B=/home/claude/build
D=$B/dist/SeedBox
PY312=$B/linpy/python/bin/python3
rm -rf $B/dist && mkdir -p $D

echo "== runtime"
cp -r $B/python $D/runtime
R=$D/runtime
SP=$R/Lib/site-packages
rm -rf $R/include $R/libs $R/Scripts $R/tcl $R/share 2>/dev/null || true
find $R -name "*.pdb" -delete
rm -f $R/DLLs/_tkinter.pyd $R/DLLs/tcl86t.dll $R/DLLs/tk86t.dll
rm -rf $R/Lib/test $R/Lib/idlelib $R/Lib/tkinter $R/Lib/turtledemo $R/Lib/ensurepip $R/Lib/lib2to3 \
       $R/Lib/pydoc_data $R/Lib/venv $R/Lib/turtle.py
rm -rf $SP/pip* $SP/setuptools* $SP/_distutils_hack $SP/distutils-precedence.pth $SP/PyInstaller $SP/pyinstaller* \
       $SP/_pyinstaller_hooks_contrib $SP/altgraph* $SP/pefile* $SP/peutils.py $SP/ordlookup $SP/win32ctypes \
       $SP/pywin32_ctypes* $SP/pkg_resources
find $SP -type d -name tests -prune -exec rm -rf {} + 2>/dev/null || true
# pandas needs pandas/_testing at import time: restore if removed
if [ ! -d $SP/pandas/_testing ]; then cp -r $B/python/Lib/site-packages/pandas/_testing $SP/pandas/; fi
if [ ! -d $SP/numpy/testing ]; then cp -r $B/python/Lib/site-packages/numpy/testing $SP/numpy/; fi
find $SP -name "*.pyi" -delete
find $R -name "__pycache__" -type d -prune -exec rm -rf {} +

echo "== PySide6 trim"
Q=$SP/PySide6
cd $Q
rm -rf *.exe doc glue include lib metatypes qml resources scripts typesystems pyside6qml.abi3.* opengl32sw.dll \
       pyside6.abi3.lib vcamp140.dll vccorlib140.dll
for p in Quick Qml Labs Lottie Designer Help UiTools Test Sql Concurrent DBus OpenGL PrintSupport Network Xml; do
  rm -f Qt6${p}*.dll Qt${p}*.pyd
done
rm -f QtExampleIcons.pyd plugins/imageformats/qpdf.dll
cd plugins && rm -rf qmllint designer qmltooling sqldrivers networkinformation tls vectorimageformats generic platforminputcontexts && cd ..
cd translations && ls | grep -v -E "^qtbase_(pt_BR|en)\.qm$" | xargs rm -f && cd ..
cd $B

echo "== app"
mkdir -p $D/app
cp -r $B/app/seedbox $D/app/
cp $B/app/main.py $D/app/
rm -f $D/app/seedbox/native/libseedbox_core.so $D/app/seedbox/assets/logo_source.png
find $D/app -name "__pycache__" -type d -prune -exec rm -rf {} +
$PY312 -m compileall -q -b -f $D/app
find $D/app -name "*.py" -delete
find $D/app -name "__pycache__" -type d -prune -exec rm -rf {} +

echo "== precompile runtime"
$PY312 -m compileall -q -j 0 --invalidation-mode unchecked-hash $R/Lib > /dev/null 2>&1 || true

echo "== launcher"
mkdir -p $B/obj
cp $B/app/seedbox/assets/seedbox.ico $B/obj/
cp $B/cpp/app.manifest $B/cpp/launcher.rc $B/obj/
(cd $B/obj && x86_64-w64-mingw32-windres launcher.rc -O coff -o launcher_res.o)
x86_64-w64-mingw32-g++ -O2 -std=c++17 -municode -mwindows -static -static-libgcc -static-libstdc++ -s \
  -o $D/SeedBox.exe $B/cpp/launcher.cpp $B/obj/launcher_res.o -lshell32
du -sh $D $R $SP/PySide6
